const { GraphQLObjectType } = require("graphql");
const Userquires = require("../model/User/queries");
const Classificationquires = require("../model/Classification/queries");

module.exports = new GraphQLObjectType({
  name: "RootQueryType",
  fields: {
    // users: Userquires.users,
    user: Userquires.user,
    classificationList: Classificationquires.classificationList,
    listbyclassificationid: Classificationquires.listbyclassificationid,
  },
});
