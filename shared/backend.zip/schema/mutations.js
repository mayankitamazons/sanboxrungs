const { GraphQLObjectType } = require("graphql");
const UserMutation = require("../model/User/mutations");
module.exports = new GraphQLObjectType({
  name: "RootMutationsType",
  fields: {
    register: UserMutation.register,
    loginwithemail: UserMutation.loginwithemail,
    loginwithmobile: UserMutation.loginwithmobile,
    usercheck: UserMutation.usercheck,
    updateuser: UserMutation.updateuser,
  },
});
