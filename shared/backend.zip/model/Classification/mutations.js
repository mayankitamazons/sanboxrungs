const {
  GraphQLString,
  GraphQLID,
  GraphQLInt,
  GraphQLBoolean,
  GraphQLNonNull,
} = require("graphql");
const { validate, ValidationError } = require("validator-fluent");
// import { validate, ValidationError } from "validator-fluent";

const Function = require("./function");
const { errorName } = require("../../middleware/errorContant");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;
var c_fields = {
  list: {
    type: GraphQLJSON,
  },
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var home_schema = new GraphQLObjectType({
  name: "ListModel",
  description: "ListModel",
  fields: c_fields,
});
module.exports = {
  classficationlist: {
    type: home_schema,
    description: "List of all classfication",
    args: {
      user_id: { type: GraphQLInt },
    },
    resolve: async (parent, args) => {
      // console.log('req data',args);
      const [data, errors] = validate(args, (value) => ({
        user_id: value("user_id").notEmpty(),
      }));

      if (Object.keys(errors).length > 0) {
        throw new ValidationError(errors);
      } else {
        return Function.classficationlist(args);
      }
    },
  },
};
