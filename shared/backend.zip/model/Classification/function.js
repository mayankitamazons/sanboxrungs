const jwt = require("jsonwebtoken");
const moment = require("moment");
const Query = require("../../lib/query");
const bcrypt = require("bcrypt");
const { createJwtToken } = require("../../util/auth");
const { errorName } = require("../../middleware/errorContant");
const COMMON = require("../../shared/common");
const validator = require("../../helper/validate");
const { relativeTimeRounding } = require("moment");
const { filter } = require("async");
exports.classificationList = async function (args) {
  var q = "select * from classification where status='1'";
  var list = await Query.queryForList(q);
  if (list.length > 0) {
    return { statusCode: 200, list: list[0], message: "Data Found" };
  } else {
    return { statusCode: 404, list: [], message: "No Data Found" };
  }
};
exports.listbyclassificationid = async function (args) {
  var q =
    "select * from users where classification_id=" + args.classification_id;
  var list = await Query.queryForList(q);
  if (list.length > 0) {
    return { statusCode: 200, list: list[0], message: "Data Found" };
  } else {
    return { statusCode: 404, list: [], message: "No Data Found" };
  }
};
