const {
  GraphQLList,
  GraphQLID,
  GraphQLString,
  GraphQLNonNull,
  GraphQLFloat,
  GraphQLObjectType,
  GraphQLInt,
} = require("graphql");

const { validate, ValidationError } = require("validator-fluent");
const { errorName } = require("../../middleware/errorContant");

const Function = require("./function");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;

// Defines the queries
var c_fields = {
  list: {
    type: GraphQLJSON,
  },
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var home_schema = new GraphQLObjectType({
  name: "BaseModel",
  description: "Base model",
  fields: c_fields,
});
module.exports = {
  classificationList: {
    type: home_schema,
    description: "List of all classfication",
    args: {
      user_id: { type: GraphQLInt },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        // console.log('req data',args);
        const [data, errors] = validate(args, (value) => ({
          user_id: value("user_id").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return Function.classificationList(args);
        }
      }
    },
  },
  listbyclassificationid: {
    type: home_schema,
    description: "s list by classfication id",
    args: {
      user_id: { type: GraphQLInt },
      classification_id: { type: GraphQLInt },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      // console.log('req data',args);
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          user_id: value("user_id").notEmpty(),
          classification_id: value("classification_id").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return Function.listbyclassificationid(args);
        }
      }
    },
  },
};
