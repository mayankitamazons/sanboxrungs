const jwt = require("jsonwebtoken");
const moment = require("moment");
const Query = require("../../lib/query");
const bcrypt = require("bcrypt");
const { createJwtToken } = require("../../util/auth");
const { errorName } = require("../../middleware/errorContant");
const COMMON = require("../../shared/common");
const validator = require("../../helper/validate");
const { relativeTimeRounding } = require("moment");
const { filter } = require("async");

exports.register = async function (args) {
  var go_ahead = true;
  if (args.mobile && go_ahead) {
    // Mobile login
    var mobilecheck = await Query.findsinglerecord("users", {
      mobile: args.mobile,
    });
    if (mobilecheck) {
      var err = new Error(errorName.MOBILE_EXIT);
      throw err;

      go_ahead = false;
    }
  }
  if (args.email && go_ahead) {
    // Email login
    var usercheck = await Query.findsinglerecord("users", {
      email: args.email,
    });
    // console.log("email already", usercheck);
    if (usercheck) {
      var err = new Error(errorName.EMAIL_EXIT);
      throw err;
    }
  }
  if (go_ahead) {
    try {
      // args.password = bcrypt.hashSync(args.password, 10);
      let insertresult = await Query.insert("users", {
        data: args,
      });
      if (insertresult.affectedRows > 0) {
        args.id = insertresult.insertId;
        args.token = createJwtToken({
          user_id: args.id,
          name: args.name,
          mobile_number: args.mobile_number,
        });
        return args;
      } else {
        var err = new Error(errorName.WENT_WRONG);
        throw err;
      }
    } catch (e) {
      var err = new Error(errorName.WENT_WRONG);
      throw err;
    }
  } else {
    var err = new Error(errorName.WENT_WRONG);
    throw err;
  }
};

exports.loginwithemail = async function (fields) {
  var query = {};
  var errorCode = "NOTFOUND";
  if (fields.email) {
    query.email = fields.email;
    errorCode = "email";
  }
  if (fields.user_roles) {
    query.user_roles = fields.user_roles;
  }
  var user = await Query.findsinglerecord("users", query);
  // console.log('userdata',user);
  if (user) {
    if (fields.email) {
      if (fields.password === user.password) {
        var validPassword = true;
      } else {
        var validPassword = false;
      }

      // const validPassword = await bcrypt.compare(
      //   fields.password,
      //   user.password
      // );
      if (!validPassword) {
        var err = new Error(errorName.PASSWORD_WRONG);
        throw err;
      }
    }
    const token = createJwtToken({
      user_id: user.id,
      name: user.name,
      mobile_number: user.mobile_number,
    });
    user.token = token;
    user.message = "Login Done";
    user.statusCode = 200;
    return user;
  } else {
    if (errorCode == "email") {
      var err = new Error(errorName.EMAIL_NOT_EXIT);
      throw err;
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  }
};

exports.loginwithmobile = async function (fields) {
  var query = {};
  var errorCode = "NOTFOUND";
  if (fields.mobile_number) {
    query.mobile_number = fields.mobile_number;
    errorCode = "mobile";
  }
  if (fields.user_roles) {
    query.user_roles = fields.user_roles;
  }
  // console.log("query", query);
  var user = await Query.findsinglerecord("users", query);
  // console.log("userdata", user);
  if (user) {
    // send otp
    var otp = 123456;
    // var otp = Math.floor(100000 + Math.random() * 999999);

    var Updateotp = await Query.update("users", {
      data: { otp: otp },
      id: user.id,
    });
    if (Updateotp.affectedRows > 0) {
      return true;
    } else {
      var err = new Error(errorName.WENT_WRONG);
      throw err;
    }
  } else {
    if (errorCode == "mobile") {
      var err = new Error(errorName.MOBILE_NOT_EXIT);
      throw err;
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  }
};
exports.verifiyotp = async function (fields) {
  var query = {};
  if (fields.mobile_number) {
    query.mobile_number = fields.mobile_number;
  }
  if (fields.otp) {
    query.otp = fields.otp;
  }
  var user = await Query.findsinglerecord("users", query);
  // console.log('userdata',user);
  if (user) {
    const token = createJwtToken({
      user_id: user.id,
      name: user.name,
      mobile_number: user.mobile_number,
    });
    user.token = token;
    user.message = "Login Done";
    user.statusCode = 200;
    return user;
  } else {
    var err = new Error(errorName.NOTFOUND);
    throw err;
  }
};

exports.usercheck = async function (fields) {
  var query = {};
  var errorCode = "NOTFOUND";
  if (fields.email) {
    query.email = fields.email;
    errorCode = "email";
  } else if (fields.mobile_number) {
    query.mobile_number = fields.mobile_number;
    errorCode = "mobile";
  }
  var user = await Query.findByFields("users", query);

  if (user.length > 0) {
    if (errorCode == "email") {
      var err = new Error(errorName.EMAIL_EXIT);
      throw err;
    } else if (errorCode == "mobile") {
      var err = new Error(errorName.MOBILE_EXIT);
      throw err;
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  } else {
    return true;
  }
};

exports.updateuser = async function (args) {
  console.log("agrs for update user", args);
  if (args.mobile) {
    var mobilecheck = await Query.query(
      "select id from users where mobile='" +
        args.mobile +
        "' and id !=" +
        args.user_id
    );
    if (mobilecheck) {
      var err = new Error(errorName.MOBILE_EXIT);
      throw err;
    }
  }
  if (args.email) {
    var usercheck = await Query.query(
      "select id from users where email='" +
        args.email +
        "' and id !=" +
        args.user_id
    );
    if (usercheck) {
      var err = new Error(errorName.EMAIL_EXIT);
      throw err;
    }
  }
  var u = {};
  if (args.first_name) u.first_name = args.first_name;
  if (args.middle_name) u.middle_name = args.middle_name;
  if (args.last_name) u.last_name = args.last_name;
  if (args.email) u.email = args.email;
  if (args.mobile) u.mobile = args.mobile;
  if (args.about) u.about = args.about;
  if (args.profile_pic) u.profile_pic = args.profile_pic;
  if (args.gender) u.gender = args.gender;
  if (args.dob) {
    u.dob = moment(args.dob).format("YYYY/MM/DD");
  }
  if (args.chattingess) u.chattingess = args.chattingess;
  if (args.smoking || args.smoking == false) u.smoking = args.smoking;
  if (args.is_driver || args.is_driver == false) u.is_driver = args.is_driver;
  if (args.password) {
    // console.log("password args", args.password);
    var newpassword = bcrypt.hashSync(args.password, 10);
    u.password = newpassword;
  }
  // console.log(u);
  var updateprofile = await Query.update("users", {
    data: u,
    id: args.user_id,
  });
  if (updateprofile.affectedRows > 0) {
    var user = await Query.findsinglerecord("users", {
      id: args.user_id,
    });
    return user;
  } else {
    var err = new Error(errorName.WENT_WRONG);
    throw err;
  }
};

exports.userdetail = async function (args) {
  if (args.user_id == args.token_user_id) {
    var user = await Query.findsinglerecord("users", {
      id: args.token_user_id,
    });
    if (user) {
      return user;
    } else {
      var err = new Error(errorName.NOTFOUND);
      throw err;
    }
  } else {
    var err = new Error(errorName.UNAUTHRIZED);
    throw err;
  }
};
