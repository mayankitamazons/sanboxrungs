const {
  GraphQLString,
  GraphQLID,
  GraphQLInt,
  GraphQLBoolean,
  GraphQLNonNull,
} = require("graphql");
const { validate, ValidationError } = require("validator-fluent");
// import { validate, ValidationError } from "validator-fluent";
const type = require("./type").schema;
const verification_schema = require("./type").verification_schema;
const common_fields = require("./type").common_fields;
const UserFunction = require("./function");
const { errorName } = require("../../middleware/errorContant");

module.exports = {
  register: {
    type,
    description: "Register new user",
    args: {
      mobile_number: { type: GraphQLString },
      name: { type: GraphQLString },
      user_roles: { type: GraphQLString },
      email: { type: GraphQLString },
      password: { type: GraphQLString },
      referral_id: { type: GraphQLString },
      country_code: { type: GraphQLString },
    },
    resolve: async (parent, args) => {
      // console.log('req data',args);
      const [data, errors] = validate(args, (value) => ({
        name: value("name").notEmpty().isLength({ min: 3, max: 25 }),
        email: value("email").isEmail(),
        user_roles: value("user_roles").notEmpty(),
        mobile_number: value("mobile_number").notEmpty().isMobilePhone(),
        country_code: value("country_code").isLength({ min: 1, max: 5 }),
        password: value("password").notEmpty().isLength({ min: 6, max: 25 }),
      }));

      if (Object.keys(errors).length > 0) {
        throw new ValidationError(errors);
      } else {
        return UserFunction.register(args);
      }
    },
  },
  loginwithemail: {
    type,
    description: "Login user with email",
    args: {
      email: { type: GraphQLString },
      password: { type: GraphQLString },
      user_roles: { type: GraphQLString },
    },
    resolve: async (parent, args) => {
      var go_ahead = true;
      const [data, errors] = validate(args, (value) => ({
        email: value("email").notEmpty().isEmail(),
        user_roles: value("user_roles").notEmpty(),
        password: value("password").notEmpty().isLength({ min: 8, max: 12 }),
      }));
      if (Object.keys(errors).length > 0) {
        throw new ValidationError(errors);
      } else {
        return UserFunction.loginwithemail(args);
      }
    },
  },
  loginwithmobile: {
    type: GraphQLBoolean,
    description: "Login user with email",
    args: {
      mobile_number: { type: GraphQLString },
      user_roles: { type: GraphQLString },
    },
    resolve: async (parent, args) => {
      var go_ahead = true;
      const [data, errors] = validate(args, (value) => ({
        mobile_number: value("mobile_number").notEmpty().isMobilePhone(),
        user_roles: value("user_roles").notEmpty(),
      }));
      if (Object.keys(errors).length > 0) {
        throw new ValidationError(errors);
      } else {
        return UserFunction.loginwithmobile(args);
      }
    },
  },
  verifiyotp: {
    type,
    description: "Login user with mobile number and otp code",
    args: {
      mobile_number: { type: GraphQLString },
      otp: { type: GraphQLString },
    },
    resolve: async (parent, args) => {
      var go_ahead = true;
      const [data, errors] = validate(args, (value) => ({
        mobile_number: value("mobile_number").notEmpty().isMobilePhone(),
        otp: value("otp").notEmpty(),
      }));
      if (Object.keys(errors).length > 0) {
        throw new ValidationError(errors);
      } else {
        return UserFunction.verifiyotp(args);
      }
    },
  },
  usercheck: {
    type: GraphQLBoolean,
    description: "Check user email ,mobile no",
    args: {
      email: { type: GraphQLString },
      mobile_number: { type: GraphQLString },
    },
    resolve: async (parent, args) => {
      const [data, errors] = validate(args, (value) => ({
        email: value("email").isEmail(),
        mobile_number: value("mobile_number").isMobilePhone(),
      }));

      if (Object.keys(errors).length > 0) {
        throw new ValidationError(errors);
      } else {
        return UserFunction.usercheck(args);
      }
    },
  },
  updateuser: {
    type,
    description: "update user",
    args: {
      name: { type: GraphQLString },
      middle_name: { type: GraphQLString },
      last_name: { type: GraphQLString },
      mobile: { type: GraphQLString },
      password: { type: GraphQLString },
      country_code: { type: GraphQLString },
      email: { type: GraphQLString },
      profile_pic: { type: GraphQLString },
      dob: { type: GraphQLString },
      gender: { type: GraphQLString },
      location: { type: GraphQLString },
      about: { type: GraphQLString },
      is_driver: { type: GraphQLBoolean },
      smoking: { type: GraphQLBoolean },
      chattingess: { type: GraphQLString },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      // console.log("req args", args);
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          first_name: value("first_name").isLength({ min: 3, max: 25 }),
          middle_name: value("middle_name").isLength({ min: 3, max: 25 }),
          last_name: value("last_name").isLength({ min: 3, max: 25 }),
          email: value("email").isEmail(),
          mobile: value("mobile").isMobilePhone(),
          country_code: value("country_code").isLength({ min: 2, max: 5 }),
          password: value("password").isLength({ min: 8, max: 12 }),
          about: value("about").isLength({ min: 5, max: 25 }),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.user_id = verifiedUser.user_id;
          return UserFunction.updateuser(args);
        }
      }
    },
  },
};
