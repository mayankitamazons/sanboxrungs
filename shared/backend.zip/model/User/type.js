let {
  GraphQLID,
  GraphQLString,
  GraphQLInt,
  GraphQLObjectType,
  GraphQLNonNull,
  GraphQLBoolean,
} = require('graphql');

var auth_data = {
  userId: {
    type: GraphQLString,
  },
  token: {
    type: GraphQLString,
  },
  tokenExpiration: {
    type: GraphQLInt,
  },
};  
const common_fields = {
  id: { type: GraphQLID },
  mobile_number: { type: new GraphQLNonNull(GraphQLString) },
  name: { type: GraphQLString},
  user_roles: { type: GraphQLString },
  country_code: { type: GraphQLString },
  email: { type: GraphQLString },
 password: { type: GraphQLString },
 referral_id: { type: GraphQLString },
 token: { type: GraphQLString },
};
const c_schema = new GraphQLObjectType({
  name: 'User',
  description: 'User type',
  fields: common_fields,
});
module.exports = {
  schema: c_schema,
  auth_data: auth_data,
  common_fields: common_fields,
};
