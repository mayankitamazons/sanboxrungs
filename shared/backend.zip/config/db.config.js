module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "db",
};
// module.exports = {
//   HOST: 'localhost',
//   USER: 'root',
//  PASSWORD: '',
//   DB: 'humbleride',
// };
