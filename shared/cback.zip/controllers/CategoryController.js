const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model
const Category = require('../models/Category'); // Category model
const Page = require('../models/Page'); // Category model
const CRUD = require('../shared/CRUD');
const { wrap } = require('co');
exports.updateCategoryByid = async function (req, res) {
	model = new Category;
	let categoryid = req.params.id
	const body = req.body;
	let parentArr = body.parent_id;
	let parentPath = [];

	var saveRecords = await Category.findById(categoryid);
	if (req.body.title) {
		saveRecords.title = req.body.title;
	}
	if (req.body.status || req.body.status == 0) {
		saveRecords.status = req.body.status;
	}
	if (req.body.seller_status || req.body.seller_status == 0) {
		saveRecords.seller_status = req.body.seller_status;
	}
	if (req.body.icon) {
		saveRecords.icon = req.body.icon;
	}
	if (req.body.description) {
		saveRecords.description = req.body.description;
	}
	if (req.body.image) {
		saveRecords.image = req.body.image;
	}
	if (req.body.isTrending) {
		saveRecords.isTrending = req.body.isTrending;
	}
	if (req.body.creater_id) {
		saveRecords.creater_id = req.body.creater_id;
	}
	if (req.body.sellerid) {
		saveRecords.sellerid = req.body.sellerid;
	}
	if (req.body.parent_id) {
		saveRecords.parent_id = req.body.parent_id;
	}
	if (req.body.services_type) {
		saveRecords.services_type = req.body.services_type;
	}
	if (body.parent_id) {
		if (parentArr.length) {

			var parentData = await Category.findById(parentArr[0]);
			let parentPath = parentData.path;
			parentData.haveChild = true;
			parentData.save((err, result) => {
				console.log("parent Updated succesfully");
			});
		}
	}

	saveRecords.save((err, result) => {
		ResponseService.generalPayloadResponse(err, saveRecords, res);
	});
	// Category.findByIdAndUpdate(categoryid, saveRecords, { new: true }, (err, doc) => {
	//     ResponseService.generalPayloadResponse(err, saveRecords, res, undefined, "Updated");
	// });

}
exports.create = async function (req, res) {
	model = new Category;
	const body = req.body;
	let parentArr = body.parent_id;
	let parentPath = [];
	var customSlug;
	var d = new Date();
	var time = d.getTime();
	if (body.slug) {

		//check slug exists or not

		let CatData = await Category.find({ "slug": body.slug });
		let existsData = CatData[0];

		if (CatData.length) {
			customSlug = existsData.slug + "-" + time;
		} else {
			customSlug = body.slug;
		}

	} else {

		customSlug = CRUD.convertToSlug(body.title);
		let CatData = await Category.find({ "slug": customSlug });
		let existsData = CatData[0];

		if (CatData.length) {
			customSlug = existsData.slug + "-" + time;
		} else {
			customSlug = customSlug + "-" + time;
		}
	}
	model.slug = customSlug;
	model.title = req.body.title;
	if (req.body.services_type)
	model.services_type = req.body.services_type;
	if (req.body.icon == '')
		model.icon = 'https://humbleirde.s3.ca-central-1.amazonaws.com/rugs/logo.png';
	else
		model.icon = req.body.icon;
	model.description = req.body.description;
	if (req.body.image == '')
		model.image = 'https://humbleirde.s3.ca-central-1.amazonaws.com/rugs/logo.png';
	else
		model.image = req.body.image;
	model.isTrending = req.body.isTrending;
	model.creater_id = req.body.creater_id;
	model.sellerid = req.body.sellerid;
	model.parent_id = req.body.parent_id;
	if (req.body.status || req.body.status == 0)
		model.status = req.body.status;
	else
		model.status = 1;
	if (req.body.seller_status || req.body.seller_status == 0)
		model.seller_status = req.body.seller_status;
	else
		model.seller_status = 1;
	if (req.body.root_path)
		model.root_path = req.body.root_path;
	if (parentArr.length) {

		var parentData = await Category.findById(parentArr[0]);
		let parentPath = parentData.path;
		parentData.haveChild = true;
		// parentData.childCount = parentData.childCount + 1;

		parentData.save((err, result) => {
			console.log("parent Updated succesfully");
		});
		//        let index = parentPath.indexOf(parentArr[0]);

		//        if (index == -1) {
		//            parentPath.push({_id: parentData._id});
		//        }
		//        console.log(parentPath);
	}
	//
	//    if (parentPath.length) {
	//        model.path = parentPath
	//    } else {
	//        model.path = parentPath
	//    }

	//    console.log(body);
	//    console.log(parentPath);
	//console.log(model);
	model.save((err, result) => {
		ResponseService.generalPayloadResponse(err, model, res);
	});
}

exports.getCategoryById = async function (req, res) {
	let categoryid = req.params.id
	const model = Category;

	if (categoryid) {
		let categoryData = await model.find({ _id: categoryid }).populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id");
		console.log(categoryData);
		ResponseService.generalPayloadResponse(null, categoryData, res);
		return;
	}
} 
exports.getBySlug = async function (req, res) {
	let slug = req.params.slug
	const model = Category;

	if (slug) {
		let categoryData = await model.find({ slug: slug }).populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id");
		console.log(categoryData);
		ResponseService.generalPayloadResponse(null, categoryData, res);
		return;
	}
}

//category id can be main category id and subcategory id

exports.getCategoryTreeByid = async function (query, limit, page, type, body, res) {

	const model = Category;

	let searchid = body.searchid;
	//console.log(searchid);
	var CategoryData;

	if (body.status) {
		CategoryData = await model.find({ "parent_id": { $in: searchid }, status: body.status }).populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });

	}
	if (body.isTrending) {
		CategoryData = await model.find({ _id: searchid, isTrending: body.isTrending }).populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}
	if (body.creater_id) {
		CategoryData = await model.find({ _id: searchid, creater_id: body.creater_id })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}
	master_cat_data = await model.findOne({ _id: searchid });
	category_name = master_cat_data.title;
	ResponseService.generalPayloadResponse(null, CategoryData, res, 200, category_name);
	return

}
//category slug can be main category id and subcategory id     

exports.getCategoryTreeByslug = async function (query, limit, page, type, body, res) {

	const model = Category;
	var slug = body.searchid;
	Category2 = await model.find({ slug: slug });

	// let searchid = Category2[0]._id;
	//  console.log(searchid);
	var CategoryData;
	// var searchid = Category2[0]._id;
	if (body.status) {
		CategoryData = await model.find({ "parent_id": { $in: searchid }, status: body.status })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
		//console.log(CategoryData);
	}
	if (body.isTrending) {
		CategoryData = await model.find({ _id: searchid, isTrending: body.isTrending })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}
	if (body.creater_id) {
		CategoryData = await model.find({ _id: searchid, creater_id: body.creater_id })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}
	//  console.log(CategoryData);
	ResponseService.generalPayloadResponse(null, CategoryData, res);
	return

}

exports.categorylist = async function (query, limit, page, type, body, res) {

	const model = Category;

	var CategoryData;
	if(body.is_seller && body.seller_id && body.services_type)
	{
		CategoryData = await model.find({status:1,services_type:body.services_type,isTrending: true, parent_id: { $exists: true, $size: 0 } })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id")
			.skip(page * limit).limit(limit).sort({ _id: 1 });
			ResponseService.generalPayloadResponse(null, CategoryData, res);
			return;

	}
	if (body.isTrending) {
		CategoryData = await model.find({ isTrending: true, parent_id: { $exists: true, $size: 0 } })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id")
			.skip(page * limit).limit(limit).sort({ _id: -1 });
	}
	
	if (body.creater_id) {
		CategoryData = await model.find({ creater_id: body.creater_id, parent_id: { $exists: true, $size: 0 } })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}
	if (body.status || body.status == 0) {
		CategoryData = await model.find({ status: body.status, parent_id: { $exists: true, $size: 0 } })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}
	if (body.seller_status || body.seller_status == 0) {
		CategoryData = await model.find({ seller_status: body.seller_status })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}

	if (body.status && body.sellerid) {
		CategoryData = await model.find({ status: body.status, sellerid: body.sellerid }).populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}

	if ((body.seller_status || body.seller_status == 0) && (body.status || body.status == 0)) {
		CategoryData = await model.find({ seller_status: body.seller_status, status: body.status })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}
	if (body.services_type) {
		console.log('special case');   
		CategoryData = await model.find({ services_type: body.services_type,parent_id: { $exists: true, $size: 0 } })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: -1 });
	}
	if (body.services_type && body.status) {
		console.log('special case 2');
		CategoryData = await model.find({ status:body.status,services_type: body.services_type,parent_id: { $exists: true, $size: 0 } })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: 1 });
	}
	if (body.services_type && body.status && body.sellerid) {
		CategoryData = await model.find({ status:body.status,services_type: body.services_type })
			.populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({ _id: 1 });
	}     
	ResponseService.generalPayloadResponse(null, CategoryData, res);
}

exports.pagelist = async function (query, limit, page, type, body, res) {

	const model = Page;
	var PageData;

	if (body.footer_type) {
		PageData = await model.find({ footer_type: body.footer_type }).skip(page * limit).limit(limit).sort({ _id: -1 });
	} else {
		PageData = await model.find().skip(page * limit).limit(limit).sort({ _id: -1 });
	}


	ResponseService.generalPayloadResponse(null, PageData, res);
}