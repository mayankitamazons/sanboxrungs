const ResponseService = require('../shared/ResponseService'); // Response service
const AttributeStyle = require('../models/AttributeStyle'); // Attr option model

const CRUD = require('../shared/CRUD');


exports.list = async function (query, limit, page, type, body, res) {
    // category list has filter of sub category id, isTredning, Creator id
    const model = AttributeStyle;
    var AttributeData;

    if (body.status) {
        AttributeData = await model.find({status: body.status});
    }
    if (body.style_for) {
        AttributeData = await model.find({style_for: body.style_for});
    }
    if (body.style_for && body.status) {
        AttributeData = await model.find({style_for: body.style_for,status: body.status});
    }
    ResponseService.generalPayloadResponse(null, AttributeData, res);
    return;
}