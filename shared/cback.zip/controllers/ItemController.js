const ResponseService = require('../shared/ResponseService'); // Response service
const Item = require('../models/Item'); // Item model

const CRUD = require('../shared/CRUD');

exports.itemList = async function (req, res) {
    const allItem = await Item.find().populate('blockid', "position title content_view search_key");
    ResponseService.generalPayloadResponse(null, allItem, res);
}