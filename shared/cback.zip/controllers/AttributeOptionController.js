const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model

const AttributeOption = require('../models/AttributeOption'); // Topic model

const CRUD = require('../shared/CRUD');

exports.list = async function (query, limit, page, type, body, res) {
     // category list has filter of sub category id, isTredning, Creator id
    const model = AttributeOption;
    var CategoryData;

    if (body.attr_id) {
        CategoryData = await model.find({attr_id:attr_id});
    }
    else
    {
        CategoryData = await model.find({});
    }

    ResponseService.generalPayloadResponse(null, CategoryData, res);
}