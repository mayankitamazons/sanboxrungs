const ResponseService = require('../shared/ResponseService'); // Response service
const LeaderBoard = require('../models/LeaderBoard'); // Attr option model
const Order = require('../models/Order'); // Attr option model
const User = require('../models/User'); // Attr option model
const CRUD = require('../shared/CRUD');


exports.add = async function (req, res) {

    let user_id = req.body.customer_id;
    let order_id = req.body.order_id;
    if (user_id && order_id) {
        let userRecord = await User.findById(user_id);
        if (userRecord) {
            community_id = userRecord.community_id;
            let OrderRecord = await Order.findById(order_id);
            if (OrderRecord) {
                parms = {
                    "order_id": req.body.order_id,
                    "user_id": user_id,
                    "community_id": community_id,
                }
                cart_items = OrderRecord.cartitem;
                first_product_id = cart_items[0].product_id;
                first_product_name = cart_items[0].name;
                if (cart_items.length > 1) {

                    other_str = "& " + (cart_items.length - 1) + " more other product";
                    parms.product = {
                        "product_id": first_product_id,
                        "product_name": first_product_name,
                        "other_str": other_str
                    };
                } else {

                    parms.product = {
                        "product_id": first_product_id,
                        "product_name": first_product_name,
                        "other_str": ''
                    };

                }
                const model = new LeaderBoard(parms);
                await LeaderBoard.findOne({
                    order_id: req.body.order_id,
                    user_id: req.body.user_id
                }, async (err, doc) => {
                    if (doc) {
                        ResponseService.generalPayloadResponse(null, "Already Shared to LeaderBoard", res);
                        return;
                    } else {
                        let LData = await model.save();
                        if (LData) {

                            ResponseService.generalPayloadResponse(null, LData, res);
                            return;
                        } else {
                            ResponseService.generalPayloadResponse(null, "Failed to save", res);
                            return;
                        }

                    }
                })

            } else {
                ResponseService.generalPayloadResponse(null, "Invalid Order id", res);
                return;
            }

        } else {
            ResponseService.generalPayloadResponse(null, "Invalid User id", res);
            return;
        }

    } else {
        ResponseService.generalPayloadResponse(null, "Required Parameter missing", res);
        return;
    }

}
exports.list = async function (query, limit, page, type, body, res) {

    const model = LeaderBoard;
    Ldata = [];
    if (body.community_id) {

        Ldata = await model.find({ "community_id": { $in: body.community_id } }).populate('user_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });

    }
    Ldata = Ldata.filter(l => l.user_id != null || l.user_id != {});
    ResponseService.generalPayloadResponse(null, Ldata, res);
}