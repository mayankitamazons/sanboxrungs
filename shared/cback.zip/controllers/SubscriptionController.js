const asyncHandler = require("../shared/middleware/async");
const ResponseService = require("../shared/ResponseService");
const Subscription = require("../models/Subscription");
const User = require("../models/User");

exports.createSubscription = asyncHandler(async (req, res, next) => {

	const subscription = await Subscription.create(req.body);

	if (!subscription) return ResponseService.generalResponse("Error Creating Subscription", res, 404);

	return ResponseService.generalPayloadResponse(null, subscription, res);
});


exports.getSubscription = asyncHandler(async (req, res, next) => {

	const subscription = await Subscription.findById(req.params.id);

	if (!subscription) return ResponseService.generalResponse("Subscription Not Found", res, 404);

	return ResponseService.generalPayloadResponse(null, subscription, res);
});


exports.getSubscriptions = asyncHandler(async (req, res, next) => {

	const subscription = await Subscription.find();

	if (!subscription) return ResponseService.generalResponse("There was some error", res, 404);

	return ResponseService.generalPayloadResponse(null, subscription, res);
});


exports.subscribeSeller = asyncHandler(async (req, res, next) => {

	const subscription = await Subscription.findById(req.params.id);
	if (!subscription) return ResponseService.generalResponse("Subscription Not Found", res, 404);

	const user = await User.findById(req.body.user);
	if (!user) return ResponseService.generalResponse("Seller Not Found", res, 404);

	user.subscription_plan = req.body.date ? {
		subscription: subscription._id,
		start_date: req.body.date
	} : { subscription: subscription._id, start_date: Date.now() };

	return ResponseService.generalPayloadResponse(null, user, res);
});