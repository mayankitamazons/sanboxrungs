const ResponseService = require('../shared/ResponseService'); // Response service

const Question = require('../models/Question'); // Attr option model
const Answer = require('../models/Answer'); // Attr option model

const User = require('../models/User'); // Attr option model
const CRUD = require('../shared/CRUD');

exports.getById = async function (req, res) {

	model = new Question;

	let QuestioID = req.params.id

	let Records = await Question.findById(QuestioID).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic");

	let totalVote = await (await Answer.find({
		"question_id": QuestioID
	})).length;

	let totalAnswers = await Answer.find({
		"question_id": QuestioID
	})

	//totalAnswers.forEach(async function (firstdata, firstindex) {
	//console.log(firstdata.answers);

	let array = [];

	for (i = 0; i < Records.answers.length; i++) {
		let answerid = Records.answers[i]._id;
		let answerCount = await (await Answer.find({
			"answers": answerid,
			"question_id": QuestioID
		})).length;
		Records.answers[i].vote_count = answerCount;
	}
	Records.total_vote = totalVote;

	if (Records) {
		ResponseService.generalPayloadResponse(null, Records, res);
		return;
	} else {
		Records = {};
		ResponseService.generalPayloadResponse(null, Records, res);
		return;
	}

}
exports.getBySlug = async function (req, res) {
	model = new Question;
	let slug = req.params.slug;

	let Records = await Question.find({
		"slug": slug
	}).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic");
	let QuestioID = Records._id;
	let totalVote = await (await Answer.find({
		"question_id": QuestioID
	})).length;

	Records.total_vote = totalVote;

	if (Records) {
		ResponseService.generalPayloadResponse(null, Records, res);
		return;
	} else {
		Records = {};
		ResponseService.generalPayloadResponse(null, Records, res);
		return;
	}
}

exports.add = async function (req, res) {

	let creater_id = req.body.creater_id;
	body = req.body;
	let userRecord = await User.findById(creater_id);
	if (!req.body.community_id)
		req.body.community_id = userRecord.community_id;
	var customSlug;
	var d = new Date();
	var time = d.getTime();
	if (body.slug) {

		//check slug exists or not

		let QuestionData = await Question.find({
			"slug": body.slug
		});
		let existsData = QuestionData[0];

		if (QuestionData.length) {
			customSlug = existsData.slug + "-" + time;
		} else {
			customSlug = body.slug;
		}

	} else {

		customSlug = CRUD.convertToSlug(body.question);
		let QuestionData = await Question.find({
			"slug": customSlug
		});
		let existsData = QuestionData[0];

		if (QuestionData.length) {
			customSlug = existsData.slug + "-" + time;
		} else {
			customSlug = customSlug + "-" + time;
		}
	}
	req.body.slug = customSlug;
	const model = new Question(req.body);
	let QuestionData = await model.save();
	query = {};
	query.$addToSet = {
		PollList: QuestionData._id
	};
	User.findByIdAndUpdate(userRecord, query, {
		new: true
	}, (err, doc) => {

	});
	ResponseService.generalPayloadResponse(null, QuestionData, res);
	return;
	//    model.save((err, val) => {
	//        ResponseService.generalPayloadResponse(err, val, res);
	//        return;
	//    });
}

exports.update = async function (req, res) {
	let question = await Question.findById(req.params.id);
	if (!question) return ResponseService.generalResponse('Question not found', res, 404);

	if (req.body.poll_complete) {
		req.body.voting_complete_time = Date.now();
	}

	question = await Question.findByIdAndUpdate(req.params.id, req.body, { new: true });

	return ResponseService.generalPayloadResponse(null, question, res);
}

function array_diff(a1, a2) {

	var a = [],
		diff = [];

	for (var i = 0; i < a1.length; i++) {
		a[a1[i]] = true;
	}

	for (var i = 0; i < a2.length; i++) {
		if (a[a2[i]]) {
			delete a[a2[i]];
		} else {
			a[a2[i]] = true;
		}
	}

	for (var k in a) {
		diff.push(k);
	}

	return diff;
}

exports.list = async function (query, limit, page, type, body, res) {

	const model = Question;
	var QuestionData;

	let loggedInUser;

	if (body.login_user_id && body.login_user_id != 'null') {
		loggedInUser = body.login_user_id;
		userRecord = await User.findById(loggedInUser);


	} else {
		loggedInUser = '';
	}


	if (body.isVoted == false && loggedInUser && body.community_id && body.status) {
		let answerData = await Answer.find({
			"user_id": loggedInUser
		});
		u_com = '';
		if (userRecord) {
			user_community = userRecord.community_id;
			for (c = 0; c < user_community.length; c++) {
				s_com_id = user_community[c];
				if (s_com_id == body.community_id) {
					u_com = body.community_id;
				}
			}

		}

		if (answerData.length) {
			let attendQues = [];
			for (i = 0; i < answerData.length; i++) {
				attendQues.push(answerData[i].question_id);
			}
			let filterQuesArr = []
			if (attendQues.length) {

				QuestionDataArr = await model.find({
					status: 1,
					"community_id": {
						$in: u_com
					},
				}).populate('community_id', "builder_name name pincode")
					.populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({
						_id: -1
					});
				QuestionDataArr = QuestionDataArr.filter(poll => poll.creater_id != null);
				let allQuestionsId = [];
				for (i = 0; i < QuestionDataArr.length; i++) {
					allQuestionsId[i] = QuestionDataArr[i]._id;
				}
				console.log("allQuestions");
				console.log(allQuestionsId);

				console.log("filter values");
				filterArr = array_diff(allQuestionsId, attendQues);

				for (i = 0; i < filterArr.length; i++) {
					questionId = filterArr[i];
					try {
						QuestionData = await Question.findById(questionId);
					} catch (err) {

					}

					filterQuesArr[i] = QuestionData;
				}
			}

			QuestionData = filterQuesArr;
		} else {
			QuestionData = await model.find({
				"community_id": {
					$in: body.community_id
				},
				status: body.status
			}).populate('community_id', "builder_name name pincode")
				.populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({
					_id: -1
				});
			QuestionDataArr = QuestionDataArr.filter(poll => poll.creater_id != null);
		}

	} else if (body.isVoted == true && loggedInUser && body.community_id && body.status) {
		let answerData = await Answer.find({
			"user_id": loggedInUser
		});

		if (answerData.length) {
			let attendQues = [];
			for (i = 0; i < answerData.length; i++) {
				attendQues.push(answerData[i].question_id);
			}
			let filterQuesArr = []
			if (attendQues.length) {

				QuestionDataArr = await model.find({
					status: 1,
					"community_id": {
						$in: body.community_id
					},
				}).populate('community_id', "builder_name name pincode")
					.populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({
						_id: -1
					});
				QuestionDataArr = QuestionDataArr.filter(poll => poll.creater_id != null);


				let allQuestionsId = [];
				for (i = 0; i < QuestionDataArr.length; i++) {
					allQuestionsId[i] = QuestionDataArr[i]._id;
				}
				console.log("allQuestions");
				console.log(allQuestionsId);

				console.log("filter values");
				filterArr = attendQues;

				for (i = 0; i < filterArr.length; i++) {
					questionId = filterArr[i];
					try {
						QuestionData = await Question.findById(questionId);
					} catch (err) {

					}

					filterQuesArr[i] = QuestionData;
				}
			}

			QuestionData = filterQuesArr;
		} else {
			QuestionData = await model.find({
				"community_id": {
					$in: body.community_id
				},
				status: body.status
			}).populate('community_id', "builder_name name pincode")
				.populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({
					_id: -1
				});
			QuestionDataArr = QuestionDataArr.filter(poll => poll.creater_id != null);
		}

	} else {
		if (body.status) {
			QuestionData = await model.find({
				status: body.status
			}).populate('community_id', "builder_name name pincode")
				.populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({
					_id: -1
				});
		}
		if (body.creater_id) {
			QuestionData = await model.find({
				creater_id: body.creater_id
			}).populate('community_id', "builder_name name pincode")
				.populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({
					_id: -1
				});

		}
		if (body.community_id) {

			QuestionData = await model.find({
				"community_id": {
					$in: body.community_id
				}
			}).populate('community_id', "builder_name name pincode")
				.populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({
					_id: -1
				});
			QuestionData = QuestionData.filter(poll => poll.creater_id != null);
		}
		if (body.community_id && body.creater_id && (body.status || body.status == 0)) {
			QuestionData = await model.find({
				"community_id": {
					$in: body.community_id
				},
				creater_id: body.creater_id,
				status: body.status
			}).populate('community_id', "builder_name name pincode")
				.populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({
					_id: -1
				});
		}
		if (body.creater_id == '' && body.community_id == '') {
			QuestionData = await model.find().populate('community_id', "builder_name name pincode")
				.populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({
					_id: -1
				});

			QuestionData = QuestionData.filter(poll => poll.creater_id != null);
		}
	}


	let qRecords = [];
	if (loggedInUser) {
		quelength = QuestionData.length;
		if (quelength > 0) {
			for (i = 0; i < QuestionData.length; i++) {
				data = QuestionData[i];
				if (data) {
					QuestioID = data._id;
					if (loggedInUser) {
						let totalVote = await (await Answer.find({
							"question_id": QuestioID,
							"user_id": loggedInUser
						})).length;
						if (totalVote > 0) {
							data.isVoted = true;
							data.total_vote = totalVote;

						} else {
							data.isVoted = false;
						}

					} else {
						data.isVoted = false;
					}
					qRecords.push(data);
				}

			}
		}
		ResponseService.generalPayloadResponse(null, qRecords, res);
		return
	} else {
		ResponseService.generalPayloadResponse(null, QuestionData, res);
		return
	}

}

exports.share = async function (id, res) {
	const model = Question;

	var QuestionData = await model.findById(id);
	QuestionData.share_count = QuestionData.share_count + 1;

	QuestionData.save(function (err, result) {
		if (err) {
			ResponseService.generalResponse("Something went wrong, please try again.", result, 401, "Something went wrong, please try again");
			return;
		} else {
			ResponseService.generalPayloadResponse(err, result, res);
			return;
		}
	});
}