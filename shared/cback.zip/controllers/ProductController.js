const ResponseService = require("../shared/ResponseService"); // Response service
const User = require("../models/User"); // User model

const CRUD = require("../shared/CRUD");
const Product = require("../models/Product");
const Cart = require("../models/Cart");
const Attribute = require("../models/Attribute");
const AttributeStyle = require("../models/AttributeStyle"); // Attr option model
const SellerProduct = require("../models/SellerProduct");
const { compareSync } = require("bcryptjs");
const mongoose = require("mongoose");
const Category = require("../models/Category");
const bodyParser = require("body-parser");
const Order = require("../models/Order");
const Review = require("../models/Review");

exports.ProductFilter = async function (query, limit, page, type, body, res) {
  let productData;
  limit = 1000;
  const model = Product;
  cart_count = 0;
  wishlist_count = 0;
  let pRecords = [];
  userdata = [];
  wishlist = [];
  cartlist = [];
  s_a = [];
  let login_user_id;
  if (body.login_user_id) {
    login_user_id = body.login_user_id;
    var userdata = await User.findById(login_user_id);
    var cartlist = await Cart.findOne({
      customer_id: login_user_id,
      is_active: 1,
    });
    wishlist = userdata.wishList;
  } else {
    login_user_id = "";
  }
  // category page filter
  // filter of size id
  if (body.size_id && body.color_id) {
    console.log("size filter");

    let productData = await Product.find({
      size_id: { $in: body.size_id },
      color_id: { $in: body.color_id },
      status: 1,
    })
      .populate("cat_id", "cat_name image")
      .populate("color_id", "color_name color_code")
      .populate("size_id", "size_name")
      .populate("community_id", "name pincode")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });

    if (login_user_id) {
      if (cartlist) {
        cart_items = cartlist.cartitem;
        cart_count = cartlist.cartitem.length;
      }

      wishlist_count = wishlist.length;
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }
        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
  if (body.size_id) {
    console.log("size filter");

    let productData = await Product.find({
      size_id: { $in: body.size_id },
      status: 1,
    })
      .populate("cat_id", "cat_name image")
      .populate("color_id", "color_name color_code")
      .populate("size_id", "size_name")
      .populate("community_id", "name pincode")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });

    if (login_user_id) {
      if (cartlist) {
        cart_items = cartlist.cartitem;
        cart_count = cartlist.cartitem.length;
      }

      wishlist_count = wishlist.length;
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }
        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
  if (body.color_id) {
    console.log("color filter");

    let productData = await Product.find({
      color_id: { $in: body.color_id },
      status: 1,
    })
      .populate("cat_id", "cat_name image")
      .populate("community_id", "name pincode")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });

    if (login_user_id) {
      if (cartlist) {
        cart_items = cartlist.cartitem;
        cart_count = cartlist.cartitem.length;
      }

      wishlist_count = wishlist.length;
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }
        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
  if (body.community_id && body.cat_id && body.status) {
    console.log("filter 5");
    catArr = [];
    productData = [];
    var categoryRecords = await Category.findById(body.cat_id);
    if (categoryRecords) {
      catArr.push(categoryRecords._id);
    }
    var haveChild = categoryRecords.haveChild;
    if (haveChild) {
      SubCategoryData = await Category.find({
        parent_id: { $in: body.cat_id },
        status: 1,
      });
      if (SubCategoryData.length) {
        for (k = 0; k < SubCategoryData.length; k++) {
          subcatid = SubCategoryData[k]._id;

          catArr.push(subcatid);
        }
      }
    }
    if (catArr.length) {
      for (j = 0; j < catArr.length; j++) {
        categoryid = catArr[j];
        let productDataCat = await Product.find({
          cat_id: { $in: categoryid },
          status: 1,
          community_id: { $in: body.community_id },
        })
          .populate("cat_id", "cat_name image")
          .populate("community_id", "name pincode")
          .populate("creater_id", "name username email userrole profile_pic")
          .skip(page * limit)
          .limit(limit)
          .sort({ _id: -1 });

        productData.push(
          productDataCat.filter(
            (product) =>
              product.seller_id != null && product.seller_id.length != 0
          )
        );
      }
      //productRecord = [].concat.apply([], productData);
      productData = productData[0];
    }
    if (login_user_id) {
      if (cartlist) {
        cart_items = cartlist.cartitem;
        cart_count = cartlist.cartitem.length;
      }

      wishlist_count = wishlist.length;
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }
        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
  //status
  if (body.status || body.status == "0") {
    console.log("filter 6");
    productData = await model
      .find({
        status: body.status,
      })
      .populate("cat_id", "title image")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
    if (login_user_id) {
      cart_items = cartlist.cartitem;
      cart_count = cartlist.cartitem.length;
      wishlist_count = wishlist.length;
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }
        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
  //
  if (body.seller_status || body.seller_status == "0") {
    console.log("filter 7");
    productData = await model
      .find({
        seller_status: body.seller_status,
      })
      .populate("cat_id", "title image")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
    if (login_user_id) {
      if (cartlist) {
        cart_items = cartlist.cartitem;
        cart_count = cartlist.cartitem.length;
      }
      wishlist_count = wishlist.length;
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }

        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
  //service_type
  if (body.service_type) {
    console.log("filter 8");
    productData = await model
      .find({
        service_type: body.service_type,
      })
      .populate("cat_id", "title image")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
    for (i = 0; i < productData.length; i++) {
      p_data = productData[i];
      productId = p_data._id;
      if (login_user_id && wishlist) {
        wishlist.forEach(async (w_l, index) => {
          if (
            mongoose.Types.ObjectId(w_l).equals(
              mongoose.Types.ObjectId(productId)
            )
          ) {
            p_data.is_wishlist = true;
          }
        });
      }

      pRecords.push(p_data);
    }
    ResponseService.generalPayloadResponse(null, pRecords, res);
    return;
  }
  //seller_id;
  if (body.seller_id) {
    console.log("filter 9");
    productData = await model
      .find({
        seller_id: {
          $in: body.seller_id,
        },
      })
      .populate("cat_id", "title image")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
    if (login_user_id) {
      if (cartlist) {
        cart_items = cartlist.cartitem;
        cart_count = cartlist.cartitem.length;
      }

      wishlist_count = wishlist.length;
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }

        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
  //attrid;
  if (body.attrid) {
    console.log("filter 10");
    productData = await model
      .find({
        attrid: {
          $in: body.attrid,
        },
      })
      .populate("cat_id", "title image")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
    if (login_user_id) {
      cart_items = cartlist.cartitem;
      cart_count = cartlist.cartitem.length;
      wishlist_count = wishlist.length;
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }

        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
  //category id;
  if (body.cat_id) {
    console.log("filter 11");
    productData = await model
      .find({
        cat_id: {
          $in: body.cat_id,
        },
      })
      .populate("cat_id", "cat_name image")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
    if (login_user_id) {
      if (cartlist) {
        cart_items = cartlist.cartitem;
        cart_count = cartlist.cartitem.length;
      }
      if (wishlist) {
        wishlist_count = wishlist.length;
      }
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }

        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
  //community id;
  if (body.community_id) {
    console.log("filter 12");
    productData = await model
      .find({
        community_id: {
          $in: body.community_id,
        },
      })
      .populate("cat_id", "cat_name image")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic", {
        seller_profile_status: 1,
        status: 1,
      })
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });

    productData = productData.filter(
      (product) => product.seller_id != null && product.seller_id.length > 0
    );
    if (login_user_id) {
      cart_items = cartlist.cartitem;
      cart_count = cartlist.cartitem.length;
      wishlist_count = wishlist.length;
    }
    if (login_user_id || cart_count > 0 || wishlist_count > 0) {
      for (i = 0; i < productData.length; i++) {
        p_data = productData[i];
        productId = p_data._id;
        if (login_user_id && wishlist) {
          wishlist.forEach(async (w_l, index) => {
            if (
              mongoose.Types.ObjectId(w_l).equals(
                mongoose.Types.ObjectId(productId)
              )
            ) {
              p_data.is_wishlist = true;
            }
          });
        }

        pRecords.push(p_data);
      }
      ResponseService.generalPayloadResponse(null, pRecords, res);
      return;
    } else {
      ResponseService.generalPayloadResponse(null, productData, res);
      return;
    }
  }
};

exports.getBySlug = async function (req, res) {
  model = new Product();
  let slug = req.params.slug;

  let productRecords = await Product.find({ slug: slug })
    .populate("cat_id", "title image")
    .populate("color_id", "color_name color_code")
    .populate("size_id", "size_name");

  if (productRecords) {
    ResponseService.generalPayloadResponse(null, productRecords, res);
    return;
  } else {
    productData = {};
    ResponseService.generalPayloadResponse(null, productData, res);
    return;
  }
};

exports.getBySku = async function (req, res) {
  model = new Product();
  let sku = req.params.sku;

  let productRecords = await Product.find({ sku: sku }).populate(
    "cat_id",
    "title image"
  );

  if (productRecords) {
    ResponseService.generalPayloadResponse(null, productRecords, res);
    return;
  } else {
    productData = {};
    ResponseService.generalPayloadResponse(null, productData, res);
    return;
  }
};

Array.prototype.remove = function () {
  var what,
    a = arguments,
    L = a.length,
    ax;
  while (L && this.length) {
    what = a[--L];
    while ((ax = this.indexOf(what)) !== -1) {
      this.splice(ax, 1);
    }
  }
  return this;
};

exports.getById = async function (req, res) {
  model = new Product();
  let productId = req.params.id;
  let login_user_id;
  // console.log('req data',req.body);
  // console.log('login user id',req.body.login_user_id);
  // return;
  if (
    req.body.login_user_id &&
    req.body.login_user_id != null &&
    req.body.login_user_id != "undefined"
  ) {
    login_user_id = req.body.login_user_id;
    var userdata = await User.findById(login_user_id);
    var cartlist = await Cart.findOne({
      customer_id: login_user_id,
      is_active: 1,
    });
    if (userdata) wishlist = userdata.wishList;
  } else {
    login_user_id = "";
  }
  //    console.log('user wishlist',wishlist);
  //    return;
  let productRecords = await Product.findById(productId)
    .populate("cat_id", "title image")
    .populate("color_id", "color_name color_code")
    .populate("size_id", "size_name")
    .populate("creater_id", "name username email userrole profile_pic")
    .populate("community_id", "builder_name name pincode")
    .populate(
      "seller_id",
      "name business_name username email userrole profile_pic"
    );

  if (productRecords) {
    if (productRecords.attribute) var Attr = productRecords.attribute;
    else var Attr = [];

    let AttrRecord = [];
    let QRecord = [];
    var QtrArray = productRecords.qty_attr;

    if (QtrArray.length > 0) {
      for (i = 0; i < QtrArray.length; i++) {
        //console.log(QtrArray[i].qty_type);

        var qty_id = QtrArray[i].qty_type;
        //var attr_id = "5fba889b48ea8400047c99a2";
        try {
          var qdetail = await AttributeStyle.findById(qty_id);
        } catch (err) {}
        // console.log(qdetail);
        if (qdetail) QtrArray[i].qty_label = qdetail.style_name;
        else QtrArray[i].qty_label = "";
        QRecord.push(QtrArray);
      }
      productRecords.qty_attr = QRecord[0];
    } else {
      productRecords.qty_attr = [
        {
          qty_type: "",
          qty_value: "",
          qty_label: "NA",
        },
      ];
    }
    if (Attr.length > 0) {
      for (a = 0; a < Attr.length; a++) {
        // console.log(Attr[i].attrid);

        var attr_id = Attr[a].attrid;
        //var attr_id = "5fba889b48ea8400047c99a2";
        if (attr_id) {
          var detail = await Attribute.findById(attr_id);
          if (detail) Attr[a].attr_label = detail.input_name;
          else Attr[a].attr_label = "";
        }

        AttrRecord.push(Attr);
      }
      productRecords.attribute = AttrRecord[0];
    } else {
      productRecords.attribute = [];
    }
    // modifiy service based prodcut , group buy product
    multiseller = productRecords.multiseller;
    product_id = productRecords._id;
    product_type = productRecords.product_type;
    service_type = productRecords.service_type;
    s_a = [];
    seller_stock = await SellerProduct.find({ product_id: product_id });
    for (j = 0; j < seller_stock.length; j++) {
      s_data = seller_stock[j];
      var s_record = await User.findById(s_data.seller_id);
      // console.log(s_record);
      s_data.seller_name = s_record.name;
      s_data.business_name = s_record.business_name;
      s_data.profile_pic = s_record.profile_pic;
      s_data.seller_status = s_record.seller_profile_status;

      if (productRecords.is_group_buy) {
        g_pro = [];
        seller_stock = seller_stock[j];

        groupRecord = seller_stock.group_slot;
        currentDate = new Date();
        if (groupRecord) {
          for (p = 0; p < groupRecord.length; p++) {
            single_group = groupRecord[p];
            group_id = single_group._id;

            past_order = await Order.find({
              group_by_ids: { $in: group_id.toString() },
            });

            if (
              currentDate >= single_group.sell_start_date &&
              currentDate <= single_group.sell_end_date &&
              single_group.status == 1
            )
              if (single_group.product_sell < single_group.min_qty)
                g_pro.push(single_group);
          }
          s_data.group_slot = g_pro;
        }
      }
      if (service_type == "2") {
        s_r = [];
        slotRecord = seller_stock.service_day_slot;
        if (slotRecord) {
          for (p = 0; p < slotRecord.length; p++) {
            single_slot = slotRecord[p];
            slot_id = single_slot._id;
            past_order = await Order.findOne({
              slot_by_ids: {
                $in: slot_id,
              },
            });
            if (past_order.length) single_slot.product_sell = past_order.length;
            s_r.push(single_slot);
          }
          s_data.group_slot = g_pro;
        }
      }
      s_a.push(s_data);
    }
    productRecords.seller_stock = s_a;
    // check product on cart & on wishlist
    if (!login_user_id || login_user_id == "null" || login_user_id == "") {
    } else {
      // all product on cart
      if (login_user_id && wishlist) {
        wishlist.forEach(async (w_l, index) => {
          if (
            mongoose.Types.ObjectId(w_l).equals(
              mongoose.Types.ObjectId(productId)
            )
          ) {
            productRecords.is_wishlist = true;
          }
        });
      }
      if (login_user_id && cartlist) {
        cart_items = cartlist.cartitem;
        // console.log(cart_items);
        if (cart_items.length > 0) {
          cart_items.forEach(async (c_l, index) => {
            if (c_l != "null") {
              if (
                mongoose.Types.ObjectId(c_l.product_id).equals(
                  mongoose.Types.ObjectId(productId)
                )
              ) {
                productRecords.is_on_cart = true;
              }
            }
          });
        }
      }
    }
    // check with varient based product
    if (product_type == "config") {
      let otherParentProducts = await Product.find({
        parent_id: productRecords._id,
      });
      otherProducts = [];
      if (otherParentProducts.length) {
        for (i = 0; i < otherParentProducts.length; i++) {
          otherProducts[i] = otherParentProducts[i]._id;
        }
      } else {
        parent_id = productRecords.parent_id;
        if (parent_id) {
          parentProduct = await Product.findById(parent_id);
          console.log("1");
          if (parentProduct) {
            let newotherParentProducts = await Product.find({
              parent_id: parentProduct._id,
            });
            if (newotherParentProducts.length) {
              for (i = 0; i < newotherParentProducts.length; i++) {
                if (newotherParentProducts[i]._id != productId) {
                  otherProducts[i] = newotherParentProducts[i]._id;
                }
              }
            }
            otherProducts.push(parent_id);
          }
        }
      }
      otherProducts = otherProducts.filter((el) => {
        return el != null && el != "";
      });
      otherParProducts = [];
      if (otherProducts.length) {
        for (i = 0; i < otherProducts.length; i++) {
          productOtherRecords = await Product.findById(otherProducts[i])
            .populate("cat_id", "title image")
            .populate("creater_id", "name username email userrole profile_pic")
            .populate("community_id", "builder_name name pincode")
            .populate(
              "seller_id",
              "name business_name username email userrole profile_pic"
            );
          if (productOtherRecords) {
            multiseller = productOtherRecords.multiseller;
            other_product_id = productOtherRecords._id;
            product_type = productOtherRecords.product_type;
            service_type = productOtherRecords.service_type;
            if (productOtherRecords.attribute)
              var Attr = productOtherRecords.attribute;
            else var Attr = [];
            var QtrArray = productOtherRecords.qty_attr;
            let AttrRecord = [];
            let QRecord = [];
            for (q = 0; q < QtrArray.length; q++) {
              //console.log(QtrArray[i].qty_type);

              var qty_id = QtrArray[q].qty_type;
              //var attr_id = "5fba889b48ea8400047c99a2";
              try {
                var qdetail = await AttributeStyle.findById(qty_id);
              } catch (err) {}
              // console.log(qdetail);
              if (qdetail) QtrArray[q].qty_label = qdetail.style_name;
              else QtrArray[q].qty_label = "";
              QRecord.push(QtrArray);
            }
            if (Attr.length > 0) {
              for (a = 0; a < Attr.length; a++) {
                // console.log(Attr[i].attrid);

                var attr_id = Attr[a].attrid;
                //var attr_id = "5fba889b48ea8400047c99a2";
                var detail = await Attribute.findById(attr_id);
                if (detail) Attr[a].attr_label = detail.input_name;
                else Attr[a].attr_label = "";
                AttrRecord.push(Attr);
              }
            }
            productOtherRecords.attribute = AttrRecord[0];
            productOtherRecords.qty_attr = QRecord[0];
            s_a = [];
            seller_stock = await SellerProduct.find({
              product_id: other_product_id,
            });
            for (j = 0; j < seller_stock.length; j++) {
              s_data = seller_stock[j];
              var s_record = await User.findById(s_data.seller_id);
              // console.log(s_record);
              s_data.seller_name = s_record.name;
              s_data.business_name = s_record.business_name;
              s_data.profile_pic = s_record.profile_pic;
              s_data.seller_status = s_record.seller_profile_status;

              if (productOtherRecords.is_group_buy) {
                g_pro = [];
                groupRecord = seller_stock.group_slot;
                if (groupRecord) {
                  for (p = 0; p < groupRecord.length; p++) {
                    single_group = groupRecord[p];
                    group_id = single_group._id;
                    past_order = await Order.findOne({
                      group_by_ids: {
                        $in: group_id,
                      },
                    });
                    if (past_order.length)
                      single_group.product_sell = past_order.length;
                    g_pro.push(single_group);
                  }
                  s_data.group_slot = g_pro;
                }
              }
              if (service_type == "2") {
                s_r = [];
                slotRecord = seller_stock.service_day_slot;
                if (slotRecord) {
                  for (p = 0; p < slotRecord.length; p++) {
                    single_slot = slotRecord[p];
                    slot_id = single_slot._id;
                    past_order = await Order.findOne({
                      slot_by_ids: {
                        $in: slot_id,
                      },
                    });
                    if (past_order.length)
                      single_slot.product_sell = past_order.length;
                    s_r.push(single_slot);
                  }
                  s_data.group_slot = g_pro;
                }
              }
              s_a.push(s_data);
            }
            productOtherRecords.seller_stock = s_a;
            // check product on cart & on wishlist
            if (
              !login_user_id ||
              login_user_id == "null" ||
              login_user_id == ""
            ) {
            } else {
              // all product on cart
              if (login_user_id && wishlist) {
                wishlist.forEach(async (w_l, index) => {
                  if (
                    mongoose.Types.ObjectId(w_l).equals(
                      mongoose.Types.ObjectId(productId)
                    )
                  ) {
                    productOtherRecords.is_wishlist = true;
                  }
                });
              }
              if (login_user_id && cartlist) {
                cart_items = cartlist.cartitem;
                // console.log(cart_items);
                if (cart_items.length > 0) {
                  cart_items.forEach(async (c_l, index) => {
                    if (c_l != "null") {
                      if (
                        mongoose.Types.ObjectId(c_l.product_id).equals(
                          mongoose.Types.ObjectId(productId)
                        )
                      ) {
                        productOtherRecords.is_on_cart = true;
                      }
                    }
                  });
                }
              }
            }
          }
          otherParProducts.push(productOtherRecords);
        }
      }
      productRecords.otherProducts = otherParProducts;
    }
    // reviews list
    let reviewdata = await Review.find({ product_id: productId }).populate(
      "user_id",
      "name username email userrole profile_pic"
    );
    productRecords.reviews = reviewdata;
    console.log(productRecords);

    ResponseService.generalPayloadResponse(null, productRecords, res);
    return;
  } else {
    console.log("else case");
    productData = {};
    ResponseService.generalPayloadResponse(null, productData, res);
    return;
  }
};
async function getCommData(sellerid) {
  let community_ids;

  let userData = await User.findById(sellerid);

  if (userData.community_id.length) {
    community_ids = userData.community_id;
  }

  return community_ids;
}

exports.checkSlug = async function (req, res) {
  model = new Product();

  let slug = req.body.slug;

  let productRecords = await Product.find({ slug: slug }).populate(
    "cat_id",
    "title image"
  );

  let Response;

  if (productRecords.length) {
    Response = {
      isExists: true,
      msg: "Slug already exists in Database",
    };
  } else {
    Response = {
      isExists: false,
      msg: "Slug not exists in Database",
    };
  }

  ResponseService.generalPayloadResponse(null, Response, res);
  return;
};

function iterate(item) {
  return item;
}
// group by update
exports.groupupdate = async function (req, res) {
  model = new Product();
  const body = req.body;
  if (
    req.params.id &&
    body.seller_id &&
    req.body.product_id &&
    req.body.group_id
  ) {
    let product_id = req.body.product_id;
    let seller_id = body.seller_id;
    var pdetail = await Product.findById(product_id);
    if (pdetail) {
      sellerstock = await SellerProduct.findOne({
        seller_id: seller_id,
        product_id: product_id,
      });
      if (sellerstock) {
      } else {
        Response = "Invalid Stock id";
        ResponseService.generalPayloadResponse(null, Response, res);
        return;
      }
    } else {
      Response = "Invalid Product id";
      ResponseService.generalPayloadResponse(null, Response, res);
      return;
    }
  } else {
    Response = "missing required parameter";
    ResponseService.generalPayloadResponse(null, Response, res);
    return;
  }
};
// add stock
exports.addstock = async function (req, res) {
  model = new Product();
  const body = req.body;
  if (req.body.product_id) {
    let product_id = req.body.product_id;
    let pending_stock = body.add_item;
    let min_stock = body.min_stock;
    let parentPath = [];
    let Response = "";
    var pdetail = await Product.findById(product_id);
    if (pdetail) {
      sellerstock = await SellerProduct.findOne({
        seller_id: seller_id,
        product_id: product_id,
      });
      console.log(sellerstock);
      if (sellerstock) {
        seller_Stock_id = sellerstock._id;
        if (seller_Stock_id == req.params.id) {
          if (body.pending_stock > 0) {
            current_stock = sellerstock.pending_stock;
            var updated_stock = current_stock + pending_stock;
            stock_data = {
              stock_value: body.pending_stock,
              s_type: "in",
              comment: "Stock updated",
              creater_id: body.seller_id,
            };
          }
          p_seller_data = pdetail.seller_id;
          first_seller_id = p_seller_data[0];

          if (body.min_stock) sellerstock.min_stock = body.min_stock;
          if (body.price) sellerstock.price = body.price;
          if (body.special_price)
            sellerstock.special_price = body.special_price;
          if (body.pending_stock > 0) {
            sellerstock.pending_stock = updated_stock;
          }
          if (body.comment) {
            comment = body.comment;
          } else {
            comment = "Stock Updated";
          }
          sellerstock.save((err, result) => {
            console.log("Seller info update");
          });
          if (body.pending_stock > 0) {
            stock_data = {
              stock_value: body.pending_stock,
              s_type: "in",
              comment: comment,
              creater_id: body.seller_id,
            };
            query = {};
            if (stock_data) {
              query.$push = {
                stock_data: stock_data,
              };
            }
            SellerProduct.findByIdAndUpdate(
              seller_Stock_id,
              query,
              {
                new: true,
              },
              (err, doc) => {
                console.log("Stock updated");
              }
            );
          } else {
            stock_data = {};
          }

          if (first_seller_id == seller_id) {
            // update pending stock of product table too
            let current_stock_data = pdetail.stock_data;
            pdetail.stock_data = stock_data;
            if (body.pending_stock) {
              pdetail.pending_stock = updated_stock;
            }
            if (body.price) pdetail.price = body.price;
            if (body.special_price) pdetail.special_price = body.special_price;
            pdetail.save((err, result) => {
              if (body.pending_stock) {
                query = {};
                if (stock_data) {
                  query.$push = {
                    stock_data: stock_data,
                  };
                }
                Product.findByIdAndUpdate(
                  product_id,
                  query,
                  {
                    new: true,
                  },
                  (err, doc) => {}
                );
              }
            });
          }
          var pdetail = await Product.findById(product_id);
          ResponseService.generalPayloadResponse(null, pdetail, res);
          return;
        } else {
          Response = "Invalid Seller Stock id";
          ResponseService.generalPayloadResponse(null, Response, res);
          return;
        }
      } else {
        Response = "Invalid Stock id";
        ResponseService.generalPayloadResponse(null, Response, res);
        return;
      }
    } else {
      Response = "Invalid Product id";
      ResponseService.generalPayloadResponse(null, Response, res);
      return;
    }
  } else {
    Response = "missing required parameter";
    ResponseService.generalPayloadResponse(null, Response, res);
    return;
  }
};
exports.add = async function (req, res) {
  var body = req.body;
  seller_product = req.body.seller_product;
  seller_id = body.seller_id;
  if (body.status || body.status == 0) status = body.status;
  else status = 1;
  if (body.seller_status || body.seller_status == 0) {
    seller_status = body.seller_status;
  } else {
    seller_status = 1;
  }

  let productsku;

  if (body.sku) {
    productsku = body.sku;
  } else {
    productsku = CRUD.alphaId();
  }

  var customSlug;
  var d = new Date();
  var time = d.getTime();

  if (body.slug) {
    //check slug exists or not

    let productData = await Product.find({ slug: body.slug });
    let existsData = productData[0];

    if (productData.length) {
      customSlug = existsData.slug + "-" + time;
    } else {
      customSlug = body.slug;
    }
  } else {
    customSlug = CRUD.convertToSlug(body.product_en);
    let productData = await Product.find({ slug: customSlug });
    let existsData = productData[0];

    if (productData.length) {
      customSlug = existsData.slug + "-" + time;
    } else {
      customSlug = customSlug + "-" + time;
    }
  }
  if (body.attribute == "") {
    body.attribute = {
      attrid: "",
      value: "",
    };
  }
  params = {
    product_en: body.product_en,
    product_hn: body.product_hn,
    slug: customSlug,
    sku: productsku,
    icon: body.icon,
    pictures: body.pictures,
    description: body.description,
    cat_id: body.cat_id,
    color_id: body.color_id,
    size_id: body.size_id,
    is_recommmend: body.is_recommmend,
    is_trending: body.is_trending,
    is_topoffer: body.is_topoffer,
    community_id: body.community_id,
    service_type: body.service_type,
    product_type: body.product_type,
    seller_id: seller_id,
    creater_id: body.creater_id,
    video: body.video,
    qty_attr: body.qty_attr,
    attribute: body.attribute,
    price: body.price,
    special_price: body.special_price,
    qty: body.qty,
    pending_stock: body.qty,
    min_stock: body.min_stock,
    parent_id: body.parent_id,
    fetchParentInfo: body.fetchParentInfo,
    config_attr: body.config_attr,
    policy_text: body.policy_text,
    policy_image: body.policy_image,
    attributeStyleId: body.attributeStyleId,
    status: status,
    seller_status: seller_status,
    delivery_time: body.delivery_time,
    delivery_slot: body.delivery_slot,
    shippingCost: body.shippingCost,
    tax: body.tax,
  };
  model = Product;

  product = new model(params);

  product.save(function (err, val) {
    if (err) {
      console.log(err);
    } else {
      //seller data with product we add here
      if (body.qty) {
        stock_data = {
          stock_value: body.qty,
          s_type: "in",
          comment: "New product Added",
        };
        if (!body.shippingCost) body.shippingCost = 0;
        if (!body.tax) body.tax = 0;
      }
    }
    ResponseService.generalPayloadResponse(err, val, res);
  });
  // ResponseService.generalPayloadResponse(null,'', res);
};

exports.updateProductByid = async function (req, res) {
  model = new Product();
  let product_id = req.params.id;
  const body = req.body;
  let parentArr = body.parent_id;
  let parentPath = [];

  var saveRecords = await Product.findById(product_id)
    .populate("cat_id", "cat_name image")
    .populate("community_id", "name pincode")
    .populate("seller_id", "name username email userrole profile_pic")
    .populate("creater_id", "name username email userrole profile_pic");
  if (req.body.product_en) {
    saveRecords.product_en = req.body.product_en;
  }
  if (req.body.product_hn) {
    saveRecords.product_hn = req.body.product_hn;
  }
  if (req.body.add_item > 0) {
    StockQuery = {};
    StockQuery.$addToSet = {
      stock_data: {
        stock_value: req.body.add_item,
        s_type: "in",
        creater_id: req.body.creater_id,
      },
    };
    await Product.findByIdAndUpdate(product_id, StockQuery, { new: true });
    // stock update
    // old stock value
    //    console.log(saveRecords);
    var old_stock = saveRecords.pending_stock;
    saveRecords.pending_stock = old_stock + req.body.add_item;
  }
  if (req.body.price) {
    saveRecords.price = req.body.price;
  }
  if (req.body.special_price) {
    saveRecords.special_price = req.body.special_price;
  }
  if (req.body.sku) {
    saveRecords.sku = req.body.sku;
  }
  if (req.body.status || req.body.status == 0) {
    saveRecords.status = req.body.status;
  }
  if (req.body.seller_status || req.body.seller_status == 0) {
    saveRecords.seller_status = req.body.seller_status;
  }
  if (req.body.icon) {
    saveRecords.icon = req.body.icon;
  }
  if (req.body.description) {
    saveRecords.description = req.body.description;
  }

  if (req.body.is_recommmend) {
    saveRecords.is_recommmend = req.body.is_recommmend;
  }
  if (req.body.is_trending) {
    saveRecords.is_trending = req.body.is_trending;
  }
  if (req.body.is_topoffer) {
    saveRecords.is_topoffer = req.body.is_topoffer;
  }
  if (req.body.cat_id) {
    saveRecords.cat_id = req.body.cat_id;
  }
  if (req.body.pictures) {
    saveRecords.pictures = req.body.pictures;
  }
  if (req.body.creater_id) {
    saveRecords.creater_id = req.body.creater_id;
  }
  if (req.body.shippingCost) {
    saveRecords.shippingCost = req.body.shippingCost;
  }
  if (req.body.tax) {
    saveRecords.tax = req.body.tax;
  }
  if (req.body.sellerid) {
    saveRecords.sellerid = req.body.sellerid;
  }
  if (req.body.seller_id) {
    saveRecords.seller_id = req.body.seller_id;
  }
  if (req.body.attribute) {
    saveRecords.attribute = req.body.attribute;
  }
  seller_field_update = false;
  if (req.body.price) {
    saveRecords.price = req.body.price;
    seller_field_update = true;
  }
  if (req.body.special_price) {
    saveRecords.special_price = req.body.special_price;
    seller_field_update = true;
  }
  if (req.body.qty) {
    saveRecords.qty = req.body.qty;
  }
  if (req.body.min_stock) {
    saveRecords.min_stock = req.body.min_stock;
    seller_field_update = true;
  }
  if (req.body.policy_text) {
    saveRecords.policy_text = req.body.policy_text;
  }
  if (req.body.policy_image) {
    saveRecords.policy_image = req.body.policy_image;
  }
  if (req.body.attributeStyleId) {
    saveRecords.attributeStyleId = req.body.attributeStyleId;
  }
  if (req.body.product_type) {
    saveRecords.product_type = req.body.product_type;
  }
  if (req.body.video) {
    saveRecords.video = req.body.video;
  }
  if (req.body.qty_attr) {
    saveRecords.qty_attr = req.body.qty_attr;
  }
  if (req.body.service_day_slot) {
    // update service day slot for all seller
    seller_id = saveRecords.seller_id[0]._id;
    product_id = saveRecords._id;
    if (seller_id) {
      seller_stock = await SellerProduct.findOne({
        product_id: product_id,
        seller_id: seller_id,
      });
      seller_stock_id = seller_stock._id;

      query = {
        service_day_slot: req.body.service_day_slot,
      };
      SellerProduct.findByIdAndUpdate(
        seller_stock_id,
        query,
        { new: true },
        (err, doc) => {
          console.log("Servce data updated");
        }
      );
    }
  }

  saveRecords.save((err, result) => {
    ResponseService.generalPayloadResponse(err, saveRecords, res);
  });
  // Category.findByIdAndUpdate(categoryid, saveRecords, { new: true }, (err, doc) => {
  //     ResponseService.generalPayloadResponse(err, saveRecgerords, res, undefined, "Updated");
  // });
};
const unique = Math.floor(100000 + Math.random() * 900000);

exports.productlist = async function (query, limit, page, type, body, res) {
  limit = 1000;
  const model = Product;
  if (body.status == "") body.status = 1;
  productRecord = await model
    .find({ status: 1 })
    .populate("cat_id", "title image")
    .populate("creater_id", "name username email userrole profile_pic")
    .populate("community_id", "builder_name name pincode")
    .populate("seller_id", "name username email userrole profile_pic")
    .skip(page * limit)
    .limit(limit)
    .sort({ _id: -1 });
  console.log(body);

  //  console.log(body.cat_id);
  if (body.cat_id) {
    let CategoryData = await Category.findById(body.cat_id);

    let SubcategoryData = await Category.find({
      parent_id: { $in: body.cat_id },
    });

    let CategoryArr = [body.cat_id];
    if (SubcategoryData.length) {
      for (i = 0; i < SubcategoryData.length; i++) {
        CategoryArr.push(SubcategoryData[i].cat_id);
      }
    }
    console.log(CategoryArr);
    productRecord = await model
      .find({
        cat_id: {
          $in: body.cat_id,
        },
      })
      .populate("cat_id", "title image")
      .populate("creater_id", "name username email userrole profile_pic")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
  }
  p_list = [];
  wishlist = [];
  cartlist = [];
  login_user_id = body.login_user_id;
  if (login_user_id) {
    var userdata = await User.findById(login_user_id);
    var cartlist = await Cart.findOne({
      customer_id: login_user_id,
      is_active: 1,
    });
    if (userdata) {
      if (userdata.wishList) wishlist = userdata.wishList;
    }
  }
  for (j = 0; j < productRecord.length; j++) {
    s_a = [];
    p_data = productRecord[j];
    if (login_user_id) {
      if (login_user_id && wishlist) {
        wishlist.forEach(async (w_l, index) => {
          if (
            mongoose.Types.ObjectId(w_l).equals(
              mongoose.Types.ObjectId(p_data._id)
            )
          ) {
            p_data.is_wishlist = true;
          }
        });
      }
      if (login_user_id && cartlist) {
        p_data.is_on_cart = true;
      }
    }

    pro_id = productRecord[j]["_id"];
    seller_stock = await SellerProduct.find({ product_id: pro_id });
    if (seller_stock) {
      for (k = 0; k < seller_stock.length; k++) {
        s_data = seller_stock[k];
        var s_record = await User.findById(s_data.seller_id);
        // console.log(s_record);
        s_data.seller_name = s_record.name;
        s_data.business_name = s_record.business_name;
        s_data.profile_pic = s_record.profile_pic;
        s_a.push(s_data);
      }
      p_data.seller_stock = seller_stock;
    } else {
      p_data.seller_stock = [];
    }
    p_list.push(p_data);

    productRecord.seller_stock = s_a;
  }
  ResponseService.generalPayloadResponse(null, productRecord, res);

  return;
};
// seller wise stock list
exports.sellerwisestock = async function (query, limit, page, type, body, res) {
  let productData;
  const model = SellerProduct;
  //status
  if (body.status || body.status == "0") {
    productData = await model
      .find({
        status: body.status,
      })
      .populate("product_id", "product_en product_hn sku icon pictures")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
  }
  if ((body.status || body.status == "0") && body.seller_id) {
    productData = await model
      .find({
        status: body.status,
        seller_id: body.seller_id,
      })
      .populate("product_id", "product_en product_hn sku icon pictures")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
  }
  if ((body.status || body.status == "0") && body.product_id) {
    productData = await model
      .find({
        status: body.status,
        product_id: body.product_id,
      })
      .populate("product_id", "product_en product_hn sku icon pictures")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
  }
  if (
    (body.status || body.status == "0") &&
    body.product_id &&
    body.seller_id
  ) {
    productData = await model
      .find({
        status: body.status,
        product_id: body.product_id,
        seller_id: body.seller_id,
      })
      .populate("product_id", "product_en product_hn sku icon pictures")
      .populate("community_id", "builder_name name pincode")
      .populate("seller_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });
  }
  ResponseService.generalPayloadResponse(null, productData, res);
  return;
};
