const asyncHandler = require("../shared/middleware/async");
const User = require("../models/User");
const ResponseService = require("../shared/ResponseService");
const Product = require("../models/Product");
const Review = require("../models/Review");
const Order = require("../models/Order");
const moment = require('moment-timezone');

exports.addReview = asyncHandler(async(req, res, next) => {

    body = req.body;

    if (body.product_id && body.order_id && body.user_id) {

        const user = await User.findById(body.user_id);

        if (!user)
            return ResponseService.generalResponse("The User doesnt exist", res, 404);

        const product = await Product.findById(body.product_id);

        if (!product) {
            return ResponseService.generalResponse("The Product doesnt exist", res, 404);
        }

        const order = await Order.findById(body.order_id);

        if (!order) return ResponseService.generalResponse("This Order doesnt exist", res, 404);

        let existInOrder = false;

        for (o of order.cartitem) {
            if (o.product_id == body.product_id) existInOrder = true;
        }

        if (!existInOrder) return ResponseService.generalResponse("THis product doesnt exist in this order", res, 404);

        if (order.customer_id != body.user_id)
            return ResponseService.generalResponse("You cannot review orders which you havent placed", res, 404);

        let past_review = await Review.findOne({ product_id: body.product_id, order_id: body.order_id, user_id: body.user_id });

        if (past_review != null) return ResponseService.generalResponse("Review has already been placed by this user on this product", res, 404);

        const review = (await Review.create(body)).populate('user_id', 'name email mobile_no').populate('product_id', 'product_en description');

        if (!review)
            return ResponseService.generalResponse("The Review could not be created", res, 404);

        order.is_reviewed = true;
        order.save();

        return ResponseService.generalPayloadResponse(null, review, res);
    } else
        return ResponseService.generalResponse(null, res, 404, "Required Parameter missing");
});

exports.deleteReview = asyncHandler(async(req, res, next) => {

    // Check if review is in the database
    const review = await Review.findById(req.params.id);

    // If the review is not in the database then throw error
    if (!review) {
        return ResponseService.generalResponse(`There is no review available with the id of ${req.params.id}`, res, 404);
    }

    await Review.findByIdAndRemove(req.params.id);

    return ResponseService.generalResponse(null, res);

})

exports.getAllReview = asyncHandler(async(req, res, next) => {

    filters = req.query;

    if (filters.product_id) {
        const product = await Product.findById(filters.product_id);

        if (!product)
            return ResponseService.generalResponse("This product doesnt exist", res, 404);
    }
    const reviews = await Review.find(filters).populate('user_id', 'name email mobile_no profile_pic').populate('product_id', 'product_en description').populate('order_id');
    star1 = 0;
    star2 = 0;
    star3 = 0;
    star4 = 0;
    star5 = 0;

    r_s = {};
    if (reviews.length == 0) {
        return ResponseService.generalResponse("No reviews for this product exist of this selection.", res, 404);

    } else {
        star1 = await Review.find({ "product_id": filters.product_id, "rating": 1 }).count();
        star2 = await Review.find({ "product_id": filters.product_id, "rating": 2 }).count();
        star3 = await Review.find({ "product_id": filters.product_id, "rating": 3 }).count();
        star4 = await Review.find({ "product_id": filters.product_id, "rating": 4 }).count();
        star5 = await Review.find({ "product_id": filters.product_id, "rating": 5 }).count();
        let Records = [];
        reviews.forEach(async(data, index) => {
            data.createdTime = moment(data.created_date).fromNow(true);
            await Records.push(data);
        });
        r_s = {
            "reviews": Records,
            "star1": star1,
            "star2": star2,
            "star3": star3,
            "star4": star4,
            "star5": star5,
        };
    }


    return ResponseService.generalPayloadResponse(null, r_s, res);

});

exports.getReviewById = asyncHandler(async(req, res, next) => {
    const review = await Review.findById(req.params.id).populate('user_id', 'name email mobile_no').populate('product_id', 'product_en description').populate('order_id');

    return ResponseService.generalPayloadResponse(null, review, res);
});