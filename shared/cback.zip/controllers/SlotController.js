const ResponseService = require('../shared/ResponseService'); // Response service
const Slot = require('../models/Slot'); // Attr option model
const User = require('../models/User'); // Attr option model
const CRUD = require('../shared/CRUD');
const moment = require('moment-timezone');
// var dateFormat = require('dateformat');
const querystring = require("querystring");
const axios = require("axios");
exports.getById = async function(req, res) {
    model = new Slot;
    let SlotId = req.params.id;
    let SlotRecords = await Slot.findById(SlotId)
        .populate('event_id', "title description  slug start_date end_date pictures").populate('seller_id', "username name profile_pic");


    SlotRecords.createdTime = moment(SlotRecords.created_date).fromNow(true);
    start_time = SlotRecords.start_date;
    end_date = SlotRecords.end_date;
    // SlotRecords.start_date = dateFormat(start_time, "dd mmm yyyy h:MM tt");
    // SlotRecords.end_date = dateFormat(end_date, "dd mmm yyyy h:MM tt");

    let loggedInUser;
    let userRecord;
    if (req.body.login_userid) {
        loggedInUser = req.body.login_userid;
        userRecord = await User.findById(loggedInUser);

    } else {
        loggedInUser = '';
    }

    if (SlotRecords) {
        ResponseService.generalPayloadResponse(null, SlotRecords, res);
        return;
    } else {
        SlotRecords = {};
        ResponseService.generalPayloadResponse(null, SlotRecords, res);
        return;
    }

}
exports.getBySlug = async function(req, res) {
    model = new Slot;
    let slug = req.params.slug;
    let SlotRecords = await Slot.find({ "slug": slug }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").populate('seller_id', "username name profile_pic");
    // console.log(BlogRecords);
    SlotRecords.createdTime = moment(SlotRecords.created_date).fromNow(true);
    let loggedInUser;
    let userRecord;
    if (req.body.login_userid) {
        loggedInUser = req.body.login_userid;
        userRecord = await User.findById(loggedInUser);

    } else {
        loggedInUser = '';
    }

    if (SlotRecords) {
        ResponseService.generalPayloadResponse(null, SlotRecords, res);
        return;
    } else {
        SlotRecords = {};
        ResponseService.generalPayloadResponse(null, SlotRecords, res);
        return;
    }

}
exports.updateByid = async function(req, res) {
    model = new Slot;
    let slot_id = req.params.id
    const body = req.body;
    var saveRecords = await Slot.findById(slot_id).populate('seller_id', "username name profile_pic mobile_no");

    if (req.body.community_id) {
        saveRecords.community_id = req.body.community_id;
    }
    if (req.body.pictures) {
        saveRecords.pictures = req.body.pictures;
    }
    if (req.body.status) {
        saveRecords.status = req.body.status;
    }
    if (req.body.seller_register_stauts) {
        seller_register_stauts = req.body.seller_register_stauts;
        saveRecords.seller_register_stauts = req.body.seller_register_stauts;
        seller_Data = saveRecords.seller_id;
        seller_mobile_no = seller_Data[0].mobile_no;

        if (seller_register_stauts == "accepted") {
            sms_str = "Request For  -" + saveRecords.title + " is " + saveRecords.seller_register_stauts;
        }
        if (seller_mobile_no && req.body.seller_register_stauts && sms_str) {
            console.log(sms_str);
            res2 = await sendotp(sms_str, seller_mobile_no);
        }
    }
    if (req.body.charges_type) {
        saveRecords.charges_type = req.body.charges_type;
    }
    if (req.body.isBooked) {
        saveRecords.isBooked = req.body.isBooked;
    }
    if (req.body.accepted_detail) {
        saveRecords.accepted_detail = req.body.accepted_detail;
    }
    if (req.body.seller_id) {
        saveRecords.seller_id = req.body.seller_id;
    }
    if (req.body.start_date) {
        saveRecords.start_date = req.body.start_date;
    }
    if (req.body.end_date) {
        saveRecords.end_date = req.body.end_date;
    }
    if (req.body.charges_amount) {
        saveRecords.charges_amount = req.body.charges_amount;
    }
    if (req.body.location) {
        saveRecords.location = req.body.location;
    }
    if (req.body.title) {
        saveRecords.title = req.body.title;
    }
    if (req.body.description) {
        saveRecords.description = req.body.description;
    }
    if (req.body.total_amount) {
        saveRecords.total_amount = req.body.total_amount;
    }
    if (req.body.created_date) {
        saveRecords.created_date = req.body.created_date;
    }
    saveRecords.save((err, result) => {

        ResponseService.generalPayloadResponse(err, saveRecords, res);
    });
}
exports.add = async function(req, res) {

    body = req.body;
    var d = new Date();
    var time = d.getTime();
    start_date = req.body.start_date;
    end_date = req.body.end_date;
    // 1- fixed , 2- daily 3- hourly 
    charges_type = req.body.charges_type;
    if (charges_type == 1)
        total_amount = req.body.charges_amount;
    else if (charges_type == 2) {
        var startDate = moment(new Date(start_date), "DD.MM.YYYY");
        var endDate = moment(new Date(end_date), "DD.MM.YYYY");
        var day_differ = endDate.diff(startDate, 'days');
        console.log(day_differ);
        total_amount = req.body.charges_amount * day_differ;
    }

    req.body.total_amount = total_amount;
    const model = new Slot(req.body);
    let SlotData = await model.save();
    ResponseService.generalPayloadResponse(null, SlotData, res);
    return;

}

exports.list = async function(query, limit, page, type, body, res) {
    const model = Slot;
    var SlotData;
    if (body.leader_id && body.leader_id != "601a9de26b1138356002a5e9") {
        var userdata = await User.findById(body.leader_id);
        user_community_ids = userdata.community_id;
        SlotData = await model.find({
                "community_id": {
                    $in: user_community_ids
                },
                "status": 1
            })
            .populate('seller_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
        ResponseService.generalPayloadResponse(null, SlotData, res);
        return;

    }
    SlotData = await model.find().populate('event_id', "title slug start_date end_date").populate('seller_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
    //console.log(page);
    currentDate = new Date();
    console.log(currentDate);
    if (body.community_id && body.status && body.seller_register_status) {

        SlotData = await model.find({
                "community_id": {
                    $in: body.community_id
                },
                "status": 1,
                "isBooked": true,
                "seller_register_stauts": body.seller_register_status
            })
            .populate('seller_id', ['name', 'seller_profile_status', 'username', 'email', 'userrole', 'profile_pic'], { seller_profile_status: 1, status: 1 }).skip(page * limit).limit(limit).sort({ _id: -1 });

        SlotData = SlotData.filter(slot => (slot.seller_id != null && slot.seller_id.length != 0) && (new Date(slot.end_date) > currentDate));
        ResponseService.generalPayloadResponse(null, SlotData, res);
        return;

    }
    if (body.community_id && (body.isBooked || body.isBooked == false)) {
        // booked false case means seller has to register 
        SlotData = await model.find({
                "community_id": {
                    $in: body.community_id
                },
                "status": 1,
                "isBooked": body.isBooked
            })
            .populate('seller_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
        ResponseService.generalPayloadResponse(null, SlotData, res);
        return;

    }
    if (body.community_id) {
        SlotData = await model.find({
                "community_id": {
                    $in: body.community_id
                },
                "status": 1
            })
            .populate('seller_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
        ResponseService.generalPayloadResponse(null, SlotData, res);
        return;

    }
    if (body.seller_id) {
        SlotData = await model.find({
                "seller_id": {
                    $in: body.seller_id
                },
                "status": 1
            })
            .populate('seller_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
        ResponseService.generalPayloadResponse(null, SlotData, res);
        return;

    }
    SlotData = await model.find({})
        .populate('seller_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
    ResponseService.generalPayloadResponse(null, SlotData, res);
    return;
}

exports.share = async function(id, res) {
    const model = Slot;

    var SlotData = await model.findById(id);
    SlotData.share_count = SlotData.share_count + 1;

    SlotData.save(function(err, result) {
        if (err) {
            ResponseService.generalResponse("Something went wrong, please try again.", result, 401, "Something went wrong, please try again");
            return;
        } else {
            ResponseService.generalPayloadResponse(err, result, res);
            return;
        }
    });
}
exports.sellerregister = async function(req, res) {
    body = req.body;
    seller_id = body.seller_id;
    slot_id = body.slot_id;
    if (seller_id && slot_id) {
        let slot_record = await Slot.findOne({ "_id": slot_id });

        if (slot_record && slot_record.isBooked == false && slot_record.seller_register_stauts == "pending") {

            query = {};
            query.$addToSet = { seller_id: seller_id }
            Slot.findByIdAndUpdate(slot_id, query, { new: true }, (err, doc) => {
                slot_record.isBooked = true;
                slot_record.seller_register_stauts = 'requested';
                if (body.title)
                    slot_record.title = body.title;
                if (body.desc)
                    slot_record.description = body.desc;
                if (body.pictures)
                    slot_record.pictures = body.pictures;
                slot_record.save((err, result) => {
                    ResponseService.generalPayloadResponse(null, slot_record, res);
                });

            })

        } else {
            ResponseService.generalResponse("InvaliD slot Data.", res, 404, "Invalid slot Data.");
            return;

        }

    } else {
        ResponseService.generalResponse("Required Parameter is missing.", res, 404, "Required Parameter is missing.");
        return;
    }
}
async function sendotp(message, mobile_no) {
    const ApiUserName = "Ravikanth";
    const ApiUserPassword = "SMS@Pass1";
    const ApiUserSenderId = "SPRNBR";
    const ApiUrl = "https://login.bulksmsgateway.in/sendmessage.php?";

    const type = 3;
    const Newapi = {
        user: ApiUserName,
        password: ApiUserPassword,
        sender: ApiUserSenderId,
        type: 3,
    };

    var number = mobile_no;
    // const message="Now Regi";
    // console.log(req.query);
    var config = {
        method: "GET",
        url: `${ApiUrl}${querystring.stringify(Newapi)}` +
            "&mobile=" +
            number +
            "&" +
            querystring.stringify({
                message: message,
            }),
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        },
    };
    return new Promise((resolutionFunc, rejectionFunc) => {
        axios(config)
            .then((results) => {
                // console.log(results);
                var res2 = {
                    status: 200,
                };
                resolutionFunc(res2);
            })
            .catch((err) => {
                // console.log(err);
                rejectionFunc(err);
            });
    });
}