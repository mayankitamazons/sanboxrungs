const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model

const Category = require('../models/Category'); // Topic model

const CRUD = require('../shared/CRUD');

exports.categoryList = function (query, limit, page, type, res) {
    const model = Category;

    model.find(query, (err, doc) => {

        ResponseService.generalPayloadResponse(err, doc, res);
    }).populate("lang", "title icon").skip(page * limit).limit(limit).sort({_id: -1});
}

exports.categorylist = async function (query, limit, page, type, body, res) {
     // category list has filter of sub category id, isTredning, Creator id
    const model = Category;
    var CategoryData;
    if (body.isTrending) {
        CategoryData = await model.find({isTrending:true});
    }
    if (body.creater_id) {
        CategoryData = await model.find({creater_id:true});
    }
    if (body.status) {
        CategoryData = await model.find({status:body.status});
    }
    ResponseService.generalPayloadResponse(null, CategoryData, res);
}