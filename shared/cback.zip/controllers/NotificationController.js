const ResponseService = require('../shared/ResponseService'); // Response service


// Notification service
const NotificationService = require('../shared/NotificationService')

// User model
const User = require('../models/User')

exports.callNotification = function(req, res) {
    User.findById(req.body.receiver_id, async(err, doc) => {
        if (err) {
            ResponseService.generalResponse(err, res);
        } else {
            const result = await NotificationService.sendToUserList(`${req.body.name} is calling you!`, "Ring...", doc.notification_id, req.body);
            if (result.status) {

            } else {
                console.log(result);
                ResponseService.generalResponse("Error occured!", res, 500, "Error occured!");
            }
        }
    })
}

exports.callEndNotification = function(req, res) {
    User.findById(req.body.receiver_id, async(err, doc) => {
        if (err) {
            ResponseService.generalResponse(err, res);
        } else {
            const result = await NotificationService.sendToUserList("You call has been ended!", "Hang up", doc.notification_id, { type: "ending" });
            if (result.status) {
                ResponseService.generalResponse(err, res, 200, "Notification sent");
            } else {
                console.log(result);
                ResponseService.generalResponse("Error occured!", res, 500, "Error occured!");
            }
        }
    })
}