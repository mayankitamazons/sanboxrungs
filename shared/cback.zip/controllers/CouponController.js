const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model

const CRUD = require('../shared/CRUD');
const Product = require('../models/Product');
const Attribute = require('../models/Attribute');
const Cart = require('../models/Cart');
const { compareSync } = require('bcryptjs');
const Coupon = require('../models/Coupon');
// var dateFormat = require('dateformat');


exports.add = async function(req, res) {

    var body = req.body;
    model = Coupon;
    coupon_code = body.coupon_code;
    body.coupon_code = coupon_code.toUpperCase();
    result = new model(body);
    result.save(function(err, val) {
        if (err) {
            data = err;
            console.log("Some error are there");
        } else {
            data = val;
            console.log("Coupon added successfully");
        }
        ResponseService.generalPayloadResponse(null, data, res);
    });
}
exports.assignuser = async function(req, res) {
    var body = req.body;
    if (body.coupon_id && body.assign_user_id) {
        saveRecords = await Coupon.findById(body.coupon_id);
        if (saveRecords) {

            query = {};
            query.$addToSet = { assigned_user_id: body.assign_user_id };
            Coupon.findByIdAndUpdate(saveRecords, query, { new: true }, (err, doc) => {
                var msg = "User Assing successfully";
                ResponseService.generalPayloadResponse(null, msg, res);
                return;

            });
        } else {
            var msg = "Invalid Coupon Id";
            ResponseService.generalPayloadResponse(null, msg, res);
            return;
        }
    } else {
        var msg = "Invalid Access";
        ResponseService.generalPayloadResponse(null, msg, res);
        return;
    }
}
exports.removeuser = async function(req, res) {
    var body = req.body;
    if (body.coupon_id && body.assign_user_id) {
        saveRecords = await Coupon.findById(body.coupon_id);
        if (saveRecords) {

            query = {};
            query.$unset = { assigned_user_id: body.assign_user_id };
            Coupon.findByIdAndUpdate(saveRecords, query, { new: true }, (err, doc) => {
                var msg = "User Removed successfully";
                ResponseService.generalPayloadResponse(null, msg, res);
                return;

            });
        } else {
            var msg = "Invalid Coupon Id";
            ResponseService.generalPayloadResponse(null, msg, res);
            return;
        }
    } else {
        var msg = "Invalid Access";
        ResponseService.generalPayloadResponse(null, msg, res);
        return;
    }
}
exports.updateByid = async function(req, res) {
    model = new Coupon;
    let coupon_id = req.params.id
    const body = req.body;
    saveRecords = await Coupon.findById(coupon_id);
    if (req.body.coupon_label) {
        saveRecords.coupon_label = req.body.coupon_label;
    }
    if (req.body.is_active || req.body.is_active == 0) {
        saveRecords.is_active = req.body.is_active;
    }
    if (req.body.coupon_method) {
        saveRecords.coupon_method = req.body.coupon_method;
    }
    if (req.body.coupon_count) {
        saveRecords.coupon_count = req.body.coupon_count;
    }
    if (req.body.assing_to) {
        saveRecords.assing_to = req.body.assing_to;
    }
    if (req.body.min_amount) {
        saveRecords.min_amount = req.body.min_amount;
    }
    if (req.body.max_amount) {
        saveRecords.max_amount = req.body.max_amount;
    }
    if (req.body.amount) {
        saveRecords.amount = req.body.amount;
    }
    if (req.body.coupon_type) {
        saveRecords.coupon_type = req.body.coupon_type;
    }
    if (req.body.visibility) {
        saveRecords.visibility = req.body.visibility;
    }
    if (req.body.uses_per_customer) {
        saveRecords.uses_per_customer = req.body.uses_per_customer;
    }
    if (req.body.uses_per_coupon) {
        saveRecords.uses_per_coupon = req.body.uses_per_coupon;
    }
    if (req.body.start_date) {
        saveRecords.start_date = req.body.start_date;
    }
    if (req.body.end_date) {
        saveRecords.end_date = req.body.end_date;
    }
    if (req.body.creater_id) {
        saveRecords.creater_id = req.body.creater_id;
    }
    if (req.body.created_by) {
        saveRecords.created_by = req.body.created_by;
    }
    if (req.body.description) {
        saveRecords.description = req.body.description;
    }
    if (req.body.assigned_user_id) {
        saveRecords.assigned_user_id = req.body.assigned_user_id;
    }
    saveRecords.save((err, result) => {
        ResponseService.generalPayloadResponse(err, saveRecords, res);
    });
    // Category.findByIdAndUpdate(categoryid, saveRecords, { new: true }, (err, doc) => {
    //     ResponseService.generalPayloadResponse(err, saveRecords, res, undefined, "Updated");
    // });

}
exports.updateByid2 = async function(req, res) {
    model = new Coupon;
    let coupon_id = req.params.id
    const body = req.body;
    console.log(coupon_id);
    return;
    var saveRecords = await Coupon.findById(coupon_id);
    if (req.body.description) {
        saveRecords.description = req.body.description;
    }
    if (req.body.coupon_code) {
        saveRecords.coupon_code = req.body.coupon_code;
    }
    if (req.body.uses_per_customer) {
        saveRecords.uses_per_customer = req.body.uses_per_customer;
    }

    if (req.body.uses_per_coupon) {
        saveRecords.uses_per_coupon = req.body.uses_per_coupon;
    }
    if (req.body.condition_value) {
        saveRecords.condition_value = req.body.condition_value;
    }
    if (req.body.amount) {
        saveRecords.amount = req.body.amount;
    }
    if (req.body.rule_type) {
        saveRecords.rule_type = req.body.rule_type;
    }
    if (req.body.start_date) {
        saveRecords.start_date = req.body.start_date;
    }
    if (req.body.end_date) {
        saveRecords.end_date = req.body.end_date;
    }

    saveRecords.save((err, result) => {
        ResponseService.generalPayloadResponse(err, saveRecords, res);
    });


}


exports.list = async function(query, limit, page, type, body, res) {

    const model = Coupon;
    let data = await model.find();
    ResponseService.generalPayloadResponse(null, data, res);

    return
}