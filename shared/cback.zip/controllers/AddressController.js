const ResponseService = require('../shared/ResponseService'); // Response service
const Address = require('../models/Address'); // Block model


const CRUD = require('../shared/CRUD');

exports.addresslist = async function (req, res) {
	var user_id=req.body.user_id;
	const Addresslist = await Address.find({ user_id: user_id,status:'1' });
	ResponseService.generalPayloadResponse(null, Addresslist, res);
}
