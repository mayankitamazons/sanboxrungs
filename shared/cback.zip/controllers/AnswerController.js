const ResponseService = require('../shared/ResponseService'); // Response service
const Answer = require('../models/Answer'); // Attr option model
const Question = require('../models/Question'); // Attr option model
const User = require('../models/User'); // Attr option model
const CRUD = require('../shared/CRUD');


exports.add = async function(req, res) {

    let user_id = req.body.user_id;
    let question_id = req.body.question_id;
    let userRecord = await User.findById(user_id);
    req.body.answers = req.body.answers;
    const model = new Answer(req.body);
    if (user_id && req.body.question_id && req.body.answers) {
        await Answer.findOne({
            question_id: req.body.question_id,
            user_id: req.body.user_id
        }, async(err, doc) => {
            if (doc) {
                ResponseService.generalResponse("Already Voted", res, 404, "Already Voted");
                return;
            } else {
                // check user community id 
                in_com_exit = false;
                community_list = userRecord.community_id;

                let questionAnswerRecords = await Question.findById(req.body.question_id);
                q_list = questionAnswerRecords.community_id;
                for (i = 0; i < community_list.length; i++) {
                    c_l = community_list[i];
                    comdata = await Question.findOne({
                        "_id": question_id,
                        "community_id": { $in: c_l }
                    });
                    if (comdata) {
                        in_com_exit = true;
                        break;
                    }
                }
                if (in_com_exit) {
                    let AnswerData = await model.save();
                    if (AnswerData) {

                        let totalVote = await Answer.find({ "question_id": req.body.question_id });

                        totalVote = totalVote.length;


                        Question.findByIdAndUpdate(req.body.question_id, { 'total_vote': totalVote }, { new: true }, (err, doc) => {
                            console.log('Question update with total_vote = ' + totalVote);
                        });
                        if ((questionAnswerRecords.answers).length) {
                            let answerArray = questionAnswerRecords.answers;

                            for (i = 0; i < answerArray.length; i++) {
                                answer_id = answerArray[i]._id
                                totalansVote = await Answer.find({ "question_id": req.body.question_id, "answers": answer_id });
                                totalansVote = totalansVote.length;

                                answerArray[i].vote_count = totalansVote;
                                if (totalVote > 0) {
                                    percentage = parseFloat((totalansVote / totalVote)).toFixed(2);
                                    answerArray[i].vote_per = percentage * 100;
                                }

                            }
                            console.log("percentage " + percentage);
                            questionAnswerRecords.answers = answerArray;
                            Question.findByIdAndUpdate(req.body.question_id, { 'answers': questionAnswerRecords.answers }, { new: true }, (err, doc) => {
                                console.log('Question answers');
                            });
                        }
                        ResponseService.generalPayloadResponse(null, AnswerData, res);
                        return;
                    } else {
                        ResponseService.generalPayloadResponse(null, "Failed to save", res);
                        return;
                    }

                } else {
                    ResponseService.generalResponse("Only Community Registered Member can vote on this poll", res, 200, "Only Community Registered Member can vote on this poll");
                    return;
                }


            }
        })
    } else {
        ResponseService.generalResponse("Required Parameter is missing", res, 404, "Required Parameter is missing");
        return;

    }



}

exports.getQuestionDetail = async function(req, res) {

    let question_id = req.body.question_id;
    let questionRecord = await Question.findById(question_id);

    let answerRecord = await Answer.find({ "question_id": question_id }).populate('question_id', "question slug answers");;
    let detail = [];
    let vote_count = answerRecord.length;

    if (answerRecord.length) {
        answerRecord.forEach(function(data, index) {

        });
    }

    ResponseService.generalPayloadResponse(null, answerRecord, res);
    return;
}