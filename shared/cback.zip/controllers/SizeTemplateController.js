const ResponseService = require('../shared/ResponseService'); // Response service
const SizeTemplate = require('../models/SizeTemplate'); // User model
const CRUD = require('../shared/CRUD');


exports.list = async function(query, limit, page, type, body, res) {
    const model = SizeTemplate;

    model.find(query, (err, doc) => {

        ResponseService.generalPayloadResponse(err, doc, res);
    });
}