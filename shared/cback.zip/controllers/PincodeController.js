const ResponseService = require('../shared/ResponseService'); // Response service
const Pincode = require('../models/pincode'); // pincode model
const CRUD = require('../shared/CRUD');
const User = require('../models/User');

exports.pincodeList = async function(query, limit, page, type, body, res) {
    const model = Pincode;
    isrequested = query.isrequested;
    limit = 1000;
     if (query.status == 1) {

        cdata = await Pincode.find({ "status": 1 }).skip(page * limit).limit(limit)
            .sort({ name: 1 });

    } else if (query.status == 0) {
        cdata = await Pincode.find({ "status": 0 }).skip(page * limit).limit(limit)
           .sort({ name: 1 });

    } else {
        cdata = await Pincode.find({ "status": 1 }).skip(page * limit).limit(limit)
            .sort({ name: 1 });
    }

    ResponseService.generalPayloadResponse(null, cdata, res);
    return;
}

exports.pincodeFilter = async function(req, res) {

    const model = Pincode;
    var PincodeData;

    if (req.body.status) {
        PincodeData = await Pincode.find({ status: req.body.status });
    }
    ResponseService.generalPayloadResponse(null, PincodeData, res);
}
