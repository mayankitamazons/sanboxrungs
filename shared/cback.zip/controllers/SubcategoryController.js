const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model

const Subcategory = require('../models/Subcategory'); // Topic model

const CRUD = require('../shared/CRUD');


exports.getSubcategoryById = function (req, res) {
    let subcategoryid = req.params.id
    const model = Subcategory;

    if (subcategoryid) {
        model.find({_id: subcategoryid}, (err, doc) => {

            ResponseService.generalPayloadResponse(err, doc, res);

        }).populate('cat_id', "title slug icon parent_id description image isTrending store_id status show_menu");
    }
}

//category id can be main category id and subcategory id.

exports.categorylist = async function (query, limit, page, type, body, res) {

    const model = Subcategory;

    var SubcategoryData;
    var cat_id = body.cat_id;
    if (cat_id) {
        if (body.isTrending) {
            SubcategoryData = await model.find({isTrending: true, cat_id: cat_id}).populate('cat_id', "title slug icon description image isTrending store_id status show_menu").populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({_id: -1});
        }
        if (body.creater_id) {
            SubcategoryData = await model.find({creater_id: true, cat_id: cat_id}).populate('cat_id', "title slug icon description image isTrending store_id status show_menu").populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({_id: -1});
        }
        if (body.status) {
            SubcategoryData = await model.find({status: body.status, cat_id: cat_id}).populate('cat_id', "title slug icon description image isTrending store_id status show_menu").populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({_id: -1});
        }
    }

    ResponseService.generalPayloadResponse(null, SubcategoryData, res);
    return
}