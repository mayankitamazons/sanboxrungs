const ResponseService = require('../shared/ResponseService'); // Response service
const AWS = require("aws-sdk");
const ses = new AWS.SES({
	region: 'us-east-2'
});

const email = require('../shared/Email');

exports.createRegistrationTemplate = async function (req, res) {
	const params = {
		"Template": {
			"TemplateName": "RegistrationTemplate", //This is the template name which you'll refer while sending through SES.
			"SubjectPart": "Registration successfull!! Welcome to Supernebr!",
			"HtmlPart": "Hi <b>{{name}}</b>, Thank you for registering to Supernebr"
		}
	}
	const response = await ses.createTemplate(params).promise();
	ResponseService.generalPayloadResponse(null, 'Successfully created Registartion template', res);
}

exports.getAllTemplate = async function (req, res) {
	// Create the promise and SES service object
	var templatePromise = ses.listTemplates({ MaxItems: 5 }).promise();

	// Handle promise's fulfilled/rejected states
	templatePromise.then(
		function (data) {
			ResponseService.generalPayloadResponse(null, data, res);
		}).catch(
			function (err) {
				ResponseService.generalResponse(err, res, 403);
			});
}

exports.getEmailTemplate = async function (req, res) {
	var templatePromise = ses.getTemplate({ TemplateName: req.params.name }).promise();

	// Handle promise's fulfilled/rejected states
	templatePromise.then(
		function (data) {
			ResponseService.generalPayloadResponse(null, data, res);
		}).catch(
			function (err) {
				ResponseService.generalResponse(err, res, 403);
			});
}

exports.createOrderConfirmTemplate = async (req, res) => {
	// Create createTemplate params
	var params = {

		"Template": {
			"TemplateName": "OrderTemplate",
			"SubjectPart": "Order, placed!",
			"HtmlPart": "Hi <b>{{name}}</b>, Thank you for registering to Supernebr"

		}
	};

	// Create the promise and SES service object
	const response = await ses.createTemplate(params).promise();
	ResponseService.generalPayloadResponse(null, 'Successfully created Order template', res);
}

exports.updateRegistrationTemplate = async function (req, res) {
	const params = {
		"Template": {
			"TemplateName": "RegistrationTemplate", //This is the template name which you'll refer while sending through SES.
			"SubjectPart": "Registration successfull!! Welcome to Supernebr!",
			"HtmlPart": "<!DOCTYPEhtml><htmldata-editor-version='2'class='sg-campaigns'xmlns='http://www.w3.org/1999/xhtml'><head><metahttp-equiv='Content-Type'content='text/html;charset=utf-8'/><metaname='viewport'content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1'/><metahttp-equiv='X-UA-Compatible'content='IE=Edge'/><styletype='text/css'>body{width:600px;margin:0auto;}table{border-collapse:collapse;}table,td{mso-table-lspace:0pt;mso-table-rspace:0pt;}img{-ms-interpolation-mode:bicubic;}</style><styletype='text/css'>body,p,div{font-family:inherit;font-size:14px;}body{color:#000000;}bodya{color:#1188e6;text-decoration:none;}p{margin:0;padding:0;}table.wrapper{width:100%!important;table-layout:fixed;-webkit-font-smoothing:antialiased;-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;}img.max-width{max-width:100%!important;}.column.of-2{width:50%;}.column.of-3{width:33.333%;}.column.of-4{width:25%;}@mediascreenand(max-width:480px){.preheader.rightColumnContent,.footer.rightColumnContent{text-align:left!important;}.preheader.rightColumnContentdiv,.preheader.rightColumnContentspan,.footer.rightColumnContentdiv,.footer.rightColumnContentspan{text-align:left!important;}.preheader.rightColumnContent,.preheader.leftColumnContent{font-size:80%!important;padding:5px0;}table.wrapper-mobile{width:100%!important;table-layout:fixed;}img.max-width{height:auto!important;max-width:100%!important;}a.bulletproof-button{display:block!important;width:auto!important;font-size:80%;padding-left:0!important;padding-right:0!important;}.columns{width:100%!important;}.column{display:block!important;width:100%!important;padding-left:0!important;padding-right:0!important;margin-left:0!important;margin-right:0!important;}}</style><!--userenteredHeadStart--><linkhref='https://fonts.googleapis.com/css?family=Viga&display=swap'rel='stylesheet'/><style>body{font-family:'Viga',sans-serif;}</style><!--EndHeaduserentered--></head><body><centerclass='wrapper'data-link-color='#1188E6'data-body-style='font-size:14px;font-family:inherit;color:#000000;background-color:#f0f0f0;'><divclass='webkit'><tablecellpadding='0'cellspacing='0'border='0'width='100%'class='wrapper'bgcolor='#f0f0f0'><tbody><tr><tdvalign='top'bgcolor='#f0f0f0'width='100%'><tablewidth='100%'role='content-container'class='outer'align='center'cellpadding='0'cellspacing='0'border='0'><tbody><tr><tdwidth='100%'><tablewidth='100%'cellpadding='0'cellspacing='0'border='0'><tbody><tr><td><tablewidth='100%'cellpadding='0'cellspacing='0'border='0'style='width:100%;max-width:600px;'align='center'><tbody><tr><tdrole='modules-container'style='padding:0px0px0px0px;color:#000000;text-align:left;'bgcolor='#ffffff'width='100%'align='left'><tableclass='modulepreheaderpreheader-hide'role='module'data-type='preheader'border='0'cellpadding='0'cellspacing='0'width='100%'style='display:none!important;mso-hide:all;visibility:hidden;opacity:0;color:transparent;height:0;width:0;'><tbody><tr><tdrole='module-content'><p></p></td></tr></tbody></table><tableborder='0'cellpadding='0'cellspacing='0'align='center'width='100%'role='module'data-type='columns'style='padding:30px20px40px30px;'bgcolor='#77dedb'><tbody><trrole='module-content'><tdheight='100%'valign='top'><tableclass='column'width='550'style='width:550px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'><tableclass='wrapper'role='module'data-type='image'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='b422590c-5d79-4675-8370-a10c2c76af02'><tbody><tr><tdstyle='font-size:6px;line-height:10px;padding:0px0px0px0px;'valign='top'align='left'><imgclass='max-width'border='0'style='display:block;color:#000000;text-decoration:none;font-family:Helvetica,arial,sans-serif;font-size:16px;'width='140'alt=''data-proportionally-constrained='true'data-responsive='false'src='../logo/logo.png'height='40'/></td></tr></tbody></table><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='1995753e-0c64-4075-b4ad-321980b82dfe'><tbody><tr><tdstyle='padding:100px0px18px0px;line-height:36px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:inherit;'><spanstyle='color:#ffffff;font-size:40px;font-family:inherit;'>Thankyouforyourorder!</span></div><div></div></div></td></tr></tbody></table><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='2ffbd984-f644-4c25-9a1e-ef76ac62a549'><tbody><tr><tdstyle='padding:18px20px20px0px;line-height:24px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:inherit;'><spanstyle='font-size:24px;'>Nowyoucanrelax.We'reworkinon</span></div><divstyle='font-family:inherit;text-align:inherit;'><spanstyle='font-size:24px;'>gettingyourordertoyouASAP!</span></div><div></div></div></td></tr></tbody></table><!--<tableborder='0'cellpadding='0'cellspacing='0'class='module'data-role='module-button'data-type='button'role='module'style='table-layout:fixed;'width='100%'data-muid='69fc33ea-7c02-45ed-917a-b3b8a6866e89'><tbody><tr><tdalign='left'bgcolor=''class='outer-td'style='padding:0px0px0px0px;'><tableborder='0'cellpadding='0'cellspacing='0'class='wrapper-mobile'style='text-align:center;'><tbody><tr><tdalign='center'bgcolor='#000000'class='inner-td'style='border-radius:6px;font-size:16px;text-align:left;background-color:inherit;'><ahref=''style='background-color:#000000;border:1pxsolid#000000;border-color:#000000;border-radius:0px;border-width:1px;color:#ffffff;display:inline-block;font-size:18px;font-weight:normal;letter-spacing:0px;line-height:normal;padding:12px18px12px18px;text-align:center;text-decoration:none;border-style:solid;font-family:inherit;'target='_blank'>FollowYourDelivery</a></td></tr></tbody></table></td></tr></tbody></table>--></td></tr></tbody></table></td></tr></tbody></table><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='8b5181ed-0827-471c-972b-74c77e326e3d'><tbody><tr><tdstyle='padding:30px20px18px30px;line-height:22px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:inherit;'><spanstyle='color:#0055ff;font-size:24px;'>OrderSummary</span></div><div></div></div></td></tr></tbody></table><tableclass='module'role='module'data-type='divider'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='f7373f10-9ba4-4ca7-9a2e-1a2ba700deb9'><tbody><tr><tdstyle='padding:0px30px0px30px;'role='module-content'height='100%'valign='top'bgcolor=''><tableborder='0'cellpadding='0'cellspacing='0'align='center'width='100%'height='3px'style='line-height:3px;font-size:3px;'><tbody><tr><tdstyle='padding:0px0px3px0px;'bgcolor='#e7e7e7'></td></tr></tbody></table></td></tr></tbody></table><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='264ee24b-c2b0-457c-a9c1-d465879f9935'><tbody><tr><tdstyle='padding:18px20px18px30px;line-height:22px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:inherit;'>OrderID:{{order_id}}</div><divstyle='font-family:inherit;text-align:inherit;'><spanstyle='color:#0055ff;'><strong>ExpectedDeliveryTime:{{delivery_date}}</strong></span></div><divstyle='font-family:inherit;text-align:inherit;'><br/></div><divstyle='font-family:inherit;text-align:inherit;'>OrderDate:{{order_date}}</div><divstyle='font-family:inherit;text-align:inherit;'>Address:{{delivery_address}}&nbsp;</div><div></div></div></td></tr></tbody></table><!--<tableborder='0'cellpadding='0'cellspacing='0'align='center'width='100%'role='module'data-type='columns'style='padding:20px20px0px30px;'bgcolor='#FFFFFF'><tbody><trrole='module-content'><tdheight='100%'valign='top'><tableclass='column'width='137'style='width:137px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'><tableclass='wrapper'role='module'data-type='image'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='239f10b7-5807-4e0b-8f01-f2b8d25ec9d7'><tbody><tr><tdstyle='font-size:6px;line-height:10px;padding:0px0px0px0px;'valign='top'align='left'><imgclass='max-width'border='0'style='display:block;color:#000000;text-decoration:none;font-family:Helvetica,arial,sans-serif;font-size:16px;'width='104'alt=''data-proportionally-constrained='true'data-responsive='false'src='http://cdn.mcauto-images-production.sendgrid.net/954c252fedab403f/f812833d-a1d7-4e7f-b5dd-8607415f078b/104x104.png'height='104'/></td></tr></tbody></table></td></tr></tbody></table><tableclass='column'width='137'style='width:137px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='f404b7dc-487b-443c-bd6f-131ccde745e2'><tbody><tr><tdstyle='padding:18px0px18px0px;line-height:22px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:inherit;'>VeggieBahnMiSandwich</div><divstyle='font-family:inherit;text-align:inherit;'><br/></div><divstyle='font-family:inherit;text-align:inherit;'><spanstyle='color:#0055ff;'>$9.49&nbsp;</span></div><div></div></div></td></tr></tbody></table></td></tr></tbody></table><tablewidth='137'style='width:137px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''class='columncolumn-2'><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'></td></tr></tbody></table><tablewidth='137'style='width:137px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''class='columncolumn-3'><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'></td></tr></tbody></table></td></tr></tbody></table><tableborder='0'cellpadding='0'cellspacing='0'align='center'width='100%'role='module'data-type='columns'style='padding:20px20px0px30px;'bgcolor='#FFFFFF'><tbody><trrole='module-content'><tdheight='100%'valign='top'><tableclass='column'width='137'style='width:137px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'><tableclass='wrapper'role='module'data-type='image'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='239f10b7-5807-4e0b-8f01-f2b8d25ec9d7.1'><tbody><tr><tdstyle='font-size:6px;line-height:10px;padding:0px0px0px0px;'valign='top'align='left'><imgclass='max-width'border='0'style='display:block;color:#000000;text-decoration:none;font-family:Helvetica,arial,sans-serif;font-size:16px;'width='104'alt=''data-proportionally-constrained='true'data-responsive='false'src='http://cdn.mcauto-images-production.sendgrid.net/954c252fedab403f/fcc12b6b-1d51-4693-8bf6-d7dbbb224010/104x104.png'height='104'/></td></tr></tbody></table></td></tr></tbody></table><tableclass='column'width='137'style='width:137px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='f404b7dc-487b-443c-bd6f-131ccde745e2.1'><tbody><tr><tdstyle='padding:18px0px18px0px;line-height:22px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:inherit;'>VietnameseIcedCoffeew/Boba</div><divstyle='font-family:inherit;text-align:inherit;'><br/></div><divstyle='font-family:inherit;text-align:inherit;'><spanstyle='color:#0055ff;'>$2.49&nbsp;</span></div><div></div></div></td></tr></tbody></table></td></tr></tbody></table><tablewidth='137'style='width:137px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''class='columncolumn-2'><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'></td></tr></tbody></table><tablewidth='137'style='width:137px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''class='columncolumn-3'><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'></td></tr></tbody></table></td></tr></tbody></table>--><tableclass='module'role='module'data-type='divider'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='f7373f10-9ba4-4ca7-9a2e-1a2ba700deb9.1'><tbody><tr><tdstyle='padding:20px30px0px30px;'role='module-content'height='100%'valign='top'bgcolor=''><tableborder='0'cellpadding='0'cellspacing='0'align='center'width='100%'height='3px'style='line-height:3px;font-size:3px;'><tbody><tr><tdstyle='padding:0px0px3px0px;'bgcolor='E7E7E7'></td></tr></tbody></table></td></tr></tbody></table><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='264ee24b-c2b0-457c-a9c1-d465879f9935.1'><tbody><tr><tdstyle='padding:18px20px30px30px;line-height:22px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:inherit;'><br/>GrandTotal&nbsp;</div><divstyle='font-family:inherit;text-align:inherit;'><br/></div><divstyle='font-family:inherit;text-align:inherit;'><spanstyle='color:#0055ff;font-size:32px;font-family:inherit;'>&#x20B9;{{total_price}}</span></div><div></div></div></td></tr></tbody></table><tableborder='0'cellpadding='0'cellspacing='0'align='center'width='100%'role='module'data-type='columns'style='padding:0px20px0px20px;'bgcolor='#0055ff'><tbody><trrole='module-content'><tdheight='100%'valign='top'><tableclass='column'width='140'style='width:140px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='9d43ffa1-8e24-438b-9484-db553cf5b092'><tbody><tr><tdstyle='padding:18px0px18px0px;line-height:22px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:center;'><ahref='http://'><spanstyle='color:#ffffff;'>Support</span></a></div><div></div></div></td></tr></tbody></table></td></tr></tbody></table><tableclass='column'width='140'style='width:140px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='9d43ffa1-8e24-438b-9484-db553cf5b092.1'><tbody><tr><tdstyle='padding:18px0px18px0px;line-height:22px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:center;'><ahref='http://'><spanstyle='color:#ffffff;'>ContactUs</span></a></div><div></div></div></td></tr></tbody></table></td></tr></tbody></table><tablewidth='140'style='width:140px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''class='columncolumn-2'><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='9d43ffa1-8e24-438b-9484-db553cf5b092.1.1'><tbody><tr><tdstyle='padding:18px0px18px0px;line-height:22px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:center;'><ahref='http://'><spanstyle='color:#ffffff;'>Drivers</span></a></div><div></div></div></td></tr></tbody></table></td></tr></tbody></table><tablewidth='140'style='width:140px;border-spacing:0;border-collapse:collapse;margin:0px0px0px0px;'cellpadding='0'cellspacing='0'align='left'border='0'bgcolor=''class='columncolumn-3'><tbody><tr><tdstyle='padding:0px;margin:0px;border-spacing:0;'><tableclass='module'role='module'data-type='text'border='0'cellpadding='0'cellspacing='0'width='100%'style='table-layout:fixed;'data-muid='9d43ffa1-8e24-438b-9484-db553cf5b092.1.1.1'><tbody><tr><tdstyle='padding:18px0px18px0px;line-height:22px;text-align:inherit;'height='100%'valign='top'bgcolor=''role='module-content'><div><divstyle='font-family:inherit;text-align:center;'><ahref='http://'><spanstyle='color:#ffffff;'>Legal</span></a></div><div></div></div></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table><divdata-role='module-unsubscribe'class='module'role='module'data-type='unsubscribe'style='background-color:#0055ff;color:#ffffff;font-size:12px;line-height:20px;padding:16px16px16px16px;text-align:Center;'data-muid='4e838cf3-9892-4a6d-94d6-170e474d21e5'><divclass='Unsubscribe--addressLine'><pclass='Unsubscribe--senderName'style='font-size:12px;line-height:20px;'>{{Sender_Name}}</p><pstyle='font-size:12px;line-height:20px;'><spanclass='Unsubscribe--senderAddress'>{{Sender_Address}}</span>,<spanclass='Unsubscribe--senderCity'>{{Sender_City}}</span>,<spanclass='Unsubscribe--senderState'>{{Sender_State}}</span><spanclass='Unsubscribe--senderZip'>{{Sender_Zip}}</span></p></div><pstyle='font-size:12px;line-height:20px;'><aclass='Unsubscribe--unsubscribeLink'href='{{{unsubscribe}}}'target='_blank'style='color:#77dedb;'>Unsubscribe</a>-<ahref='{{{unsubscribe_preferences}}}'target='_blank'class='Unsubscribe--unsubscribePreferences'style='color:#77dedb;'>UnsubscribePreferences</a></p></div><tableborder='0'cellpadding='0'cellspacing='0'class='module'data-role='module-button'data-type='button'role='module'style='table-layout:fixed;'width='100%'data-muid='e5cea269-a730-4c6b-8691-73d2709adc62'><tbody><tr><tdalign='center'bgcolor='0055FF'class='outer-td'style='padding:0px0px20px0px;'><!--<tableborder='0'cellpadding='0'cellspacing='0'class='wrapper-mobile'style='text-align:center;'><tbody><tr><tdalign='center'bgcolor='#f5f8fd'class='inner-td'style='border-radius:6px;font-size:16px;text-align:center;background-color:inherit;'><ahref='https://www.sendgrid.com/?utm_source=powered-by&utm_medium=email'style='background-color:#f5f8fd;border:1pxsolid#f5f8fd;border-color:#f5f8fd;border-radius:25px;border-width:1px;color:#a8b9d5;display:inline-block;font-size:10px;font-weight:normal;letter-spacing:0px;line-height:normal;padding:5px18px5px18px;text-align:center;text-decoration:none;border-style:solid;font-family:helvetica,sans-serif;'target='_blank'>♥POWEREDBYTWILIOSENDGRID</a></td></tr></tbody></table>--></td></tr></tbody></table></td></tr></tbody></table><!--[ifmso]></td></tr></table></center><![endif]--></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></div></center></body></html>"
		}
	}
	const response = await ses.updateTemplate(params).promise();
	ResponseService.generalPayloadResponse(null, 'Successfully updated Registartion template', res);
}

exports.sendRegistrationEmail = async function (req, res) {
	email.sendEmailAfterRegistration('ravisastryganti@gmail.com', 'supernebr20@gmail.com');
	ResponseService.generalPayloadResponse(null, 'Successfully sent email', res);
}

exports.sendOrderEmail = async (req, res) => {

	email.sendEmailAfterOrder("praveshpansari@gmail.com", "supernebr20@gmail.com", {
		"items_qty": 1,
		"status": 1,
		"order_status": 1,
		"shipping_amount": 0,
		"coupon_code": "",
		"is_reviewed": false,
		"seller_id": [
			"6071525c98f6233a006ad41b"
		],
		"cartitem": [
			{
				"qty": 1,
				"product_id": "607286e9a3ec025fa49b07dd",
				"service_type": "1",
				"slot_id": "",
				"slot_days": "",
				"slot_msg": "",
				"name": "Coffee",
				"icon": "h",
				"price": "1000.00",
				"subtotal": "1000.00",
				"seller_id": {
					"_id": "6071525c98f6233a006ad41b",
					"name": "Seller house",
					"email": "house@gmail.com",
					"mobile_no": "9352452574",
					"profile_pic": "",
					"cover_image": ""
				},
				"stock_msg": "",
				"mrp": 1200,
				"delivery_time": "10",
				"delivery_slot": "days"
			}
		],
		"address": [
			{
				"full_name": "Karan Gobazzar",
				"flat_no": "A 230",
				"wing_no": "Bluw Colony",
				"email": "karanbothra12@gmail.com",
				"mobile_no": null,
				"community_name": "Prestige Silver Oak -560066"
			}
		],
		"return_status": 0,
		"expected_delivery_date": "30-Apr",
		"return_time_expire": false,
		"is_parent_order": false,
		"childOrders": [],
		"group_by_ids": [],
		"slot_by_ids": [],
		"_id": "607ebddfdbcb4a5c7874def5",
		"subtotal": 1000,
		"grandtotal": 1000,
		"currency": "INR",
		"payment_method": "cash on delivery",
		"vat": 0,
		"discount_amount": 0,
		"tax_amount": 0,
		"customer_email": "karanbothra12@gmail.com",
		"customer_group_id": 2,
		"customer_id": "605c947e73e81265164103bb",
		"created_at": "2021-04-20T11:41:18.955Z",
		"updated_at": "2021-04-20T11:41:04.042Z",
		"__v": 0,
		"tracking_detail": [
			{
				"track_msg": "Order Placed",
				"track_code": "",
				"_id": "607ebddfdbcb4a5c7874def7",
				"creater_id": "605c947e73e81265164103bb",
				"created_time": "2021-04-20T11:41:19.064Z"
			}
		],
		"invoice_no": 66,
		"increment_id": 10000143
	}).then(
		function (data) {
			ResponseService.generalPayloadResponse(null, data, res);
		}).catch(
			function (err) {
				ResponseService.generalResponse(err, res, 401);
			});
}
