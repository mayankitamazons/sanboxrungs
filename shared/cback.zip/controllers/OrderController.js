const ResponseService = require("../shared/ResponseService"); // Response service
const User = require("../models/User"); // User model
const _ = require("lodash");
const fs = require("fs");
const PDFDocument = require("pdfkit");
const path = require("path");
const CRUD = require("../shared/CRUD");
const Product = require("../models/Product");
const SellerProduct = require("../models/SellerProduct");
const Attribute = require("../models/Attribute");
const Order = require("../models/Order");
const Cart = require("../models/Cart");
const { compareSync } = require("bcryptjs");
const CouponHistory = require("../models/CouponHistory");
const querystring = require("querystring");
const axios = require("axios");
const moment = require("moment-timezone");
var mongoose = require("mongoose");
const Coupon = require("../models/Coupon");
const NotificationService = require("../shared/NotificationService"); // Notification service
const { Console } = require("console");
const email = require("../shared/Email");
const AWS = require("aws-sdk");
const BUCKET_NAME = "humbleirde";

async function getCartByCustomerId(customer_id) {
  try {
    res = await Cart.findOne({ customer_id: customer_id, is_active: 1 });
    return res;
  } catch (err) {
    return;
  }
}

function dateparser(str) {
  return format(new Date(Date.parse(str)), "yyyy-MM-dd");
}
async function sendotp(message, mobile_no) {
  const ApiUserName = "Ravikanth";
  const ApiUserPassword = "SMS@Pass1";
  const ApiUserSenderId = "SPRNBR";
  const ApiUrl = "https://login.bulksmsgateway.in/sendmessage.php?";

  const type = 3;
  const Newapi = {
    user: ApiUserName,
    password: ApiUserPassword,
    sender: ApiUserSenderId,
    type: 3,
  };

  var number = mobile_no;
  // const message="Now Regi";
  // console.log(req.query);
  var config = {
    method: "GET",
    url:
      `${ApiUrl}${querystring.stringify(Newapi)}` +
      "&mobile=" +
      number +
      "&" +
      querystring.stringify({
        message: message,
      }),
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      Accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    },
  };
  return new Promise((resolutionFunc, rejectionFunc) => {
    axios(config)
      .then((results) => {
        // console.log(results);
        var res2 = {
          status: 200,
        };
        resolutionFunc(res2);
      })
      .catch((err) => {
        // console.log(err);
        rejectionFunc(err);
      });
  });
}

function makeid(length) {
  var result = "";
  var characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}
exports.create = async function (req, res) {
  var body = req.body;
  var d = new Date();
  var time = d.getTime();
  group_pro_exit = false;
  customer_id = body.customer_id;
  cart = await getCartByCustomerId(customer_id);

  if (cart) result = await collectTotal(cart._id);
  if (cart && cart.cartitem.length) {
    cart_order_id = cart._id;

    cart_item = cart.cartitem;

    // check for multiple seller
    const differentSellers = _.uniq(
      _.map(cart_item, (cartSeller) => {
        return cartSeller.seller_id;
      })
    );
    const params = ({
      shipping_amount,
      customer_id,
      customer_email,
      customer_group_id,
      currency,
      coupon_code,
      discount_amount,
      discount_description,
      vat,
      tax_amount,
      address,
      payment_method,
    } = cart);
    params._doc.status = 1;
    params._doc.order_status = 1;
    params._doc.created_at = time;
    params._doc.tracking_detail = {
      track_msg: "Order Placed",
      creater_id: body.customer_id,
    };

    user_mobile_no = cart.address.length ? cart.address[0].mobile_no : "123";

    first_product_id = cart_item[0].product_id;
    first_product_name = cart_item[0].name;
    first_delivery_time = cart_item[0].delivery_time;
    first_delivery_slot = cart_item[0].delivery_slot;
    if (cart_item[0].service_type == "2") {
      expected_delivery_date = cart_item[0].slot_msg;
    } else {
      if (first_delivery_slot == "days") {
        added_date = parseInt(first_delivery_time);
        exp_delivery_date = new Date(
          new Date().getTime() + added_date * 24 * 60 * 60 * 1000
        );
        expected_delivery_date = moment(exp_delivery_date).format("DD-MMM");
      } else if (first_delivery_slot == "hrs") {
        expected_delivery_date = first_delivery_time + " hrs";
      }
    }

    params._doc.expected_delivery_date = expected_delivery_date;
    console.log("different seller" + differentSellers.length);
    if (differentSellers.length > 1) {
      // split into child orders
      const allSellersProducts = {};
      _.each(cart_item, (cartData) => {
        const sellerId = _.get(cartData, "seller_id");
        const productId = _.get(cartData, "product_id");

        if (!allSellersProducts[sellerId]) {
          allSellersProducts[sellerId] = {
            [productId]: cartData,
          };
        } else {
          allSellersProducts[sellerId][productId] = cartData;
        }
      });

      const childOrders = await Promise.all(
        _.map(allSellersProducts, async (cartItem, sellerId) => {
          const childOrderParams = {
            ...params._doc,
          };

          const cartProducts = [];
          let cartItemsQty = 0;
          let grandtotal = 0;

          _.map(cartItem, (cartData, productId) => {
            cartProducts.push(cartData);
            cartItemsQty += parseInt(cartData.qty);
            grandtotal += parseInt(cartData.qty) * cartData.price;
          });

          childOrderParams.grandtotal = grandtotal;
          childOrderParams.cartitem = cartProducts;
          childOrderParams.subtotal = grandtotal;
          childOrderParams.items_qty = cartItemsQty;
          childOrderParams._id = null;

          const order_id = await saveOrder(childOrderParams);
          return order_id;
        })
      );

      params._doc.childOrders = childOrders;
      params._doc.is_parent_order = true;
      // Place Parent Order
    } else {
      console.log("single seller");
    }
    params._doc._id = mongoose.Types.ObjectId();
    order = new Order(params._doc);
    // deduct stock and mark product complete
    order_increment_id = order.increment_id;
    order.invoice_no = order.invoice_no;
    group_ids = [];
    sellers = [];
    for (i = 0; i < cart_item.length; i++) {
      element = cart_item[i];

      if (element) {
        // if (element.group_slot_id) {
        //     group_ids.push(element.group_slot_id);
        // }

        qty = parseInt(element.qty);
        product_id = element.product_id;
        p = await Product.findOne({ _id: product_id }).select(
          "price product_en special_price from_Date to_date icon multiseller seller_id pending_stock"
        );

        if (typeof p._id !== typeof undefined) {
          seller_id = element.seller_id;
          sellers.push(seller_id);
          service_type = element.service_type;
          multiseller = p.multiseller;

          sellerstock = await SellerProduct.findOne({
            seller_id: seller_id,
            product_id: product_id,
          });

          g_id_exit = false;

          seller_stock_id = sellerstock._id;
          old_stock = sellerstock.pending_stock;
          sellerstock.pending_stock = old_stock - qty;
          stock_data = {
            stock_value: qty,
            s_type: "out",
            comment: "Product out for order id : " + order_increment_id,
          };

          query = {};
          query.$addToSet = { stock_data: stock_data };
          SellerProduct.findByIdAndUpdate(
            seller_stock_id,
            query,
            { new: true },
            (err, doc) => {
              console.log("stock Data updated");
            }
          );
          seller_list = p.seller_id[0];
          if (seller_list._id == seller_id) {
            old_stock = p.pending_stock;
            new_stock = old_stock - qty;
            p.pending_stock = new_stock;
            console.log(new_stock);
            p.save((err, result) => {
              console.log("p stock updated");
            });
          }

          if (element.group_slot_id) {
            group_ids.push(element.group_slot_id);
            if (sellerstock.group_slot.length) {
              currentDate = new Date();
              gs = sellerstock.group_slot.find(
                (elem) => (elem._id = element.group_slot_id)
              );

              if (
                currentDate > gs.sell_start_date &&
                currentDate <= gs.sell_end_date
              ) {
                if (gs.product_sell + element.qty >= gs.min_qty) {
                  // Change delivery date
                  if (gs.delivery_slot == "days") {
                    exp_delivery_date = new Date();
                    exp_delivery_date.setDate(
                      exp_delivery_date.getDate() + Number(gs.delivery_time)
                    );
                    expected_delivery_date =
                      moment(exp_delivery_date).format("DD-MMM");
                    order.expected_delivery_date = expected_delivery_date;
                  }
                  if (gs.rollout_type == 2) {
                    //Delete the current slot
                    sellerstock.group_slot = sellerstock.group_slot.filter(
                      (st) => st._id != element.group_slot_id
                    );

                    // Get new Dates
                    daysPassed =
                      new Date().getTime() - gs.sell_start_date.getTime();
                    newStartDate = new Date(
                      gs.sell_start_date.getTime() + daysPassed
                    );
                    newEndDate = new Date(
                      gs.sell_end_date.getTime() + daysPassed
                    );

                    newSlot = {
                      min_qty: gs.min_qty,
                      sell_start_date: newStartDate,
                      sell_end_date: newEndDate,
                      delivery_time: gs.delivery_time,
                      delivery_slot: gs.delivery_slot,
                      rollout_type: gs.rollout_type,
                      comment: gs.comment,
                      price: gs.price,
                      special_price: gs.special_price,
                    };

                    sellerstock.group_slot.push(newSlot);
                  } else if (gs.rollout_type == 1) {
                    return ResponseService.generalResponse(
                      "Group Buy Limit Reached!Wait for seller to update slot",
                      res,
                      403
                    );
                  }
                } else {
                  console.log(
                    "Remaining qts ",
                    gs.min_qty - (gs.product_sell + element.qty)
                  );
                }

                sellerstock.group_slot.map((slot) => {
                  if (slot._id == element.group_slot_id)
                    slot.product_sell = slot.product_sell + element.qty;
                });

                await Product.findByIdAndUpdate(
                  product_id,
                  { seller_stock: sellerstock },
                  { new: true }
                );
              } else {
                return ResponseService.generalResponse(
                  "Group Buy expired!",
                  res,
                  403
                );
              }
            } else {
              return ResponseService.generalResponse(
                "Group Buy not found for the product!",
                res,
                404
              );
            }
          }

          sellerstock.save();
          // send push notification & sms to seller for order
        }
      }
    }

    order.seller_id = sellers;

    order.save(async function (err, val) {
      if (err) {
        ResponseService.generalPayloadResponse(
          null,
          "Something Went wrong try again later",
          res
        );
        return;
      } else {
        // if product has group slot based product
        order_id = val._id;
        query = {};
        query.$addToSet = { group_by_ids: group_ids };
        Order.findByIdAndUpdate(order_id, query, { new: true }, (err, doc) => {
          console.log("Group By id updated");
        });

        if (cart_item.length > 1) {
          other_str =
            "Placed: Order for " +
            first_product_name.substring(0, 25) +
            " ... & " +
            (cart_item.length - 1) +
            " more item is placed & will be delivered by " +
            expected_delivery_date;
        } else {
          other_str =
            "Placed: Order for " +
            first_product_name.substring(0, 30) +
            "... is placed & will be delivered by " +
            expected_delivery_date;
        }
        if (user_mobile_no) {
          res2 = await sendotp(other_str, user_mobile_no);
        }
        userdata = await User.findById(customer_id).populate(
          "community_id",
          "builder_name name locality pincode city status"
        );
        user_id = userdata._id;
        notifcation_ids = userdata.notification_id;
        if (notifcation_ids.length > 0) {
          NotificationService.sendByUserId(
            other_str,
            "New Order Placed",
            user_id,
            null
          );
        }

        // send email after the user registers
        // email.sendEmailAfterOrder('praveshpansari@gmail.com', 'supernebr20@gmail.com', val);

        cart.expected_delivery_date = expected_delivery_date;
        ch_params = {
          customer_id: customer_id,
          order_id: val._id,
          coupon_code: val.coupon_code,
        };

        ch = new CouponHistory(ch_params);
        ch.save();
        // cart.save();
        cart.is_active = 0;
        //  cart.save();
        // cart_id = "601cfc72fc1fad0004c60947";

        Cart.findByIdAndUpdate(
          cart_order_id,
          {
            is_active: 0,
            expected_delivery_date: expected_delivery_date,
          },
          { new: true },
          (err, doc) => {}
        );

        SellerData = await User.find({
          _id: { $in: sellers },
        }).populate(
          "community_id",
          "builder_name name locality pincode city status"
        );

        // Path to store file
        const dir = "./uploads/order/invoice/";
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }

        let invoices = [];

        SellerData.forEach((seller) => {
          subTotal = 0;
          val.cartitem.map((c) => {
            if (c.seller_id == seller._id) {
              subTotal = subTotal + c.subtotal;
            }
          });

          invoice = {
            seller: {
              name: seller.name,
              address_1:
                seller.community_id[0].builder_name +
                " " +
                seller.community_id[0].name,
              address_2:
                seller.community_id[0].locality +
                " " +
                seller.community_id[0].city +
                " - " +
                seller.community_id[0].pincode,
              gstin: seller.gst_no,
            },
            order: {
              order_id: val._id,
              order_date: val.created_at,
              invoice_date: moment().format("YYYY-MM-DD"),
              pan: "",
            },
            billing: {
              name: userdata.address_detail[0].full_name,
              address_1:
                val.address[0].adderess_1 +
                ", " +
                val.address[0].community_name,
              address_2: val.address[0].pin_code,
              contact: userdata.mobile_no
                ? userdata.mobile_no
                : userdata.email
                ? userdata.email
                : "",
            },
            shipping: {
              name: val.address[0].full_name,
              phone: val.address[0].mobile_no,
              address_1:
                val.address[0].adderess_1 +
                ", " +
                val.address[0].community_name,
              address_2: val.address[0].pin_code,
            },
            itemCount: val.cartitem.length,
            items: val.cartitem.filter((c) => c.seller_id == seller._id),
            subtotal: subTotal,
            paid: 0,
            invoice_no: val.invoice_no,
            invoice_nr: "INV" + val.invoice_no,
          };
          invoices.push(invoice);
        });

        createInvoice(
          invoices,
          dir + userdata.name.replace(/\s/g, "") + order_id + ".pdf",
          userdata.name.replace(/\s/g, "") + order_id + ".pdf"
        );

        let updateOrder = await Order.findByIdAndUpdate(
          order_id,
          {
            invoice_path: `https://humbleirde.s3.ca-central-1.amazonaws.com/${
              val.invoice_no + order_id
            }.pdf`,
          },
          { new: true }
        );

        // email.sendEmailAfterOrder(userdata.email, 'supernebr20@gmail.com', updateOrder).then();

        ResponseService.generalPayloadResponse(null, updateOrder, res);
      }
    });
  } else {
    ResponseService.generalPayloadResponse(null, "Your cart is empty", res);
  }
};

saveOrder = async (params) => {
  return new Promise((resolve) => {
    order = new Order(params);
    console.log("save child order");
    order.save(function (err, val) {
      if (err) {
        console.log(err, "err");
      } else {
        console.log("save child order final");
        return resolve(val.increment_id);
      }
    });
  });
};
exports.createmobile = async function (req, res) {
  var body = req.body;
  var d = new Date();
  var time = d.getTime();
  customer_id = body.customer_id;
  cart = await getCartByCustomerId(customer_id);
  if (cart) result = await collectTotal(cart._id);
  if (cart && cart.cartitem.length) {
    userdata = await User.findById(customer_id).populate(
      "community_id",
      "name locality pincode city status"
    );
    address_data = cart.address;
    console.log("address data", address_data);
    //	address_data=[];
    if (address_data) {
      if (
        address_data.full_name &&
        userdata.mobile_no &&
        address_data.adderess_1
      ) {
      } else {
        ResponseService.generalResponse(
          null,
          res,
          402,
          "Please add Address first"
        );
        return;
      }
    } else {
      adddress = {};
      ResponseService.generalResponse(
        null,
        res,
        402,
        "Please add Address first"
      );
      return;
    }
    cart_order_id = cart._id;

    cart_item = cart.cartitem;
    const params = ({
      shipping_amount,
      customer_id,
      customer_email,
      customer_group_id,
      currency,
      coupon_code,
      discount_amount,
      discount_description,
      vat,
      tax_amount,
      address,
      payment_method,
    } = cart);
    params._doc.status = 1;
    params._doc.order_status = 1;
    params._doc.created_at = time;
    params._doc.tracking_detail = {
      track_msg: "Order Placed",
      creater_id: body.customer_id,
    };

    user_mobile_no = cart.address.length ? cart.address.mobile_no : "123";

    first_product_id = cart_item[0].product_id;
    first_product_name = cart_item[0].name;
    first_delivery_time = cart_item[0].delivery_time;
    first_delivery_slot = cart_item[0].delivery_slot;
    var expected_delivery_date = "";
    if (first_delivery_slot == "days") {
      added_date = parseInt(first_delivery_time);
      exp_delivery_date = new Date(
        new Date().getTime() + added_date * 24 * 60 * 60 * 1000
      );
      expected_delivery_date = moment(exp_delivery_date).format("DD-MMM");
    } else if (first_delivery_slot == "hrs") {
      expected_delivery_date = first_delivery_time + " hrs";
    }
    params._doc.expected_delivery_date = expected_delivery_date;

    params._doc._id = mongoose.Types.ObjectId();
    order = new Order(params._doc);
    // deduct stock and mark product complete
    order_increment_id = order.increment_id;
    order.invoice_no = order.invoice_no;
    group_ids = [];
    sellers = [];
    for (i = 0; i < cart_item.length; i++) {
      element = cart_item[i];

      if (element) {
        // if (element.group_slot_id) {
        //     group_ids.push(element.group_slot_id);
        // }

        qty = parseInt(element.qty);
        product_id = element.product_id;
        p = await Product.findOne({ _id: product_id }).select(
          "price product_en special_price from_Date to_date icon multiseller seller_id pending_stock"
        );

        if (typeof p._id !== typeof undefined) {
          g_id_exit = false;
          old_stock = p.pending_stock;
          p.pending_stock = old_stock - qty;
          stock_data = {
            stock_value: qty,
            s_type: "out",
            comment: "Product out for order id : " + order_increment_id,
          };

          query = {};
          query.$addToSet = { stock_data: stock_data };
          Product.findByIdAndUpdate(
            product_id,
            query,
            { new: true },
            (err, doc) => {
              console.log("stock Data updated");
            }
          );
          // send push notification & sms to seller for order
        }
      }
    }

    order.seller_id = sellers;

    order.save(async function (err, val) {
      if (err) {
        ResponseService.generalPayloadResponse(
          null,
          "Something Went wrong try again later",
          res
        );
        return;
      } else {
        // if product has group slot based product
        order_id = val._id;
        if (cart_item.length > 1) {
          other_str =
            "Placed: Order for " +
            first_product_name.substring(0, 25) +
            " ... & " +
            (cart_item.length - 1) +
            " more item is placed & will be delivered by " +
            expected_delivery_date;
        } else {
          other_str =
            "Placed: Order for " +
            first_product_name.substring(0, 30) +
            "... is placed & will be delivered by " +
            expected_delivery_date;
        }
        if (user_mobile_no) {
          res2 = await sendotp(other_str, user_mobile_no);
        }
        userdata = await User.findById(customer_id).populate(
          "community_id",
          "name locality pincode city status"
        );
        user_id = userdata._id;
        notifcation_ids = userdata.notification_id;
        if (notifcation_ids.length > 0) {
          NotificationService.sendByUserId(
            other_str,
            "New Order Placed",
            user_id,
            null
          );
        }

        // send email after the user registers
        // email.sendEmailAfterOrder('praveshpansari@gmail.com', 'supernebr20@gmail.com', val);

        cart.expected_delivery_date = expected_delivery_date;
        ch_params = {
          customer_id: customer_id,
          order_id: val._id,
          coupon_code: val.coupon_code,
        };

        ch = new CouponHistory(ch_params);
        ch.save();
        // cart.save();
        cart.is_active = 0;
        //  cart.save();
        // cart_id = "601cfc72fc1fad0004c60947";

        Cart.findByIdAndUpdate(
          cart_order_id,
          {
            is_active: 0,
            expected_delivery_date: expected_delivery_date,
          },
          { new: true },
          (err, doc) => {}
        );

        // Path to store file
        const dir = "./uploads/order/invoice/";
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }

        let invoices = [];
        let SellerData = [
          {
            name: "Chouhan rugs",
            address_1: "Jaipur",
            address_2: "Raj,India",
            gst_no: "GST",
          },
        ];

        SellerData.forEach((seller) => {
          subTotal = 0;
          val.cartitem.map((c) => {
            if (c.seller_id == seller._id) {
              subTotal = subTotal + c.subtotal;
            }
          });

          invoice = {
            seller: {
              name: seller.name,
              address_1: seller.address_1,
              address_2: seller.address_2,
              gstin: seller.gst_no,
            },
            order: {
              order_id: val._id,
              order_date: val.created_at,
              invoice_date: moment().format("YYYY-MM-DD"),
              pan: "",
            },
            billing: {
              name: userdata.address_detail.full_name,
              address_1: val.address.adderess_1,
              address_2: val.address.pin_code,
              contact: userdata.mobile_no
                ? userdata.mobile_no
                : userdata.email
                ? userdata.email
                : "",
            },
            shipping: {
              name: val.address.full_name,
              phone: val.address.mobile_no,
              address_1: val.address.adderess_1,
              address_2: val.address.pin_code,
            },
            itemCount: val.cartitem.length,
            items: val.cartitem,
            subtotal: subTotal,
            paid: 0,
            invoice_no: val.invoice_no,
            invoice_nr: "INV" + val.invoice_no,
          };
          invoices.push(invoice);
        });

        createInvoice(
          invoices,
          dir + userdata.name.replace(/\s/g, "") + order_id + ".pdf",
          userdata.name.replace(/\s/g, "") + order_id + ".pdf"
        );

        let updateOrder = await Order.findByIdAndUpdate(
          order_id,
          {
            invoice_path: `https://humbleirde.s3.ca-central-1.amazonaws.com/${
              val.invoice_no + order_id
            }.pdf`,
          },
          { new: true }
        );

        // email.sendEmailAfterOrder(userdata.email, 'supernebr20@gmail.com', updateOrder).then();

        ResponseService.generalPayloadResponse(null, updateOrder, res);
      }
    });
  } else {
    ResponseService.generalPayloadResponse(null, "Your cart is empty", res);
  }
};
exports.create2 = async function (req, res) {
  var body = req.body;
  var d = new Date();
  var time = d.getTime();
  customer_id = body.customer_id;
  cart = await getCartByCustomerId(customer_id);
  if (cart && cart.cartitem.length) {
    cart_item = cart.cartitem;
    params = new Array();
    if (cart_item.length) {
      params.cartitem = cart_item;
      params.grandtotal = cart.grandtotal;
      params.items_qty = cart.items_qty;
      params.shipping_amount = cart.shipping_amount;
      params.customer_id = cart.customer_id;
      params.customer_email = cart.customer_email;
      params.customer_group_id = cart.customer_group_id;
      params.currency = cart.currency;
      params.coupon_code = cart.coupon_code;
      params.discount_amount = cart.discount_amount;
      params.discount_description = cart.discount_description;
      params.vat = cart.vat;
      params.tax_amount = cart.tax_amount;
      params.address = cart.address;
      params.payment_method = cart.payment_method;
      params.order_status = 1;
      params.created_at = time;
    }
    tracking_detail = {
      track_msg: "Order Placed",
      creater_id: body.customer_id,
    };
    params.tracking_detail = tracking_detail;
    order = new Order(params);

    order.save(async function (err, val) {
      if (err) {
        console.log(err);
      } else {
        user_mobile_no = cart.address[0].mobile_no;

        first_product_id = cart_item[0].product_id;
        first_product_name = cart_item[0].name;
        first_delivery_time = cart_item[0].delivery_time;
        first_delivery_slot = cart_item[0].delivery_slot;
        if (first_delivery_slot == "days") {
          added_date = parseInt(first_delivery_time);
          exp_delivery_date = new Date(
            new Date().getTime() + added_date * 24 * 60 * 60 * 1000
          );
          expected_delivery_date = moment(exp_delivery_date).format("DD-MMM");
        } else if (first_delivery_slot == "hrs") {
          expected_delivery_date = first_delivery_time + " hrs";
        }
        if (cart_item.length > 1) {
          other_str =
            "Placed: Order for " +
            first_product_name.substring(0, 20) +
            " +... & " +
            (cart_item.length - 1) +
            " more item is placed & will be delivered by " +
            expected_delivery_date;
        } else {
          other_str =
            "Placed: Order for " +
            first_product_name.substring(0, 20) +
            "... is placed & will be delivered by " +
            expected_delivery_date;
        }
        if (user_mobile_no) {
          res2 = await sendotp(other_str, user_mobile_no);
        }
        userdata = await User.findById(customer_id).populate(
          "community_id",
          "builder_name name locality pincode city status"
        );
        notifcation_ids = userdata.notification_id;
        if (notifcation_ids.length > 0) {
          NotificationService.sendByUserId(
            other_str,
            "New Order Placed",
            doc.user,
            doc
          );
        }
        cart.is_active = 0;
        cart.expected_delivery_date = expected_delivery_date;
        ch_params = {
          customer_id: customer_id,
          order_id: val._id,
          coupon_code: val.coupon_code,
        };

        ch = new CouponHistory(ch_params);
        ch.save();
        cart.save();
        // deduct stock and mark product complete
        for (i = 0; i < cart_item.length; i++) {
          element = cart_item[i];
          if (element) {
            qty = parseInt(element.qty);
            product_id = element.product_id;
            p = getProduct(product_id);
            if (typeof p._id !== typeof undefined) {
              seller_id = element.seller_id;
              multiseller = p.multiseller;

              sellerstock = SellerProduct.findOne({
                seller_id: seller_id,
                product_id: product_id,
              });
              seller_stock_id = sellerstock._id;
              old_stock = sellerstock.pending_stock;
              sellerstock.pending_stock = old_stock - qty;
              stock_data = {
                stock_value: qty,
                s_type: "out",
                comment: "Product out for order id" + p.increment_id,
              };
              query = {};
              query.$addToSet = {
                stock_data: stock_data,
                pending_stock: pending_stock,
              };
              SellerProduct.findByIdAndUpdate(
                sellerstock,
                query,
                { new: true },
                (err, doc) => {}
              );
              seller_list = p.seller_id[0];
              console.log(seller_list);
              return;
              if (seller_list._id == seller_id) {
                old_stock = p.pending_stock;
                new_stock = old_stock - qty;
                p.findByIdAndUpdate(
                  product_id,
                  { pending_stock: pending_stock },
                  { new: true },
                  async function (err, docs) {}
                );
              }

              // send push notification & sms to seller for order
            }
          }
        }
        console.log("Order created successfully");
      }
      ResponseService.generalPayloadResponse(null, val, res);
    });
  } else {
    ResponseService.generalPayloadResponse(null, "Your cart is empty", res);
  }
};
async function collectTotal(cart_id) {
  cart = await Cart.findOne({ _id: cart_id, is_active: 1 });
  if (cart) {
    let grandtotal = 0;
    let subtotal = 0;
    let total_item_quantity = 0;
    let shipping_amount = 0;
    let currency = "INR";
    let vat = 0;
    var tax_amount = 0;
    var discount_amount = 0;
    g_total = [];
    s_total = [];
    t_total = [];
    stock_msg = "";
    cart.allow_checkout = 1;
    allow_checkout = 1;
    reupdate_cart_item = new Array();
    if (cart.cartitem.length) {
      cart_item = cart["cartitem"];
      g_id_exit = false;
      for (i = 0; i < cart_item.length; i++) {
        element = cart_item[i];
        if (element && element != "null") {
          qty = parseInt(element.qty);
          product_id = element.product_id;
          try {
            p = await getProduct(product_id);
            if (typeof p._id !== typeof undefined) {
              let name = p.product_en;
              let icon = p.icon;
              let price = p.price;
              if (typeof p.special_price != undefined && p.special_price > 0) {
                price = p.special_price;
              }
              if (parseInt(p.pending_stock) <= 0) {
                element.stock_msg = name + "is Out of Stock";
                cart.allow_checkout = 0;
              } else if (parseInt(p.pending_stock) < qty) {
                element.stock_msg =
                  "only " +
                  p.pending_stock +
                  " quantity is availble for " +
                  name;
                cart.allow_checkout = 0;
              }
              subtotal = parseFloat(price * qty).toFixed(2);
              grandtotal = parseFloat(grandtotal + subtotal).toFixed(2);
              g_total.push(subtotal);
              s_total.push(element.shippingCost);
              t_total.push(element.tax);
              total_item_quantity = total_item_quantity + qty;
              element.icon = icon;
              element.name = name;
              element.price = parseFloat(price).toFixed(2);
              element.subtotal = parseFloat(subtotal).toFixed(2);
              reupdate_cart_item[i] = element;
            } else {
              console.log("Product Not Found.");
            }
          } catch (err) {
            return;
          }
        } else {
          console.log("Cart Item Not Found.");
        }
      }
    } else {
      console.log("Cart Empty.");
    }
    grandtotal = 0;
    shippingtotal = 0;
    Taxtotal = 0;
    for (var i = 0; i < g_total.length; i++) {
      console.log("Total cal");
      grandtotal += parseInt(g_total[i]);
      shippingtotal += parseInt(s_total[i]);
      Taxtotal += parseInt(t_total[i]);
    }

    cart.subtotal = grandtotal + shippingtotal + Taxtotal;
    cart.grandtotal = grandtotal + shippingtotal + Taxtotal;

    if (cart.coupon_code) {
      is_valid_res = await validateCoupon(
        cart.coupon_code,
        cart.customer_id,
        cart.subtotal
      );
      is_valid_coupon = is_valid_res.is_valid;
      if (is_valid_coupon) {
        discount_amount = is_valid_res.discount;
      } else {
        cart.coupon_code = "";
      }
      cart.discount_amount = discount_amount;

      if (grandtotal > discount_amount) {
        grandtotal = grandtotal - discount_amount;
      } else {
        grandtotal = 0;
      }
      // console.log("grand total after discount "+grandtotal);
    } else {
      cart.coupon_code = "";
      cart.discount_amount = 0;
    }
    cart.cartitem = reupdate_cart_item;

    cart.grandtotal = parseFloat(grandtotal + shippingtotal + Taxtotal).toFixed(
      2
    );
    //console.log(cart.grandtotal);
    cart.items_qty = total_item_quantity;
    cart.shipping_amount = parseFloat(shippingtotal).toFixed(2);
    cart.tax_amount = parseFloat(Taxtotal).toFixed(2);

    cart.currency = currency;
    cart.vat = vat;
    cart_id = cart._id;
    // console.log(cart);
    Cart.findByIdAndUpdate(
      cart_id,
      cart,
      {
        new: true,
      },
      (err, doc) => {
        // console.log('FInal');
        // console.log(doc);
      }
    );
    return cart;
  } else {
    return;
  }
}

async function stockupdate(cart_id) {}
async function getProduct(id) {
  try {
    res = await Product.findOne({ _id: id }).select(
      "price product_en special_price from_Date to_date icon"
    );
    return res;
  } catch (err) {
    return;
  }
}

const unique = Math.floor(100000 + Math.random() * 900000);

exports.orderlist = async function (query, limit, page, type, body, res) {
  const model = Order;
  limit = 1000;
  customer_id = body.customer_id;
  let order_record;
  order_record = await model
    .find()
    .skip(page * limit)
    .limit(limit)
    .sort({ increment_id: -1 });
  if (body.order_multiple_select == "y" && body.seller_id) {
    order_str = body.order_status;
    seller_id = body.seller_id;
    order_record = await model
      .find({
        order_status: { $in: [8, 9, 10] },
        seller_id: body.seller_id,
      })
      .skip(page * limit)
      .limit(limit)
      .sort({ increment_id: -1 });
  } else if (body.order_multiple_select == "y") {
    order_record = await model
      .find({ order_status: { $in: [8, 9, 10] } })
      .skip(page * limit)
      .limit(limit)
      .sort({ increment_id: -1 });
  } else {
    if (body.seller_id) {
      seller_id_request = body.seller_id;
      if (seller_id_request) {
        order_record = await model
          .find({
            cartitem: {
              $elemMatch: { seller_id: seller_id_request },
            },
          })
          .skip(page * limit)
          .limit(limit)
          .sort({ increment_id: -1 });
      }
      if (body.order_status && seller_id_request) {
        order_record = await model
          .find({
            cartitem: {
              $elemMatch: { seller_id: seller_id_request },
            },
            order_status: body.order_status,
          })
          .skip(page * limit)
          .limit(limit)
          .sort({ increment_id: -1 });
      }
    } else if (customer_id) {
      order_record = await model
        .find({
          customer_id: customer_id,
        })
        .skip(page * limit)
        .limit(limit)
        .sort({ increment_id: -1 });
    } else if (body.order_status) {
      order_record = await model
        .find({
          order_status: body.order_status,
        })
        .skip(page * limit)
        .limit(limit)
        .sort({ increment_id: -1 });
    } else {
      order_record = await model
        .find()
        .skip(page * limit)
        .limit(limit)
        .sort({ increment_id: -1 });
    }
  }
  if (body.order_status && body.customer_id) {
    order_record = await model
      .find({
        order_status: body.order_status,
        customer_id: customer_id,
      })
      .skip(page * limit)
      .limit(limit)
      .sort({ increment_id: -1 });
  }
  if (order_record.length) {
    for (i = 0; i < order_record.length; i++) {
      order_item = order_record[i];
      cartItems = order_item.cartitem;

      if (cartItems.length) {
        for (j = 0; j < cartItems.length; j++) {
          cartItem = cartItems[j];
          seller_id = cartItem.seller_id;

          if (seller_id) {
            let sellerData = await User.findOne({ _id: seller_id });
            sellerObj = {
              _id: sellerData._id,
              name: sellerData.name,
              email: sellerData.email,
              mobile_no: sellerData.mobile_no,
              profile_pic: sellerData.profile_pic,
              cover_image: sellerData.cover_image,
            };
            cartItems[j].seller_id = sellerObj;
          }
        }
      }
    }
  }
  if (body.order_status == 0) {
    order_record = await model
      .find({
        status: 0,
      })
      .skip(page * limit)
      .limit(limit)
      .sort({ increment_id: -1 });
  }
  if (body.order_status == 0 && body.seller_id) {
    order_record = await model
      .find({
        status: 0,
        cartitem: {
          $elemMatch: { seller_id: body.seller_id },
        },
      })
      .skip(page * limit)
      .limit(limit)
      .sort({ increment_id: -1 });
  }
  //  console.log(order_record);
  if (order_record) {
    ResponseService.generalPayloadResponse(null, order_record, res);
  } else {
    order_record = "your order is empty";
    ResponseService.generalPayloadResponse(null, cart_record, res);
  }
  return;
};
async function validateCoupon(coupon_code, customer_id, cart_amount) {
  coupon_code = coupon_code.toUpperCase();
  cp = await Coupon.findOne({ coupon_code: coupon_code });
  console.log(cp);

  is_valid = true;
  v_s = {
    is_valid: true,
    msg: "Coupon Applied",
  };
  if (cp) {
    var current_date = format(new Date(), "yyyy-MM-dd");
    var from_date = dateparser(cp.start_date);
    var end_date = dateparser(cp.end_date);
    cph = await CouponHistory.find({ coupon_code: coupon_code });
    cphs = await CouponHistory.find({
      coupon_code: coupon_code,
      customer_id: customer_id,
    });
    if (cp.is_active == 0) {
      is_valid = false;
      v_s = {
        is_valid: false,
        msg: "Coupon is already used",
      };
    }
    if (cph && cph.length >= cp.uses_per_coupon) {
      is_valid = false;
      v_s = {
        is_valid: false,
        msg: "Coupon is already used",
      };
    }
    if (cphs && cphs.length >= cp.uses_per_customer) {
      is_valid = false;
      v_s = {
        is_valid: false,
        msg: "Coupon is Out of Stock, Try with Different Coupon",
      };
    }
    if (current_date > end_date || current_date < from_date) {
      is_valid = false;
      v_s = {
        is_valid: false,
        msg: "Coupon is Expired",
      };
    }

    if (cp.min_amount > 0) {
      // console.log('min amount greater 0 ,cart ' + cart_amount);

      if (cp.min_amount > cart_amount) {
        is_valid = false;

        msg = "To apply that coupon cart value has to be min " + cp.min_amount;
        v_s = {
          is_valid: false,
          msg: msg,
        };
      }
    }
    if (cp.max_amount > 0) {
      if (cp.max_amount < cart_amount) {
        is_valid = false;
        msg = "Coupon is only value up to cart value of  " + cp.max_amount;
        v_s = {
          is_valid: false,
          msg: msg,
        };
      }
    }
    if (is_valid) {
      if (cp.coupon_type == "percent") {
        cp_amt = cp.amount;
        discount = (cart_amount * cp_amt) / 100;
        discount = parseFloat(discount).toFixed(2);
      } else {
        discount = cp.amount;
      }
      v_s = {
        is_valid: true,
        discount: discount,
        msg: "Coupon Applied",
      };
    }
  } else {
    discount = 0;
    console.log("coupon code not found");

    v_s = {
      is_valid: false,
      msg: "Invalid Coupon Code",
    };
  }
  return v_s;
}
exports.getById = async function (req, res) {
  model = new Order();
  let OrderId = req.params.id;
  let order_record = await Order.findById(OrderId);
  cartItems = order_record.cartitem;
  if (cartItems.length) {
    for (j = 0; j < cartItems.length; j++) {
      cartItem = cartItems[j];
      seller_id = cartItem.seller_id;

      if (seller_id) {
        let sellerData = await User.findOne({ _id: seller_id });
        sellerObj = {
          _id: sellerData._id,
          name: sellerData.name,
          email: sellerData.email,
          mobile_no: sellerData.mobile_no,
          profile_pic: sellerData.profile_pic,
          cover_image: sellerData.cover_image,
        };
        cartItems[j].seller_id = sellerObj;
      }
    }
  }
  ResponseService.generalPayloadResponse(null, order_record, res);
  return;
};

exports.changeorderstatus = async function (req, res) {
  model = new Order();
  let OrderId = req.params.id;
  body = req.body;
  cart_record = "";
  msg = "Something Went wrong try again later";

  // 1 - order placed, 2 - packed , 2- shipped, 3- delivered, 4 - cancel by customer ,5- return by customer
  // 6- return accepted , 7- refund done , 8- return rejected ,9- order cancel by admin
  let order_record = await Order.findById(OrderId);
  // console.log(order_record);
  if (body.customer_id && body.order_status && OrderId) {
    order_status = body.order_status;
    current_status = order_record.order_status;
    current_track_detail = order_record.tracking_detail;
    order_place_time = order_record.created_at;
    product_id = body.product_id;
    cart_item = order_record.cartitem;
    order_increment_id = order_record.increment_id;
    user_mobile_no = order_record.address.mobile_no;

    first_product_id = cart_item[0].product_id;
    first_product_name = cart_item[0].name;
    expected_delivery_date = order_record.expected_delivery_date;
    order_customer_id = order_record.customer_id;
    track_msg = "";
    s_ok = false;
    o_refill = false;

    admin_mobile_no = 9001025477;

    s_ok = true;
    if (s_ok) {
      order_p = false;
      // 1 - order placed, 2 - packed , 3- shipped, 4- delivered, 5 - cancel by customer ,6- return by customer
      // 7- return accepted , 8- refund done , 9- return rejected,10- cancel by admin, 11- failed due to not pickup by customer
      console.log("order current status", current_status);
      switch (order_status) {
        case 2:
          if (current_status >= 1 && current_status < 2) {
            order_p = true;
          } else {
            ResponseService.generalPayloadResponse(
              null,
              "Change order status not allowed",
              res
            );
            return;
          }
          break;
        case 3:
          if (current_status >= 2 && current_status < 3) {
            // out for delivery
            if (cart_item.length > 1) {
              other_str =
                "Out for delivery: Order for " +
                first_product_name.substring(0, 20) +
                " ... & " +
                (cart_item.length - 1) +
                " more item is ready to deliver & will be delivered by " +
                expected_delivery_date;
            } else {
              other_str =
                "Out for delivery: Order for " +
                first_product_name.substring(0, 20) +
                "... is ready to deliver & will be delivered by " +
                expected_delivery_date;
            }
            track_msg = "Out for delivery";
            order_p = true;
          } else {
            ResponseService.generalPayloadResponse(
              null,
              "Change order status not allowed",
              res
            );
            return;
          }
          break;
        case 4:
          if (current_status >= 3 && current_status < 4) {
            // order delivered
            if (cart_item.length > 1) {
              other_str =
                "Deliverd: Order for " +
                first_product_name.substring(0, 20) +
                " ... & " +
                (cart_item.length - 1) +
                " more item is  deliverd, thanks for using etonix";
            } else {
              other_str =
                "Deliverd: Order for " +
                first_product_name.substring(0, 20) +
                "... is deliverd & thanks for using etonix";
            }
            track_msg = "Delivered";
            order_p = true;
          } else {
            ResponseService.generalPayloadResponse(
              null,
              "Change order status not allowed",
              res
            );
            return;
          }
          break;
        case 5:
          if (current_status >= 3 && current_status < 5) {
            // return requested
            order_p = true;
            if (cart_item.length > 1) {
              other_str =
                "Order Cancelled: Order for " +
                first_product_name.substring(0, 20) +
                " ... & " +
                (cart_item.length - 1) +
                " more item Cancelled,Still if you need any support you can contact us.";
            } else {
              other_str =
                "Order Cancelled: Order for " +
                first_product_name.substring(0, 20) +
                "... Cancelled,Still if you need any support you can contact us.";
            }
            track_msg = "Order Cancelled";
            o_refill = true;
          } else {
            ResponseService.generalPayloadResponse(
              null,
              "After Shippment Order Cancel not allowed",
              res
            );
            return;
          }
          break;
        case 6:
          if (current_status >= 3 && current_status < 4) {
            // return requsted
            order_p = true;
            if (cart_item.length > 1) {
              other_str =
                "Return Requested: Order for " +
                first_product_name.substring(0, 20) +
                " ... & " +
                (cart_item.length - 1) +
                " more item return request is created,Still if you need any support you can contact us.";
            } else {
              other_str =
                "Return Requested: Order for " +
                first_product_name.substring(0, 20) +
                "... return request is created,Still if you need any support you can contact us.";
            }
            track_msg = "Return Request Created";
            break;
          } else {
            ResponseService.generalPayloadResponse(
              null,
              "Change order status not allowed",
              res
            );
            return;
          }
          break;
        case 7:
          if (current_status >= 6 && current_status < 7) {
            // return accepted
            if (cart_item.length > 1) {
              other_str =
                "Return Accepted: Order for " +
                first_product_name.substring(0, 20) +
                " ... & " +
                (cart_item.length - 1) +
                " more item return request is Accepted,you will recive you refund with in 7 working days.";
            } else {
              other_str =
                "Return Accepted: Order for " +
                first_product_name.substring(0, 20) +
                "... return request is Accepted,you will recive you refund with in 7 working days.";
            }
            track_msg = "Return Accepted";
            o_refill = true;
            order_p = true;
          } else {
            ResponseService.generalPayloadResponse(
              null,
              "Change order status not allowed",
              res
            );
            return;
          }
          break;
        case 8:
          // payment refund
          order_p = true;
          if (cart_item.length > 1) {
            other_str =
              "Payment Refund: Order for " +
              first_product_name.substring(0, 20) +
              " ... & " +
              (cart_item.length - 1) +
              " more item refund payment is done, Thanks to using Supernebr";
          } else {
            other_str =
              "Payment Refund: Order for " +
              first_product_name.substring(0, 20) +
              "... return refund payment is done, Thanks to using Supernebr";
          }
          track_msg = "Payment Refuned For order";
          break;
        case 9:
          order_p = true;
          track_msg = "Return Canncelled By Admin";
          break;
        case 10:
          order_p = true;
          o_refill = true;
          track_msg = "Order Cancelled By Admin";
          break;
        case 11:
          order_p = true;
          o_refill = true;
          track_msg = "Failed to deliverd Due to not pickup";
          break;
      }
      if (order_p) {
        if (body.order_status) {
          order_record.order_status = body.order_status;
        }
        if (body.rejection_point) {
          order_record.rejection_point = body.rejection_point;
        }
        if (body.comment) {
          order_record.comment = body.comment;
        }
        query = {};
        current_Time = moment();
        trac_d = {
          track_msg: track_msg,
          track_code: "",
          created_time: current_Time,
          creater_id: body.customer_id,
        };
        console.log(OrderId);
        query.$addToSet = { tracking_detail: trac_d };

        Order.findByIdAndUpdate(OrderId, query, { new: true }, (err, doc) => {
          console.log("status update");
        });
        order_record.save(async function (err, val) {
          const customerUser = await User.findById(body.customer_id);

          notifcation_ids = customerUser.notification_id;

          if (user_mobile_no && other_str) {
            res2 = sendotp(other_str, user_mobile_no);
          }

          if (notifcation_ids.length > 0) {
            NotificationService.sendByUserId(
              other_str,
              "Order Status Changed",
              body.customer_id,
              null
            );
          }

          if (admin_mobile_no && other_str) {
            res2 = sendotp(other_str, user_mobile_no);
          }
          if (o_refill) {
            // refill order item to product inventory
            cart_item = order_record.cartitem;
            for (i = 0; i < cart_item.length; i++) {
              element = cart_item[i];
              if (element) {
                qty = parseInt(element.qty);
                product_id = element.product_id;
                p = await Product.findOne({ _id: product_id }).select(
                  "price product_en special_price from_Date to_date icon multiseller"
                );

                if (typeof p._id !== typeof undefined) {
                  old_stock = p.pending_stock;
                  p.pending_stock = old_stock + qty;
                  stock_data = {
                    stock_value: qty,
                    s_type: "in",
                    comment:
                      "Product reffil for order id: " + order_increment_id,
                  };

                  query = {};
                  query.$addToSet = { stock_data: stock_data };
                  Product.findByIdAndUpdate(
                    product_id,
                    query,
                    { new: true },
                    (err, doc) => {
                      console.log("stock Data updated");
                    }
                  );
                  p.save((err, result) => {
                    console.log("p stock updated");
                  });

                  // send push notification & sms to seller for order
                }
              }
            }
          }
          ResponseService.generalPayloadResponse(err, order_record, res);
        });
        return;
      } else {
        ResponseService.generalPayloadResponse(null, msg, res);
        return;
      }
    } else {
      order_record = "Invalid Access for order";
      ResponseService.generalPayloadResponse(null, order_record, res);
      return;
    }
  } else {
    order_record = "Invalid Access";
    ResponseService.generalPayloadResponse(null, order_record, res);
    return;
  }
};

function addDays(d, qty) {
  var newDate = new Date(d.getTime()); // Copy date
  newDate.setDate(d.getDate() + qty);
  return newDate;
}

exports.viewInvoice = (req, res) => {
  const invoice = {
    shipping: {
      name: "Shipping Name",
      phone: "123838223",
      address: "1234 Main Street",
      city: "San Francisco",
      state: "CA",
      country: "US",
      postal_code: 94111,
    },
    items: [
      {
        name: "TC 100",
        qty: 2,
        subtotal: 6000,
      },
      {
        name: "USB_EXT",
        qty: 1,
        subtotal: 2000,
      },
    ],
    subtotal: 8000,
    paid: 0,
    invoice_nr: 1234,
  };

  let invoices = [invoice];

  createInvoice(invoices, "./uploads/invoice/invoic.pdf");

  return ResponseService.generalPayloadResponse(null, invoice, res);
};

createInvoice = (invoices, dirPath, fname) => {
  const notoPath = fs.readFileSync(
    path.resolve(__dirname, "../shared/fonts/noto/NotoSans-Regular.ttf")
  );
  const notoBoldPath = fs.readFileSync(
    path.resolve(__dirname, "../shared/fonts/noto/NotoSans-Bold.ttf")
  );

  let doc = new PDFDocument({ margin: 50 });
  doc.registerFont("Noto Sans", notoPath);
  doc.registerFont("Noto Sans-Bold", notoBoldPath);
  invoices.forEach((invoice, index) => {
    if (index != 0) doc.addPage();
    generateHeader(doc, invoice);
    generateCustomerInformation(doc, invoice);
    generateInvoiceTable(doc, invoice);
  });
  // generateFooter(doc);
  doc.end();
  // doc.pipe(fs.createWriteStream(dirPath));

  // const fileContent = fs.createReadStream(dirPath);
  /*let s3bucket = new AWS.S3({
		accessKeyId: IAM_USER_KEY,

		secretAccessKey: IAM_USER_SECRET,
		Bucket: BUCKET_NAME
	});*/
  // let s3bucket = new AWS.S3();

  // var params = {
  // 	Bucket: BUCKET_NAME,
  // 	Key: invoice.invoice_no + invoice.order.order_id + '.pdf',
  // 	Body: doc,
  // 	ACL: 'public-read',
  // 	contentType: 'application/pdf'
  // };
  const BUCKET_NAME = "humbleirde";
  const IAM_USER_KEY = "AKIAZJT24CTPDMWJYDEK";
  const IAM_USER_SECRET = "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";
  let s3bucket = new AWS.S3({
    accessKeyId: IAM_USER_KEY,
    secretAccessKey: IAM_USER_SECRET,
    Bucket: BUCKET_NAME,
  });
  var params = {
    Bucket: BUCKET_NAME,
    Key: invoice.invoice_no + invoice.order.order_id + ".pdf",
    Body: doc,
    ACL: "public-read",
    contentType: "application/pdf",
  };

  // Uploading files to the bucket
  s3bucket.upload(params, async function (err, data) {
    if (err) {
      throw err;
    }
    console.log(data.location);
  });
};

function generateHeader(doc, invoice) {
  doc
    .image("./shared/logo/logo.png", 50, 45, { width: 100 })
    .fillColor("#444444")
    .fontSize(10)
    .text("Chouhan rugs", 200, 50, { align: "right" })
    .text("Jaipur", 200, 65, { align: "right" })
    .text("Rajasthan,India", 200, 80, { align: "right" })
    .moveDown()
    // .font("Noto Sans-Bold")
    // .text("Sold By: " + invoice.seller.name, 50, 100)
    // .text("Seller Address: ", 50, 115)
    // .font("Noto Sans")
    // .text(invoice.seller.address_1, 125, 115)
    // .text(invoice.seller.address_2, 125, 130)
    .font("Noto Sans-Bold")
    .text("GSTIN - ", 50, 145)
    .font("Noto Sans")
    .text(invoice.seller.gstin, 90, 145)
    .font("Noto Sans-Bold")
    .text("Invoice No: " + invoice.invoice_nr, 200, 100, { align: "right" })
    .moveDown();
}

// function generateFooter(doc) {
// 	doc
// 		.fontSize(10)
// 		.text(
// 			"Payment is due within 15 days. Thank you for your business.",
// 			50,
// 			780,
// 			{ align: "center", width: 500 }
// 		);
// }

function generateCustomerInformation(doc, invoice) {
  doc
    .fillColor("#444444")
    .fontSize(20)
    .text("Invoice", 50, 160 + 16);

  generateHr(doc, 185 + 16);

  const customerInformationTop = 200 + 16;

  doc
    .fontSize(10)
    .font("Noto Sans-Bold")
    .text("Order ID:", 50, customerInformationTop)
    .text(invoice.order.order_id, 120, customerInformationTop)
    .text("Order Date:", 50, customerInformationTop + 15)
    .font("Noto Sans")
    .text(
      moment(invoice.order.order_date).format("YYYY-MM-DD"),
      120,
      customerInformationTop + 15
    )
    .font("Noto Sans-Bold")
    .text("Invoice Date:", 50, customerInformationTop + 30)
    .font("Noto Sans")
    .text(invoice.order.invoice_date, 120, customerInformationTop + 30)
    // .font("Noto Sans-Bold")
    // .text("PAN:", 50, customerInformationTop + 45)
    // .font("Noto Sans")
    // .text(invoice.order.pan, 120, customerInformationTop + 45)

    .font("Noto Sans-Bold")
    // .text("Bill To", 270, customerInformationTop)
    // .text(invoice.billing.name, 270, customerInformationTop + 15)
    // .font("Noto Sans")
    // .text(invoice.billing.address_1, 270, customerInformationTop + 30)
    // .text(invoice.billing.address_2, 270, customerInformationTop + 45)
    // .text(invoice.billing.contact, 270, customerInformationTop + 60)

    // .font("Noto Sans-Bold")
    .text("Ship To", 430, customerInformationTop)
    .text(invoice.shipping.name, 430, customerInformationTop + 15)
    .font("Noto Sans")
    .text(invoice.shipping.address_1, 430, customerInformationTop + 30)
    .text(invoice.shipping.address_2, 430, customerInformationTop + 45)
    .text("Phone: " + invoice.shipping.phone, 430, customerInformationTop + 60)
    .moveDown();

  generateHr(doc, 280 + 16);
}

function generateTableRow(doc, y, sno, c1, c2, c3, c4, c5, c6) {
  doc
    .fontSize(10)
    .text(sno, 50, y)
    .text(c1, 110, y, { width: 140 })
    .text(c2, 250, y, { width: 50 })
    .text(c3, 300, y, { width: 50 })
    .text(c4, 350, y, { width: 50, align: "right", lineBreak: false })
    .text(c5, 420, y, { lineBreak: false })
    .text(c6, 0, y, { align: "right" });
}

function generateInvoiceTable(doc, invoice) {
  let i;
  const invoiceTableTop = 330 + 16;

  doc.font("Noto Sans-Bold");
  generateTableRow(
    doc,
    invoiceTableTop,
    "S.No.",
    "Product Name",
    "Price",
    "Quantity",
    "CGST",
    "IGST",
    "Amount"
  );
  generateHr(doc, invoiceTableTop + 20);
  doc.font("Noto Sans");
  flag = false;
  for (i = 0; i < invoice.items.length; i++) {
    const item = invoice.items[i];
    const position = invoiceTableTop + (i + 1) * 30;
    generateTableRow(
      doc,
      position,
      i + 1,
      item.name,
      formatCurrency(item.subtotal / item.qty),
      item.qty,
      item.cgst,
      item.igst,
      formatCurrency(item.subtotal)
    );
    if (item.name.length > 28) flag = true;
    generateHr(doc, item.name.length > 28 ? position + 30 : position + 20);
  }

  const subtotalPosition = flag
    ? invoiceTableTop + (i + 1) * 30 + 10
    : invoiceTableTop + (i + 1) * 30;
  generateTableRow(
    doc,
    subtotalPosition,
    "",
    "",
    "",
    "",
    "",
    "Subtotal",
    formatCurrency(invoice.subtotal)
  );

  const paidToDatePosition = subtotalPosition + 20;
  generateTableRow(
    doc,
    paidToDatePosition,
    "",
    "",
    "",
    "",
    "",
    "Paid To Date",
    formatCurrency(invoice.paid)
  );

  const duePosition = paidToDatePosition + 25;
  doc.font("Noto Sans-Bold");
  generateTableRow(
    doc,
    duePosition,
    "",
    "",
    "",
    "",
    "",
    "Balance Due",
    formatCurrency(invoice.subtotal - invoice.paid)
  );
  doc.font("Noto Sans");
}

function generateHr(doc, y) {
  doc.strokeColor("#aaaaaa").lineWidth(1).moveTo(50, y).lineTo(560, y).stroke();
}

function formatCurrency(paisa) {
  return "\u20B9" + Number(paisa).toFixed(2);
}
