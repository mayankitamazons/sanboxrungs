const ResponseService = require('../shared/ResponseService'); // Response service
const Event = require('../models/Event'); // Attr option model
const User = require('../models/User'); // Attr option model
const CRUD = require('../shared/CRUD');
const moment = require('moment-timezone');

exports.getById = async function(req, res) {
    model = new Event;
    let EventId = req.params.id;
    let EventRecords = await Event.findById(EventId).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").populate('seller_id', "username name profile_pic");
    // console.log(BlogRecords);
    EventRecords.createdTime = moment(EventRecords.created_date).fromNow(true);
    let loggedInUser;
    let userRecord;
    if (req.body.login_userid) {
        loggedInUser = req.body.login_userid;
        userRecord = await User.findById(loggedInUser);

    } else {
        loggedInUser = '';
    }

    if (EventRecords) {
        ResponseService.generalPayloadResponse(null, EventRecords, res);
        return;
    } else {
        EventRecords = {};
        ResponseService.generalPayloadResponse(null, EventRecords, res);
        return;
    }

}
exports.getBySlug = async function(req, res) {
    model = new Event;
    let slug = req.params.slug;
    let EventRecords = await Event.find({ "slug": slug }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").populate('seller_id', "username name profile_pic");
    // console.log(BlogRecords);
    EventRecords.createdTime = moment(EventRecords.created_date).fromNow(true);
    let loggedInUser;
    let userRecord;
    if (req.body.login_userid) {
        loggedInUser = req.body.login_userid;
        userRecord = await User.findById(loggedInUser);

    } else {
        loggedInUser = '';
    }

    if (EventRecords) {
        ResponseService.generalPayloadResponse(null, EventRecords, res);
        return;
    } else {
        EventRecords = {};
        ResponseService.generalPayloadResponse(null, EventRecords, res);
        return;
    }

}
exports.add = async function(req, res) {

    let creater_id = req.body.creater_id;
    body = req.body;
    var customSlug;
    var d = new Date();
    var time = d.getTime();
    if (body.slug) {

        //check slug exists or not

        let EventData = await Event.find({ "slug": body.slug });
        let existsData = EventData[0];

        if (EventData.length) {
            customSlug = existsData.slug + "-" + time;
        } else {
            customSlug = body.slug;
        }

    } else {

        customSlug = CRUD.convertToSlug(body.title);
        let EventData = await Event.find({ "slug": customSlug });
        let existsData = EventData[0];

        if (EventData.length) {
            customSlug = existsData.slug + "-" + time;
        } else {
            customSlug = customSlug + "-" + time;
        }
    }
    req.body.slug = customSlug;
    const model = new Event(req.body);
    let EventData = await model.save();

    ResponseService.generalPayloadResponse(null, EventData, res);
    return;
    //    model.save((err, val) => {
    //        ResponseService.generalPayloadResponse(err, val, res);
    //        return;
    //    });
}
exports.list = async function(query, limit, page, type, body, res) {

    const model = Event;
    var EventData;
    //console.log(page);
    if (body.status) {
        EventData = await model.find({ status: body.status }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").populate('seller_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
    }
    if (body.creater_id) {
        EventData = await model.find({ creater_id: body.creater_id }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").populate('seller_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });

    }
    if (body.community_id) {

        EventData = await model.find({ "community_id": { $in: body.community_id } }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").populate('seller_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
    }

    ResponseService.generalPayloadResponse(null, EventData, res);
}

exports.share = async function(id, res) {
    const model = Event;

    var EventData = await model.findById(id);
    EventData.share_count = EventData.share_count + 1;

    EventData.save(function(err, result) {
        if (err) {
            ResponseService.generalResponse("Something went wrong, please try again.", result, 401, "Something went wrong, please try again");
            return;
        } else {
            ResponseService.generalPayloadResponse(err, result, res);
            return;
        }
    });
}