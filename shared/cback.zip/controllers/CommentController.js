const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model
const Blog = require('../models/Blog'); // User model
const Comment = require('../models/Comment'); // Topic model
const mongoose = require('mongoose');
const CRUD = require('../shared/CRUD');
const moment = require('moment-timezone');
const Notification = require('../models/Notification'); // Notification model
// Notification service
const NotificationService = require('../shared/NotificationService')

function convertTimeStampTodate(unixtimestamp) {
    sourceEpoch = parseInt(unixtimestamp);


    if (sourceEpoch <= 9999999999) {
        sourceEpoch *= 1000;
    }
    var date = new Date(sourceEpoch);
    return date.toLocaleString();

}
exports.commentListing = async function(req, res) {

    if (req.body.blogid) {
        let loggedInUser;
        //let userRecord;
        if (req.body.login_userid) {
            loggedInUser = req.body.login_userid;
            // userRecord = await User.findById(loggedInUser);

        } else {
            loggedInUser = '';
        }

        try {
            const commentRecords = await Comment.find({ blogid: req.body.blogid }).populate('userlikes', "username name profile_pic").populate('userid', "username name profile_pic").populate('blogid', "title description slug pictures status comment_count likes_count");
            ResponseService.generalPayloadResponse(null, commentRecords, res);
            return;
            //const CommentData = await Comment.find({videoid: req.body.videoid}).populate('userlikes', "username name profile_pic").populate('userid', "username name profile_pic").populate('videoid', "title cover_image comment_status videoUrl");
            //ResponseService.generalPayloadResponse(null, CommentData, res, );
            //return;
        } catch (err) {
            ResponseService.generalPayloadResponse(err, {}, res);
        }
    } else {
        ResponseService.generalPayloadResponse("Blog id is required", {}, res);

        return;
    }
}
exports.addComment = async function(req, res) {

    query = {};
    var saveRecords = new Comment;

    if (req.body.blogid) {
        var userRecords = await User.findById(req.body.userid);
        var blogRecords = await Blog.findById(req.body.blogid);
        let NoticeModel = new Notification;
        var creator_user_id = blogRecords.creater_id;
        var creatorRecords = await User.findById(creator_user_id);
        NoticeModel.noti_type = 3;
        NoticeModel.left_key = userRecords._id;
        NoticeModel.user = req.body.userid;
        NoticeModel.right_key = blogRecords._id;
        NoticeModel.left_action = 2;
        NoticeModel.left_image = userRecords.profile_pic;
        NoticeModel.right_action = 3;
        NoticeModel.right_image = blogRecords.cover_image;
        NoticeModel.noti_title = userRecords.name + " Commented on your blog"
        NoticeModel.noti_sub_title = "";

        if (NoticeModel) {
            console.log(NoticeModel);
            NoticeModel.save();
            console.log("Nofitication saved successfully.")

        }
        if (creatorRecords.notification_id) {
            const result = await NotificationService.sendToUserList(`${userRecords.name} Commented on your Blog`, "Comment on Blog...", creatorRecords.notification_id,
                NoticeModel);
        }
        saveRecords.blogid = req.body.blogid;
        saveRecords.userid = req.body.userid;
        saveRecords.comment = req.body.comment;

        saveRecords.save(async function(err, result) {
            if (err) {

                ResponseService.generalResponse("Something went wrong, please try again.", result, 401, "Something went wrong, please try again");
                return;
            } else {

                var BlogData = await Blog.findById(saveRecords.blogid);

                BlogData.comment_count = BlogData.comment_count + 1;

                BlogData.save();
                ResponseService.generalPayloadResponse(err, saveRecords, res);
                return;
            }
        });
    } else {
        ResponseService.generalResponse("Blog id is required.", result, 401, "Blog id is required");
        return
    }
}


exports.updateComment = async function(req, res) {
    if (req.body.commentid) {

        try {
            const CommentData = await Comment.findById(req.body.commentid);
            CommentData.comment = req.body.comment;



            CommentData.save(function(err, result) {
                if (err) {
                    ResponseService.generalResponse("Something went wrong, please try again.", result, 401, "Something went wrong, please try again");
                    return;
                } else {
                    ResponseService.generalPayloadResponse(err, result, res);
                    return;
                }
            });

        } catch (err) {
            ResponseService.generalPayloadResponse(err, {}, res);
        }
    }
}





exports.getuserdata = async function(req, res) {
    if (req.body.user) {
        try {
            const userData = await User.findById(req.body.user);
            const BlogData = await Blog.find({ creator_id: req.body.user });
            const response = [];
            response.push({ "userData": userData, "videoData": VideoData });
            ResponseService.generalPayloadResponse(null, response, res, );
        } catch (err) {
            ResponseService.generalPayloadResponse(err, {}, res);
        }
    }
}
exports.notificationID = function(req, res) {
    query = {};
    if (req.body.isAdd) {
        query.$addToSet = { notification_id: req.body.notification_id }
    } else {
        query.$pull = { notification_id: req.body.notification_id }
    }
}