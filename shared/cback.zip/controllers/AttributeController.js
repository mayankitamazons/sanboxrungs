const ResponseService = require('../shared/ResponseService'); // Response service
const Attribute = require('../models/Attribute'); // Attr option model

const CRUD = require('../shared/CRUD');


exports.attributelist = async function (query, limit, page, type, body, res) {
    // category list has filter of sub category id, isTredning, Creator id
    const model = Attribute;
    var AttributeData;

    if (body.status) {
        AttributeData = await model.find({status: body.status}).populate('AttributeStyle', "style_name comment");
    }
    ResponseService.generalPayloadResponse(null, AttributeData, res);
    return;
}