const ResponseService = require('../shared/ResponseService'); // Response service
const Block = require('../models/Block'); // Block model
const Item = require('../models/Item'); // Item model
const Category = require('../models/Category'); // Item model
const Tree = require('../models/Tree'); // Item model

const CRUD = require('../shared/CRUD');

exports.blockList = async function (req, res) {
    const idOfjohn = '1234567890abcdef';
    let john, children, grandchildren; // initialise variables

    Tree.findById(idOfjohn) // find John
            .then(user => {
                john = user; // assign to variable with wider scope

                return Tree.find({manager: idOfjohn}); // find users whose manager is John
            })
            .then(users => {
                children = users;
                const childrenIDs = users.map(user => user._id); // make array of IDs

                return Tree.find({manager: {$in: childrenIDs}}); // find users whose managers have John as a manager
            })
            .then(users => {
                grandchildren = users;

                const all = [john]
                        .concat(children)
                        .concat(grandchildren); // create a single array

                console.log(all); // or do whatever
            });
}