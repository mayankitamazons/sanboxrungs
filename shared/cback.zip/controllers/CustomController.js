const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model

const Category = require('../models/Category'); // Topic model

const CRUD = require('../shared/CRUD');

exports.add = async function (query, limit, page, body, res) {
    var params={"data":"add product"};
    ResponseService.generalPayloadResponse(null, params, res);
}
//category id can be main category id and subcategory id

exports.categorylist = async function (query, limit, page, type, body, res) {
    // category list has filter of sub category id, isTredning, Creator id
    // Attribue listing have issue
    const model = Category;

    var CategoryData;

    if (body.isTrending) {
        CategoryData = await model.find({isTrending: true}).populate('sub_category_id', "title slug icon sub_category_id description image isTrending store_id status show_menu").populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({_id: -1});
    }
    if (body.creater_id) {
        CategoryData = await model.find({creater_id: true}).populate('sub_category_id', "title slug icon sub_category_id description image isTrending store_id status show_menu").populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({_id: -1});
    }
    if (body.status) {
        CategoryData = await model.find({status: body.status}).populate('sub_category_id', "title slug icon sub_category_id description image isTrending store_id status show_menu").populate('creater_id', "name profile_pic email community_id").populate('sellerid', "name profile_pic email community_id").skip(page * limit).limit(limit).sort({_id: -1});
    }

    ResponseService.generalPayloadResponse(null, CategoryData, res);
}