const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model

const CRUD = require('../shared/CRUD');
const { compareSync } = require('bcryptjs');
const Payment = require('../models/Payment');


exports.add = async function(req, res) {

    var body = req.body;
    
    model = Payment;
    result = new model(body);      
    result.save(function(err, val) {
        if (err) {
            console.log(err);
        } else {
            console.log("Payment method added successfully");
        }
        ResponseService.generalPayloadResponse(null, val, res);
    });
}

exports.update = async function(req, res) {
    model = Payment;
    let id = req.body.id
    var saveRecords = await model.findById(id);
    if (req.body.name) {
        saveRecords.name = req.body.name;
    }
    if (req.body.code) {
        saveRecords.code = req.body.code;
    }
    if (req.body.is_active) {
        saveRecords.is_active = req.body.is_active;
    }
    saveRecords.save((err, result) => {
        ResponseService.generalPayloadResponse(err, result, res);
    });
    return;
}

exports.getPaymentMethods = async function(query, limit, page, type, body, res) {

    const model = Payment;
    let data = await model.find();
    ResponseService.generalPayloadResponse(null, data, res);
    return
}