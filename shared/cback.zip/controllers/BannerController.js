const ResponseService = require('../shared/ResponseService'); // Response service
const Banner = require('../models/Banner'); // Attr option model

const CRUD = require('../shared/CRUD');

exports.add = async(req, res) => {

    let creater_id = req.body.creater_id;
    body = req.body;
    var customSlug;
    var d = new Date();
    var time = d.getTime();
    if (body.slug) {

        //check slug exists or not

        let BannerData = await Banner.find({ "slug": body.slug });
        let existsData = BannerData[0];

        if (BannerData.length) {
            customSlug = existsData.slug + "-" + time;
        } else {
            customSlug = body.slug;
        }

    } else {

        customSlug = CRUD.convertToSlug(body.title);
        let BannerData = await Banner.find({ "slug": customSlug });
        let existsData = BannerData[0];

        if (BannerData.length) {
            customSlug = existsData.slug + "-" + time;
        } else {
            customSlug = customSlug + "-" + time;
        }
    }
    req.body.slug = customSlug;

    // let previousbanner = await Banner.find({ "slug": customSlug });
    // check with previous banner if exit then update that 
    const model = new Banner(req.body);
    let BannerData = await model.save();

    ResponseService.generalPayloadResponse(null, BannerData, res);
    return;
    //    model.save((err, val) => {
    //        ResponseService.generalPayloadResponse(err, val, res);
    //        return;
    //    });
}
exports.list = async function(query, limit, page, type, body, res) {
    // category list has filter of sub category id, isTredning, Creator id
    const model = Banner;
    var AttributeData;

    if (body.status || body.status == 0) {
        AttributeData = await model.find({ status: body.status }).populate('community_id', "builder_name name locality pincode city status").populate('category_id', "title slug icon description image status");

    }
    if (body.community_id) {
        AttributeData = await model.find({
            "community_id": {
                $in: body.community_id
            },
            "status": 1
        }).populate('community_id', "builder_name name locality pincode city status").populate('category_id', "title slug icon description image status");
    }

    if (body.community_id && body.category_id) {
        AttributeData = await model.find({
            "category_id": {
                $in: body.category_id
            },
            "community_id": {
                $in: body.community_id
            },
            status: 1
        }).populate('community_id', "builder_name name locality pincode city status").populate('category_id', "title slug icon description image status");
    }

    if (AttributeData == undefined) {
        AttributeData = await model.find({ status: 1 }).populate('community_id', "builder_name name locality pincode city status").populate('category_id', "title slug icon description image status");

    }
    if (AttributeData.length == 0) {
        a_data = {
            "button_action": 1,
            "search_key": "",
            "status": 1,
            "banner_position": 1,
            "banner_for": 2,
            "banner_type": 1,
            "category_id": [],
            "community_id": [],
            "_id": "demobanner",
            "title": "",
            "sub_title": "",
            "button_text": "",
            "image": "https://humbleirde.s3.ca-central-1.amazonaws.com/rugs/logo.png",
            "slug": "-1608717509646",
            "created_date": "2020-12-23T09:58:29.657Z",
            "__v": 0
        };  
        AttributeData.push(a_data);
    }
    ResponseService.generalPayloadResponse(null, AttributeData, res);
    return;
}