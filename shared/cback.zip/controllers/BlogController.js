const ResponseService = require('../shared/ResponseService'); // Response service
const Blog = require('../models/Blog'); // Attr option model
const User = require('../models/User'); // Attr option model
const CRUD = require('../shared/CRUD');
const moment = require('moment-timezone');
const mongoose = require('mongoose');
exports.getById = async function (req, res) {
	model = new Blog;
	let BlogId = req.params.id

	let BlogRecords = await Blog.findById(BlogId).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic");
	// console.log(BlogRecords);
	BlogRecords.createdTime = moment(BlogRecords.created_date).fromNow(true);
	let loggedInUser;
	let userRecord;
	if (req.body.login_userid) {
		loggedInUser = req.body.login_userid;
		userRecord = await User.findById(loggedInUser);

	} else {
		loggedInUser = '';
	}
	//console.log(loggedInUser);
	likes_count = BlogRecords.userlikes.length;
	BlogRecords.likes_count = likes_count;
	if (loggedInUser) {
		if (BlogRecords.userlikes[0]) {
			userlikes = BlogRecords.userlikes[0];
			if (mongoose.Types.ObjectId(loggedInUser).equals(mongoose.Types.ObjectId(userlikes._id))) {
				BlogRecords.isLike = true;
			}
		} else {
			BlogRecords.isLike = false;

		}

	} else {
		BlogRecords.isLike = false;

	}
	if (BlogRecords) {
		ResponseService.generalPayloadResponse(null, BlogRecords, res);
		return;
	} else {
		BlogRecords = {};
		ResponseService.generalPayloadResponse(null, BlogRecords, res);
		return;
	}

}
exports.getBySlug = async function (req, res) {
	model = new Blog;
	let slug = req.params.slug;
	let BlogRecords = await Blog.find({ "slug": slug }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic");
	BlogRecords.createdTime = moment(BlogRecords.created_date).fromNow(true);
	let loggedInUser;
	let userRecord;
	if (req.body.login_userid) {
		loggedInUser = req.body.login_userid;
		userRecord = await User.findById(loggedInUser);

	} else {
		loggedInUser = '';
	}
	//    console.log(BlogRecords.userlikes);

	userlikes = BlogRecords[0].userlikes;
	if (userlikes)
		likes_count = userlikes.length;
	else
		likes_count = 0;

	BlogRecords[0].likes_count = likes_count;

	if (loggedInUser && userlikes) {
		likelist = userlikes;
		console.log(likelist);

		likelist.forEach(async (w_l, index) => {
			if (mongoose.Types.ObjectId(w_l).equals(mongoose.Types.ObjectId(loggedInUser))) {
				BlogRecords[0].isLike = true;
			}
		});

	}
	if (BlogRecords) {
		ResponseService.generalPayloadResponse(null, BlogRecords, res);
		return;
	} else {
		BlogRecords = {};
		ResponseService.generalPayloadResponse(null, BlogRecords, res);
		return;
	}

}
exports.addBlog = async function (req, res) {

	let creater_id = req.body.creater_id;
	body = req.body;
	let userRecord = await User.findById(creater_id);
	if (!req.body.community_id)
		req.body.community_id = userRecord.community_id;
	var customSlug;
	var d = new Date();
	var time = d.getTime();
	if (body.slug) {

		//check slug exists or not

		let blogData = await Blog.find({ "slug": body.slug });
		let existsData = blogData[0];

		if (blogData.length) {
			customSlug = existsData.slug + "-" + time;
		} else {
			customSlug = body.slug;
		}

	} else {

		customSlug = CRUD.convertToSlug(body.title);
		let blogData = await Blog.find({ "slug": customSlug });
		let existsData = blogData[0];

		if (blogData.length) {
			customSlug = existsData.slug + "-" + time;
		} else {
			customSlug = customSlug + "-" + time;
		}
	}
	req.body.slug = customSlug;
	if (req.body.pictures.length == 0)
		req.body.pictures = ["https://humbleirde.s3.ca-central-1.amazonaws.com/rugs/logo.png"];

	const model = new Blog(req.body);
	let BlogData = await model.save();
	query = {};
	query.$addToSet = { blogList: BlogData._id };
	User.findByIdAndUpdate(userRecord, query, { new: true }, (err, doc) => {

	});
	ResponseService.generalPayloadResponse(null, BlogData, res);
	return;
	//    model.save((err, val) => {
	//        ResponseService.generalPayloadResponse(err, val, res);
	//        return;
	//    });
}
exports.bloglist = async function (query, limit, page, type, body, res) {

	const model = Blog;
	var Blogdata;

	if (body.limit) {
		limit = body.limit;
	}
	if (body.top_blogs && body.community_id) {

		Blogdata = await model.find({ "community_id": { $in: body.community_id }, "status": 1 })
			.populate('community_id', "builder_name name pincode")
			.populate('creater_id', "name username email userrole profile_pic")
			.skip(page * 4).limit(4).sort({ likes_count: -1, comment_count: -1 });

	} else {
		if (body.status || body.status == '0') {
			Blogdata = await model.find({ status: body.status }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
		}
		if (body.creater_id) {
			Blogdata = await model.find({ creater_id: body.creater_id }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });

		}
		if (body.community_id) {
			Blogdata = await model.find({ "community_id": { $in: body.community_id }, "status": 1 }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
		}
		if ((body.status || body.status == '0') && body.creater_id && body.community_id) {
			Blogdata = await model.find({ "community_id": { $in: body.community_id }, creater_id: body.creater_id, status: body.status }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });

		}
		if ((body.status || body.status == '0') && body.community_id && body.creater_id == '') {
			Blogdata = await model.find({ "community_id": { $in: body.community_id }, status: body.status }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
		}
		if (body.community_id && body.creater_id) {
			Blogdata = await model.find({ "community_id": { $in: body.community_id }, creater_id: body.creater_id }).populate('community_id', "builder_name name pincode").populate('creater_id', "name username email userrole profile_pic").skip(page * limit).limit(limit).sort({ _id: -1 });
		}
	}
	let Records = [];
	Blogdata.forEach((data, index) => {
		data.createdTime = moment(data.created_date).fromNow(true);
		if (data.creater_id && data.creater_id != null)
			Records.push(data);
	});


	ResponseService.generalPayloadResponse(null, Records, res);
}

exports.shareblog = async function (id, res) {
	const model = Blog;

	var Blogdata = await model.findById(id);
	Blogdata.share_count = Blogdata.share_count + 1;

	Blogdata.save(function (err, result) {
		if (err) {
			ResponseService.generalResponse("Something went wrong, please try again.", result, 401, "Something went wrong, please try again");
			return;
		} else {
			ResponseService.generalPayloadResponse(err, result, res);
			return;
		}
	});
}