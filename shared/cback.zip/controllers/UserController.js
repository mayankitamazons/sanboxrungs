const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model
const Community = require('../models/Community'); // Topic model

const CRUD = require('../shared/CRUD')
const Product = require('../models/Product');
const jwt = require('jsonwebtoken');
const generateUniqueId = require('generate-unique-id');
const querystring = require('querystring');
const axios = require('axios');
const AWS = require('aws-sdk');
AWS.config.update({ region: 'us-east-2' });
const ses = new AWS.SES({ region: "us-east-2" });
const LoginMethods = Object.freeze({
	EMAIL: 1,
	MOBILE: 2
})
//exports.getAllUser = async function (req, res) {
//    const allUser = await User.find().sort({_id: -1}).populate('followers', "name profile_pic").populate('following', "name profile_pic");;
//    ResponseService.generalPayloadResponse(null, allUser, res);
//}
exports.getAllUser = async function (query, limit, page, type, res) {
	const model = User;
	// console.log(res.req.query);
	limit = 1000;
	var filter = {};
	if (res.req.query.userRole) {
		var filter = {
			userRole: res.req.query.userRole
		};
	}

	if (res.req.query.userRole && res.req.query.community_id) {
		var filter = {
			userRole: res.req.query.userRole,
			"community_id": {
				$in: res.req.query.community_id
			}
		};

	}
	if (res.req.query.userRole && (res.req.query.seller_profile_status || res.req.query.seller_profile_status == '0') && !res.req.query.community_id) {
		var filter = {
			userRole: res.req.query.userRole,
			seller_profile_status: res.req.query.seller_profile_status
		};
	}
	//console.log(filter);

	User.find(filter, (err, doc) => {

		ResponseService.generalPayloadResponse(err, doc, res);
	}).skip(page * limit).limit(limit).sort({
		_id: -1
	}).populate('community_id', "builder_name name locality pincode city status").skip(page * limit).limit(limit).sort({
		_id: -1
	});
}
exports.addtowishlist = function (req, res) {
	query = {};
	if (req.body.isAdd) {
		query.$addToSet = { wishList: req.body.product_id }
	} else {
		query.$pull = { wishList: req.body.product_id }
	}

	User.findByIdAndUpdate(req.body.customer_id, query, { new: true }, (err, doc) => {
		ResponseService.generalPayloadResponse(err, doc, res, undefined, "Product is added to wishlist");
	})
}
exports.wishlist = async function (req, res) {
	const model = User;
	user_id = req.body.customer_id;
	wrecord = [];
	if (user_id) {
		userdata = await User.findOne({ "_id": user_id });
		wishlist = userdata.wishList;
		reupdate_cart_item = new Array();
		if (wishlist.length) {

			w_item = wishlist;

			for (i = 0; i < w_item.length; i++) {
				element = w_item[i];
				console.log(element);
				if (element) {
					productRecord = await Product.findById(element);


				}
				wrecord.push(productRecord);
			}
		}
		ResponseService.generalPayloadResponse(null, wrecord, res);
		return;

	} else {
		ResponseService.generalPayloadResponse(null, "Use id is required", res);
		return;
	}

}

exports.sellerlist = async function (query, limit, page, type, res) {
	const model = User;
	limit = 1000;
	var filter = {};
	var community_id = res.req.body.community_id;
	console.log('seller list');         
	if (res.req.query.userRole && res.req.body.community_id && res.req.body.services_type) {
		console.log('filter called');   
		var filter = {

			services_type: res.req.body.services_type,
			userRole: res.req.query.userRole,
			"community_id": {
				$in: community_id
			}
		};
	}
	if (res.req.query.userRole && (res.req.query.seller_profile_status || res.req.query.seller_profile_status == '0')) {
		var filter = {
			userRole: res.req.query.userRole,
			seller_profile_status: res.req.query.seller_profile_status
		};
	}
	if (res.req.query.userRole && (res.req.query.seller_profile_status || res.req.query.seller_profile_status == '0') && res.req.body.community_id) {
		var filter = {
			userRole: res.req.query.userRole,
			seller_profile_status: res.req.query.seller_profile_status,
			"community_id": {
				$in: community_id
			}
		};
	}

	filter.seller_profile_status = 1;
	filter.status = 1;

	User.find(filter, (err, doc) => {

		ResponseService.generalPayloadResponse(err, doc, res);
		return;
	}, 'name profile_pic cover_image community_id').skip(page * limit).limit(limit).sort({
		_id: -1
	}).populate('community_id', "builder_name name locality pincode city status").skip(page * limit).limit(limit).sort({
		_id: -1
	})
}
exports.getSellerById = async function (req, res) {
	model = new User;
	let UserId = req.params.id

	let Records = await User.findById(UserId).populate('community_id', "builder_name name locality pincode city status");
	if (Records) {
		ResponseService.generalPayloadResponse(null, Records, res);
		return;
	} else {
		Records = {};
		ResponseService.generalPayloadResponse(null, Records, res);
		return;
	}

}
exports.getById = async function (req, res) {
	model = new User;
	let UserId = req.params.id

	let Records = await User.findById(UserId);
	if (Records) {
		
		ResponseService.generalPayloadResponse(null, Records, res);
		return;
	} else {
		Records = {};
		ResponseService.generalPayloadResponse(null, Records, res);
		return;
	}

}
exports.getuserdata = async function (req, res) {
	if (req.body.user) {

		try {
			var loggedInUserID = req.body.login_userid;
			
			const userData = await User.findById(req.body.user);
		
			const response = [];
			response.push({
				userData
				
			});
			ResponseService.generalPayloadResponse(null, response, res);
			return;
		} catch (err) {
			ResponseService.generalPayloadResponse(err, {}, res);
		}
	}
}
exports.notificationID = function (req, res) {
	query = {};
	if (req.body.isAdd) {
		query.$addToSet = {
			notification_id: req.body.notification_id
		}
	} else {
		query.$pull = {
			notification_id: req.body.notification_id
		}
	}

	User.findByIdAndUpdate(req.body.id, query, {
		new: true
	}, (err, doc) => {
		ResponseService.generalPayloadResponse(err, doc, res, undefined, "Done");
	});
}
// User check,js ex
async function sendotp(message, mobile_no) {

	const ApiUserName = 'Ravikanth';
	const ApiUserPassword = 'SMS@Pass1';
	const ApiUserSenderId = 'SPRNBR';
	const ApiUrl = 'https://login.bulksmsgateway.in/sendmessage.php?';

	const type = 3;
	const Newapi = {
		user: ApiUserName,
		password: ApiUserPassword,
		sender: ApiUserSenderId,
		type: 3
	};
	var randomumber = generateUniqueId({
		length: 4,
		useLetters: false
	})
	var number = mobile_no;
	// const message="Now Regi";
	// console.log(req.query);
	var config = {
		method: 'GET',
		url: `${ApiUrl}${querystring.stringify(Newapi)}` + '&mobile=' + number + '&' + querystring.stringify({
			message: message
		}),
		headers: {
			'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*',
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
		},
	};
	return new Promise((resolutionFunc, rejectionFunc) => {
		axios(config).then(results => {
			console.log(results);
			var res2 = {
				"status": 200,
				"otp": randomumber
			};
			resolutionFunc(res2);
		}).catch(err => {
			console.log(err);
			rejectionFunc(err);
		});
	});
}
exports.updateById = async function (req, res) {
	model = new Product;
	let user_id = req.params.id
	const body = req.body;
	let parentArr = body.parent_id;
	let parentPath = [];
	query = req.body;
	if (body.all_com_selected == "y") {
		pRecords = [];
		allcommunity = await Community.find({ "status": 1 })
			.populate('community_leader', "name username email userrole profile_pic mobile_no").sort({ name: 1 });
		for (k = 0; k < allcommunity.length; k++) {
			s_com = allcommunity[k];
			pRecords.push(s_com._id);
		}
		query.community_id = pRecords;
	}
	User.findByIdAndUpdate(user_id, query, { new: true }, (err, doc) => {
		ResponseService.generalPayloadResponse(err, doc, res);
		return;
	});
}

exports.sendotp = function (req, res) {
	// DB query for User
	var query = {};

	if (req.body.social_id) { // Social login
		query.social_id = req.body.social_id;
	} else { // Regular login
		if (req.body.login_method === LoginMethods.EMAIL) { // Email login
			query.email = req.body.username;
		} else if (req.body.login_method === LoginMethods.MOBILE) { // Mobile login
			query.mobile_no = req.body.username;
		}
	}
	User.findOne(
		query,
		async (err, doc) => {
			if (doc) {
				try {
					if (req.body.login_method === LoginMethods.MOBILE) {

						var randomumber = generateUniqueId({
							length: 4,
							useLetters: false
						})
						message = `Your otp is ${randomumber}`
						let res2 = await sendotp(message, doc.mobile_no);

					} else {
						var message = '';
						if (message === '') {
							var randomumber = generateUniqueId({
								length: 4,
								useLetters: false
							})
							message = `Your otp is ${randomumber}`
						}
						// send email for reset password 
						var res2 = {
							"otp": randomumber
						};
					}
					var res2 = {
						"otp": randomumber
					};
				} catch (err) {
					var res2 = {};
					ResponseService.generalPayloadResponse(err, res2, res);
				}
				// User exists
				ResponseService.generalPayloadResponse(err, res2, res);
				// ResponseService.generalResponse(err, res, 200, "Otp Send");
			} else {
				// No user found
				ResponseService.generalResponse(err, res, 404, "User not found");
			}
		}
	)

};


exports.sendsms = async function (req, res) {
	try {
		const ApiUserName = 'Ravikanth';
		const ApiUserPassword = 'SMS@Pass1';
		const ApiUserSenderId = 'SPRNBR';
		const ApiUrl = 'https://login.bulksmsgateway.in/sendmessage.php?';

		const type = 3;
		const Newapi = {
			user: ApiUserName,
			password: ApiUserPassword,
			sender: ApiUserSenderId,
			type: 3
		}
		var number = req.query.number;
		// const message="Now Regi";
		// console.log(req.query);
		var message = '';
		if (message === '') {
			const randomumber = generateUniqueId({
				length: 4,
				useLetters: false
			})
			message = `Your otp is ${randomumber}`
		}
		console.log(message);
		var config = {
			method: 'GET',
			url: `${ApiUrl}${querystring.stringify(Newapi)}` + '&numbers=' + number + '&' + querystring.stringify({
				message: message
			}),
			headers: {
				'Content-Type': 'application/json',
				'Access-Control-Allow-Origin': '*',
				'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
			},
		};
		console.log(number);
		axios(config).then(results => {
			res.json(results)
			return
		})
	} catch (err) {
		ResponseService.generalPayloadResponse(err, {}, res);
	}
}

exports.getENV = async (req, res) => {
	return ResponseService.generalPayloadResponse(null, { config: AWS.config, ses }, res);
}