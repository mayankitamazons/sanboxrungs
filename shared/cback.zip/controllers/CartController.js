const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model

const CRUD = require('../shared/CRUD');
const Product = require('../models/Product');
const Address = require('../models/Address');
const SellerProduct = require('../models/SellerProduct');
const Attribute = require('../models/Attribute');
const CouponHistory = require('../models/CouponHistory');
const Cart = require('../models/Cart');
const Coupon = require('../models/Coupon');
const { compareSync } = require('bcryptjs');
var mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Order = require('../models/Order');

let seller_id;

async function getCartByCustomerId(customer_id) {

    try {
        res = await Cart.findOne({ "customer_id": customer_id, "is_active": 1 });

        return res;
    } catch (err) {
        return;
    }
}

exports.setPaymentMethod = async function (req, res) {
    // cart_id = req.body.cart_id;
    customer_id = req.body.customer_id;

    cart = await Cart.findOne({ "is_active": 1, "customer_id": customer_id });
    if (cart) {
        cart.payment_method = req.body.payment_method;
        cart.save(function (err, val) {
            if (err) {
                console.log(err);
            } else {
                console.log("payment method set successfully");
            }
            ResponseService.generalPayloadResponse(null, val, res);
        });
    } else {
        ResponseService.generalPayloadResponse(null, "your cart is empty", res);
    }
}
exports.setCheckoutAddress = async function (req, res) {
    // cart_id = req.body.cart_id;
    customer_id = req.body.customer_id;
    userdata = await User.findById(customer_id).populate('community_id', "builder_name name locality pincode city status");
    cart = await Cart.findOne({ "is_active": 1, "customer_id": customer_id });
    if (cart) {
        body = req.body;

        address = {
            "full_name": body.full_name,
            "mobile_no": body.mobile_no ? body.mobile_no : userdata.mobile_no,
            "email": userdata.email,
            "pin_code": body.pin_code,
            "locality": body.locality,
            "city": body.city,
            "state": body.state,
            "landmark": body.landmark,
            "adderess_1": body.adderess_1,
            "alternative_phone": body.alternative_phone,
            "address_type": body.address_type


        };
        cdata = userdata.community_id[0];
        address.community_name = cdata.name;

        delete address['customer_id'];
        cart.address = address;
        cart.save(function (err, val) {
            if (err) {
                console.log(err);
            } else {
                console.log("Delivery address set successfully");
                User.findByIdAndUpdate(
                    customer_id, { address_detail: address }, { new: true },
                    (err, doc) => { console.log('Address updated'); }
                );
            }
            ResponseService.generalPayloadResponse(null, val, res);
        });
    } else {
        ResponseService.generalPayloadResponse(null, "your cart is empty", res);
    }
}

exports.applyCoupon = async function (req, res) {
    cart_id = req.body.cart_id;
    coupon_code = req.body.coupon_code;


    cart = await Cart.findOne({ "_id": cart_id });
    if(!cart){
        return ResponseService.generalResponse(
            "Invalid Cart",
            res,
            404
        );
    }
    customer_id = cart.customer_id;
    cart_amount = cart.grandtotal;

    is_valid_res = await validateCoupon(coupon_code, customer_id, cart_amount);
    is_valid_coupon = is_valid_res.is_valid;
    coupon_msg = is_valid_res.msg;

    if (!is_valid_coupon) {

        ResponseService.generalResponse(null, res, 404, coupon_msg);
        return;
    }
    if (cart && is_valid_coupon) {
        cart.coupon_code = coupon_code;
        cart.save(function (err, val) {
            if (err) {
                console.log(err);
            } else {
                let result = collectTotal(cart_id);
                console.log("Coupon code " + coupon_code + " apply successfully");
            }
            ResponseService.generalPayloadResponse(null, val, res);
        });
    } else {
        ResponseService.generalPayloadResponse(null, "your cart is empty", res);
    }
}
exports.removeCoupon = async function (req, res) {
    cart_id = req.body.cart_id;
    coupon_code = req.body.coupon_code;

    cart = await Cart.findOne({ "_id": cart_id });

    if (cart) {
        cart.coupon_code = '';
        cart.save(function (err, val) {
            if (err) {
                console.log(err);
            } else {
                let result = collectTotal(cart_id);
                console.log("Coupon code " + coupon_code + " removed successfully");
            }
            ResponseService.generalPayloadResponse(null, val, res);
        });
    } else {
        ResponseService.generalPayloadResponse(null, "your cart is empty", res);
    }
}

function dateparser(str) {
    return format(new Date(Date.parse(str)), "yyyy-MM-dd");
}
async function validateCoupon(coupon_code, customer_id, cart_amount) {
    coupon_code = coupon_code.toUpperCase();
    cp = await Coupon.findOne({ "coupon_code": coupon_code });
    console.log(cp);

    is_valid = true;
    v_s = {
        "is_valid": true,
        "msg": "Coupon Applied"
    };
    if (cp) {
        var current_date = format(new Date(), "yyyy-MM-dd");
        var from_date = dateparser(cp.start_date);
        var end_date = dateparser(cp.end_date);
        cph = await CouponHistory.find({ "coupon_code": coupon_code });
        cphs = await CouponHistory.find({ "coupon_code": coupon_code, "customer_id": customer_id });
        if (cp.is_active == 0) {
            is_valid = false;
            v_s = {
                "is_valid": false,
                "msg": "Coupon is already used"
            };
        }
        if (cph && cph.length >= cp.uses_per_coupon) {
            is_valid = false;
            v_s = {
                "is_valid": false,
                "msg": "Coupon is already used"
            };
        }
        if (cphs && cphs.length >= cp.uses_per_customer) {
            is_valid = false;
            v_s = {
                "is_valid": false,
                "msg": "Coupon is Out of Stock, Try with Different Coupon"
            };
        }
        if (current_date > end_date || current_date < from_date) {
            is_valid = false;
            v_s = {
                "is_valid": false,
                "msg": "Coupon is Expired"
            };
        }

        if (cp.min_amount > 0) {
            // console.log('min amount greater 0 ,cart ' + cart_amount);

            if (cp.min_amount > cart_amount) {
                is_valid = false;

                msg = "To apply that coupon cart value has to be min " + cp.min_amount;
                v_s = {
                    "is_valid": false,
                    "msg": msg
                };
            }
        }
        if (cp.max_amount > 0) {
            if (cp.max_amount < cart_amount) {
                is_valid = false;
                msg = "Coupon is only value up to cart value of  " + cp.max_amount;
                v_s = {
                    "is_valid": false,
                    "msg": msg
                };
            }
        }
        if (is_valid) {
            if (cp.coupon_type == "percent") {
                cp_amt = cp.amount;
                discount = cart_amount * cp_amt / 100;
                discount = parseFloat(discount).toFixed(2);
            } else {
                discount = cp.amount;
            }
            v_s = {
                "is_valid": true,
                "discount": discount,
                "msg": "Coupon Applied"
            };
        }

    } else {
        discount = 0;
        console.log("coupon code not found");

        v_s = {
            "is_valid": false,
            "msg": "Invalid Coupon Code"
        };
    }
    return v_s;

}
async function calculateDisocunt(coupon_code, total) {
    cp = await Coupon.findOne({ "coupon_code": coupon_code });
    discount = 0;
    if (cp) {

        if (cp.coupon_type == "percent") {
            cp_amt = cp.amount;
            discount = total * cp_amt / 100;
            discount = parseFloat(discount).toFixed(2);
        } else {
            discount = cp.amount;
        }
    } else {
        console.log("coupon code " + coupon_code + " not found");
    }
    return discount;

}

exports.add = async function (req, res) {
    var body = req.body;
    var d = new Date();
    var time = d.getTime();
    qty = body.qty;
    sell_on_com = false;
    customer_id = body.customer_id;
    product_id = body.product_id;
    if(body.product_id && body.customer_id && body.qty && body.address_id){
        let p = await getProduct(product_id);
        if (!p) {
            ResponseService.generalPayloadResponse(null, "Product not found", res);
            return;
        }
        if (p) {
            let name = p.product_en;
            pending_stock = p.pending_stock;
            min_stock = p.min_stock;
            if (parseInt(pending_stock) <= parseInt(min_stock)) {

                ResponseService.generalResponse(null, res, 404, "Product is out of Stock");
                return;
            }
            if (parseInt(pending_stock) < parseInt(qty)) {
                if (parseInt(pending_stock) < parseInt(min_stock))
                    pending_stock = min_stock;
                msg = "only " + pending_stock + " product is available for " + name;
                ResponseService.generalResponse(msg, res, 200, msg);
                return;

            }
            let userData = await User.findById(body.customer_id).populate('community_id', "name locality pincode city status");
        
            addressData = await Address.findById(body.address_id);
            console.log('addressData',addressData);
            if(addressData){  
                address = {
                    "full_name": addressData.full_name,
                    "mobile_no": addressData.mobile_no ? addressData.mobile_no : userData.mobile_no,
                    "email": addressData.email,
                    "pin_code": addressData.pin_code,
                    "locality": addressData.locality,
                    "city": addressData.city,
                    "state": addressData.state,
                    "landmark": addressData.landmark,
                    "adderess_1": addressData.adderess_1, 
                    "adderess_2": addressData.adderess_2, 
                    "alternative_phone": addressData.alternative_phone,
                    "address_type": addressData.address_type,
                    "address_id":body.address_id
                };
                product_id = p._id;
                price = p.price;
                
                icon = p.icon;
                if (p.special_price > 0) {
                    price = p.special_price;
                }
                 subtotal = price * qty;
                 g_id_exit = false;
                 add_item = {
                    "qty": qty,
                    "product_id": product_id,
                    "name": name,
                    "icon": icon,
                    "price": price,
                    "subtotal": subtotal,
                    "stock_msg": "",
                    "mrp": price,
                    "delivery_time": p.delivery_time,
                    "delivery_slot": p.delivery_slot,
                    "shippingCost": p.shippingCost,
                    "tax": p.tax
                };  
                cart = await getCartByCustomerId(customer_id);
                if (!cart) {
                    customer_group_id = 2;
                    customer_email = userData.email;
                    params = {
                        "customer_email": customer_email,
                        "customer_group_id": customer_group_id,
                        "customer_id": body.customer_id,
                        "created_at": time,
                    };
                    console.log('cart item',add_item);
                    params.cartitem = add_item;
                    params.address = address;
                    model = Cart;
                    cart = new model(params);
        
                    // console.log("new item added");
                    await cart.save(async function () {
                        cart = await getCartByCustomerId(customer_id);
                        let result = await collectTotal(cart._id);
                        let Responsecart = await Cart.findOne({ "_id": cart._id, "is_active": 1 });
                        ResponseService.generalPayloadResponse(null, Responsecart, res);
                        return;
                    });
                } else{
                    //
                    console.log('no past cart exit');
                    cart_id = cart._id;
                    cart_item = cart.cartitem;
                    is_new_item = true;
                    cartlength = cart_item.length;
                    reupdate_cart_item = new Array();
                    if (cartlength) {
                        for (j = 0; j < cart_item.length; j++) {
                            preitem = cart_item[j];
                            if (preitem) {
                                // if (typeof preitem.product_id == typeof undefined || typeof preitem.product_id == typeof null) {
                                //     continue;
                                // }
                                if (product_id.toString() == (preitem.product_id).toString()) {
                                    is_new_item = false;
                                    preitem.qty = qty;
                                }
                                preitem.subtotal = preitem.qty * preitem.price;
                                reupdate_cart_item[j] = preitem;


                            }
                        }
                    }

                    if (is_new_item) {
                        reupdate_cart_item[cartlength] = add_item;
                    }

                    var reupdate_cart_item = reupdate_cart_item.filter(function (el) {
                        return el != null;
                    });

                    await Cart.findByIdAndUpdate(cart_id, { 'cartitem': reupdate_cart_item }, { new: true },
                        async function (err, docs) { });
                    let result = await collectTotal(cart_id);
                    // console.log("result", result);
                    let Responsecart = await Cart.findOne({ "_id": cart_id, "is_active": 1 });

                    ResponseService.generalPayloadResponse(null, Responsecart, res);
                    return;

                }
            }
            else
            {
                ResponseService.generalResponse(null, res, 404, "Invalid Address id");
                return;
            }

        }
        else
        {
            ResponseService.generalResponse(null, res, 404, "Invalid Product id");
            return;
        }
    }
    else{
        ResponseService.generalResponse(null, res, 404, "Required Parameter missing");
        return;
    }
}

async function saveUpdateCart(cart_id, cartitem) {
    Cart.findByIdAndUpdate(cart_id, { 'cartitem': cartitem }, async function (err, docs) {
        console.log("saveupdatecart");
        //    let Responsecart = await Cart.findOne({ "_id": cart_id,"is_active":1 });
        //    return Responsecart;
        // ResponseService.generalPayloadResponse(err, Responsecart, res, undefined, "Updated");
        // return;
    });


}

exports.delete = async function (req, res) {

    var body = req.body;
    var d = new Date();
    var time = d.getTime();
    customer_id = body.customer_id;
    product_id = body.product_id;
    var is_product_exist = false;
    if (customer_id) {
        cart = await getCartByCustomerId(customer_id);
        if (cart) {
            cart_item = cart.cartitem;
            cartlength = cart_item.length;
            reupdate_cart_item = new Array();
            if (cartlength) {
                for (i = 0; i < cart_item.length; i++) {
                    preitem = cart_item[i];
                    if (preitem != 'null') {
                        if (product_id == preitem.product_id) {
                            is_product_exist = true;
                        }
                        if (product_id != preitem.product_id) {
                            reupdate_cart_item[i] = preitem;
                        }

                        if (reupdate_cart_item.length) {
                            cart.cartitem = reupdate_cart_item;
                        }

                    }

                }
            }
            if (is_product_exist == true) {
                msg = "Product delete successfully";
            } else {
                msg = "Product not found in your cart";
            }
            var reupdate_cart_item = reupdate_cart_item.filter(function (el) {
                return el != null;
            });
            await Cart.findByIdAndUpdate(cart._id, { 'cartitem': reupdate_cart_item }, async function (err, docs) {
                console.log("saveupdatecart");
            });
            let result = await collectTotal(cart._id);

            ResponseService.generalPayloadResponse(null, msg, res);
            return;
        } else {
            ResponseService.generalPayloadResponse(null, "your cart is empty", res);
        }
    }
}
async function collectTotal(cart_id) {

    cart = await Cart.findOne({ "_id": cart_id, "is_active": 1 });
    if (cart) {
        let grandtotal = 0;
        let subtotal = 0;
        let total_item_quantity = 0;
        let shipping_amount = 0;
        let currency = "INR";
        let vat = 0;
        var tax_amount = 0;
        var discount_amount = 0;
        g_total = [];
        s_total = [];
        t_total = [];
        stock_msg = '';
        cart.allow_checkout = 1;
        allow_checkout = 1;
        reupdate_cart_item = new Array();
        if (cart.cartitem.length) {
            cart_item = cart['cartitem'];
            g_id_exit = false;
            for (i = 0; i < cart_item.length; i++) {
                
                element = cart_item[i];
                if (element && element != 'null') {
                    qty = parseInt(element.qty);
                    product_id = element.product_id;
                    try{
                        p = await getProduct(product_id);
                        if (typeof p._id !== typeof undefined) {
                            let name = p.product_en;
                            let icon = p.icon;
                            let price = p.price;
                            if (typeof p.special_price != undefined && p.special_price > 0) {
                                price = p.special_price;
                            }
                            if (parseInt(p.pending_stock) <= 0) {

                                element.stock_msg = name + "is Out of Stock";
                                cart.allow_checkout = 0;
                            } else if (parseInt(p.pending_stock) < qty) {
                                element.stock_msg = "only " + p.pending_stock + " quantity is availble for " + name;
                                cart.allow_checkout = 0;
                            }
                            subtotal = parseFloat(price * qty).toFixed(2);
                            grandtotal = parseFloat(grandtotal + subtotal).toFixed(2);
                            g_total.push(subtotal);
                            s_total.push(element.shippingCost);
                            t_total.push(element.tax);
                            total_item_quantity = total_item_quantity + qty;
                            element.icon = icon;
                            element.name = name;
                            element.price = parseFloat(price).toFixed(2);
                            element.subtotal = parseFloat(subtotal).toFixed(2);
                            reupdate_cart_item[i] = element;
                        }
                        else {
                            console.log("Product Not Found.");
                        }

                    }catch (err) {
                        return;
                    }
                }
                else {

                    console.log("Cart Item Not Found.");
                }
            }
        }
        else {
            console.log("Cart Empty.");
        }
        grandtotal = 0;
        shippingtotal = 0;
        Taxtotal = 0;
        for (var i = 0; i < g_total.length; i++) {
            console.log('Total cal');
            grandtotal += parseInt(g_total[i]);
            shippingtotal += parseInt(s_total[i]);
            Taxtotal += parseInt(t_total[i]);

        }

        cart.subtotal = grandtotal + shippingtotal + Taxtotal;
        cart.grandtotal = grandtotal + shippingtotal + Taxtotal;

        if (cart.coupon_code) {
            is_valid_res = await validateCoupon(cart.coupon_code, cart.customer_id, cart.subtotal);
            is_valid_coupon = is_valid_res.is_valid;
            if (is_valid_coupon) {
                discount_amount = is_valid_res.discount;
            } else {
                cart.coupon_code = "";
            }
            cart.discount_amount = discount_amount;

            if (grandtotal > discount_amount) {
                grandtotal = grandtotal - discount_amount;
            } else {
                grandtotal = 0;
            }
            // console.log("grand total after discount "+grandtotal);                  
        } else {
            cart.coupon_code = "";
            cart.discount_amount = 0;
        }
        cart.cartitem = reupdate_cart_item;

        cart.grandtotal = parseFloat(grandtotal + shippingtotal + Taxtotal).toFixed(2);
        //console.log(cart.grandtotal);   
        cart.items_qty = total_item_quantity;
        cart.shipping_amount = parseFloat(shippingtotal).toFixed(2);
        cart.tax_amount = parseFloat(Taxtotal).toFixed(2);

        cart.currency = currency;
        cart.vat = vat;
        cart_id = cart._id;
        // console.log(cart);
        Cart.findByIdAndUpdate(cart_id, cart, {
            new: true
        }, (err, doc) => {
            // console.log('FInal');
            // console.log('Final Cart',doc);

        });
        return cart;
    }
    else {
        return;
    }
    
}
format = function date2str(x, y) {
    var z = {
        M: x.getMonth() + 1,
        d: x.getDate(),
        h: x.getHours(),
        m: x.getMinutes(),
        s: x.getSeconds()
    };
    y = y.replace(/(M+|d+|h+|m+|s+)/g, function (v) {
        return ((v.length > 1 ? "0" : "") + eval('z.' + v.slice(-1))).slice(-2)
    });

    return y.replace(/(y+)/g, function (v) {
        return x.getFullYear().toString().slice(-v.length)
    });
}
async function getProduct(id) {
    try {
        res = await Product.findOne({ "_id": id }).select("price qty product_en special_price from_Date to_date icon multiseller delivery_time delivery_slot service_type shippingCost tax");
        return res;
    } catch (err) {
        return;
    }

}

exports.cartlist = async function (query, limit, page, type, body, res) {

    const model = Cart;
    customer_id = body.customer_id;
    cart = await getCartByCustomerId(customer_id);

    cart_record = 'your cart is empty';

    if (cart) {
        cart_id = cart._id;
        let result = await collectTotal(cart_id);
        let cart_record = await model.find({
            "_id": cart_id,
            "is_active": 1
        });
        // console.log(cart_record);
        ResponseService.generalPayloadResponse(null, cart_record, res);
    } else {
        ResponseService.generalPayloadResponse(null, cart_record, res);
    }
    return
}
