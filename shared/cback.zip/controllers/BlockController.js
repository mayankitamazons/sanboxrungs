const ResponseService = require("../shared/ResponseService"); // Response service
const Block = require("../models/Block"); // Block model
const Item = require("../models/Item"); // Item model
const Question = require("../models/Question"); // Attr option model
const Answer = require("../models/Answer"); // Attr option model
const User = require("../models/User"); // Attr option model
const Product = require("../models/Product"); // Video model
const Category = require("../models/Category"); // Category model
const Size = require("../models/SizeTemplate"); // Category model
const Color = require("../models/ColorTemplate"); // Category model
const Community = require("../models/Community"); // Category model
const Cart = require("../models/Cart");
const mongoose = require("mongoose");
const Banner = require("../models/Banner");
const LeaderBoard = require("../models/LeaderBoard"); // Attr option model
const Blog = require("../models/Blog"); // Attr option model
const Slot = require("../models/Slot"); // Attr option model
// var dateFormat = import('dateformat');

const CRUD = require("../shared/CRUD");

exports.blockList = async function (req, res) {
  const allBlock = await Block.find().sort({ position_nebr: 1 });
  ResponseService.generalPayloadResponse(null, allBlock, res);
};
exports.homelist = async function (req, res) {
  let allBlock = await Block.find({ status: 1 }).sort({ position_nebr: 1 });
  alength = allBlock.length;
  let blockRecords = [];
  cart_count = 0;
  wishlist_count = 0;
  let pRecords = [];
  userdata = [];
  wishlist = [];
  cartlist = [];
  community_id = "";
  service_type = "1";

  let login_user_id;
  if (req.body.login_user_id) {
    login_user_id = req.body.login_user_id;
    var userdata = await User.findById(login_user_id);

    if (!userdata)
      return ResponseService.generalResponse("User doesnt exist", res, 404);

    var cartlist = await Cart.findOne({
      customer_id: login_user_id,
      is_active: 1,
    });

    if (userdata) {
      if (userdata.wishList) wishlist = userdata.wishList;
      if (cartlist && cartlist != null) {
        cart_items = cartlist.cartitem;
        cart_count = cartlist.cartitem.length;
      } else cart_items = [];

      wishlist_count = wishlist.length;
    }
  } else {
    login_user_id = "";
  }

  if (service_type) {
    if (alength > 0) {
      for (i = 0; i < allBlock.length; i++) {
        pRecords = [];

        catArr = [];

        dataBlock = allBlock[i];
        productData = [];
        // console.log(dataBlock);
        content_view = dataBlock.content_view;
        // console.log('Content View ' + dataBlock.content_view);
        // 1 for banner view, 2 for top category list, 3 -all rugs style
        // 4- recent views style , 5- similar product style , 6- service label style
        // 7-  spotligh view, 8- shop by size, 9- popular rugs style,10 ads list
        // 11 - banner list , 12 single image view,13 - shop by color
        switch (content_view) {
          case 1:
          case 10:
          case 11:
          case 12:
            // code block
            search_keyData = dataBlock.search_key;
            if (search_keyData.length) {
              SearchData = await Banner.find({
                _id: { $in: search_keyData },
                status: 1,
              });
              dataBlock.Record = SearchData;
            }

            break;
          case 2:
            CategoryData = await Category.find({ status: 1 });
            dataBlock.Record = CategoryData;
            break;

          case 3:
          case 4:
          case 5:
          case 7:
          case 8:
            SizeData = await Size.find({ status: 1 });
            dataBlock.Record = SizeData;
            break;
          case 13:
            ColoreData = await Color.find({ status: 1 });
            dataBlock.Record = ColoreData;
            break;
          case 9:
            search_key = dataBlock.search_key[0];
            try {
              var categoryRecords = await Category.findOne({ _id: search_key });
              console.log("category", categoryRecords);
            } catch (err) {}

            if (categoryRecords) {
              catArr.push(categoryRecords._id);
              var haveChild = categoryRecords.haveChild;

              SubCategoryData = await Category.find({
                parent_id: { $in: search_key },
                status: 1,
              });
              if (SubCategoryData.length) {
                for (k = 0; k < SubCategoryData.length; k++) {
                  subcatid = SubCategoryData[k]._id;

                  catArr.push(subcatid);
                }
              }
            }

            let page = 0;
            limit = 10;
            if (catArr.length) {
              for (j = 0; j < catArr.length; j++) {
                categoryid = catArr[j];

                var toBeSearch = { cat_id: categoryid, status: 1 };

                if (!comm.is_global) {
                  toBeSearch.community_id = community_id;
                }
                let productDataCat = await Product.find(toBeSearch)
                  .populate("cat_id", "cat_name image title")
                  .populate(
                    "seller_id",
                    "name username email userrole profile_pic"
                  )
                  .limit(limit)
                  .sort({ _id: -1 });
                productData.push(productDataCat);
              }
              // console.log(productData.length);
              productData = productData[0];
              if (login_user_id || cart_count > 0 || wishlist_count > 0) {
                for (m = 0; m < productData.length; m++) {
                  p_data = productData[m];
                  productId = p_data._id;
                  if (login_user_id && wishlist) {
                    wishlist.forEach(async (w_l, index) => {
                      if (
                        mongoose.Types.ObjectId(w_l).equals(
                          mongoose.Types.ObjectId(productId)
                        )
                      ) {
                        p_data.is_wishlist = true;
                      }
                    });
                  }
                  if (login_user_id && cartlist) {
                    if (cart_items.length > 0) {
                      cart_items.forEach(async (c_l, index) => {
                        if (
                          mongoose.Types.ObjectId(c_l.product_id).equals(
                            mongoose.Types.ObjectId(productId)
                          )
                        ) {
                          p_data.is_on_cart = true;
                        }
                      });
                    }
                  }
                  pRecords.push(p_data);
                }
              } else {
                pRecords = productData;
              }
              dataBlock.Record = pRecords;
            } else {
              dataBlock.Record = [];
            }
            break;
          case 7:
            // code block
            search_keyData = dataBlock.search_key;
            if (search_keyData.length) {
              SearchData = await Banner.find({
                _id: { $in: search_keyData },
                status: 1,
              });
              dataBlock.Record = SearchData;
            }

            break;
          default:
            dataBlock.Record = [];
          // code block
        }

        blockRecords.push(dataBlock);
      }
    }

    ResponseService.generalPayloadResponse(null, blockRecords, res);
    return;
  } else {
    ResponseService.generalPayloadResponse(
      null,
      "Community id is Required",
      res
    );
    return;
  }
};

function getItemByblockid(blockid) {
  const itemRecords = Item.find({ blockid: blockid });
  console.log(itemRecords);
}

// combine of home banner, events, leaderboard, top blogs , blog list , polls, deal of days
exports.homepage = async function (query, limit, page, type, body, res) {
  let p_result;
  DealData = [];
  leaderboard = [];
  top_blogs = [];
  blog_list = [];
  QuestionData = [];
  pop_mart = [];
  cart_count = 0;
  wishlist_count = 0;
  let pRecords = [];
  userdata = [];
  wishlist = [];
  cartlist = [];
  BannerData = [];
  // paramater login_user_id, api_call=1-for app, 2- for web,community_id
  body.community_id = "63e2e4638794c800023180af";
  if (body.community_id) {
    let login_user_id;
    if (body.login_user_id) {
      login_user_id = body.login_user_id;
      var userdata = await User.findById(login_user_id);
      var cartlist = await Cart.findOne({
        customer_id: login_user_id,
        is_active: 1,
      });
      if (userdata.wishList) wishlist = userdata.wishList;
      if (cartlist) {
        cart_items = cartlist.cartitem;
        cart_count = cartlist.cartitem.length;
      }

      wishlist_count = wishlist.length;
    } else {
      login_user_id = "";
    }
    // fetch banner list
    BannerData = await Banner.find({
      community_id: {
        $in: body.community_id,
      },
      status: 1,
    })
      .populate(
        "community_id",
        "builder_name name locality pincode city status"
      )
      .populate("category_id", "title slug icon description image status")
      .limit(10);
    // deals of day product
    cat_id = "603b488830342a000413720a";
    var categoryRecords = await Category.findById(cat_id);
    if (categoryRecords) {
      DealData = await Product.find({
        cat_id: {
          $in: cat_id,
        },
        status: 1,
        "seller_id.0": { $exists: true },
      })
        .populate("cat_id", "cat_name image")
        .populate("community_id", "builder_name name pincode")
        .populate(
          "seller_id",
          [
            "name",
            "seller_profile_status",
            "username",
            "email",
            "userrole",
            "profile_pic",
          ],
          { seller_profile_status: 1, status: 1 }
        )
        .limit(10)
        .sort({ _id: -1 });

      DealData = DealData.filter(
        (product) => product.seller_id != null && product.seller_id.length != 0
      );

      if (login_user_id || cart_count > 0 || wishlist_count > 0) {
        for (i = 0; i < DealData.length; i++) {
          p_data = DealData[i];
          productId = p_data._id;
          if (login_user_id && wishlist) {
            wishlist.forEach(async (w_l, index) => {
              if (
                mongoose.Types.ObjectId(w_l).equals(
                  mongoose.Types.ObjectId(productId)
                )
              ) {
                p_data.is_wishlist = true;
              }
            });
          }
          if (login_user_id && cartlist) {
            if (cart_items.length > 0) {
              cart_items.forEach(async (c_l, index) => {
                if (
                  mongoose.Types.ObjectId(c_l.product_id).equals(
                    mongoose.Types.ObjectId(productId)
                  )
                ) {
                  p_data.is_on_cart = true;
                }
              });
            }
          }
          pRecords.push(p_data);
        }
        DealData = pRecords;
      }
    }
    // leaderboard data
    leaderboard = await LeaderBoard.find({
      community_id: { $in: body.community_id },
    })
      .populate("user_id", "name username email userrole profile_pic")
      .limit(10)
      .sort({ _id: -1 });

    leaderboard = leaderboard.filter(
      (lb) => lb.user_id != null && lb.user_id != {}
    );

    // blog data
    blog_list = await Blog.find({
      community_id: { $in: body.community_id },
      status: 1,
    })
      .populate("community_id", "builder_name name pincode")
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ likes_count: -1, comment_count: -1 });

    blog_list = blog_list.filter(
      (lb) => lb.creater_id != null && lb.creater_id != {}
    );
    // polls list
    try {
      let answerData = await Answer.find({
        user_id: login_user_id,
      });
      if (answerData.length) {
        let attendQues = [];
        for (i = 0; i < answerData.length; i++) {
          attendQues.push(answerData[i].question_id);
        }
        let filterQuesArr = [];
        if (attendQues.length) {
          QuestionDataArr = await Question.find({
            status: 1,
            community_id: {
              $in: body.community_id,
            },
          })
            .populate("community_id", "builder_name name pincode")
            .populate("creater_id", "name username email userrole profile_pic")
            .limit(10)
            .sort({
              _id: -1,
            });

          let allQuestionsId = [];
          for (i = 0; i < QuestionDataArr.length; i++) {
            allQuestionsId[i] = QuestionDataArr[i]._id;
          }

          filterArr = array_diff(allQuestionsId, attendQues);

          for (i = 0; i < filterArr.length; i++) {
            questionId = filterArr[i];
            try {
              QuestionData = await Question.findById(questionId);
            } catch (err) {}

            filterQuesArr[i] = QuestionData;
          }
        }

        QuestionData = filterQuesArr;
      } else {
        QuestionData = await Question.find({
          community_id: {
            $in: body.community_id,
          },
          status: body.status,
        })
          .populate("community_id", "builder_name name pincode")
          .populate("creater_id", "name username email userrole profile_pic")
          .limit(10)
          .sort({
            _id: -1,
          });
      }
    } catch (err) {}

    QuestionData = QuestionData.filter(
      (lb) => lb.creater_id != null && lb.creater_id != {}
    );

    currentDate = new Date();
    // listing of pop mart
    pop_mart = await Slot.find({
      community_id: {
        $in: body.community_id,
      },
      end_date: { $gt: currentDate },
      isBooked: true,
      seller_register_stauts: "accepted",
    })
      .populate(
        "seller_id",
        "name username email userrole profile_pic seller_profile_status",
        { seller_profile_status: 1, status: 1 }
      )
      .limit(10)
      .sort({ _id: -1 });

    p_list = [];
    for (p = 0; p < pop_mart.length; p++) {
      s_pop = pop_mart[p];
      start_time = s_pop.start_date;
      end_date = s_pop.end_date;
      s_pop.start_date = start_time;
      s_pop.end_date = end_date;
      // console.log(s_pop);
      p_list.push(s_pop);
    }
    pop_mart = p_list.filter(
      (slot) => slot.seller_id != null && slot.seller_id.length != 0
    );

    if (BannerData.length == 0) {
      a_data = {
        button_action: 1,
        search_key: "",
        status: 1,
        banner_position: 1,
        banner_for: 2,
        banner_type: 1,
        category_id: [],
        community_id: [],
        _id: "demobanner",
        title: "",
        sub_title: "",
        button_text: "",
        image: "https://humbleirde.s3.ca-central-1.amazonaws.com/rugs/logo.png",
        slug: "1608717509646",
        created_date: "2020-12-23T09:58:29.657Z",
        __v: 0,
      };
      BannerData.push(a_data);
    }
    p_result = {
      deal_cat_id: cat_id,
      bannner_list: BannerData,
      pop_mart: pop_mart,
      leaderboard: leaderboard,
      deal_of_day: DealData,
      blog_list: blog_list,
      polls: QuestionData,
    };
    ResponseService.generalPayloadResponse(null, p_result, res);
    return;
  } else {
    ResponseService.generalPayloadResponse(
      null,
      "Community id is Required",
      res
    );
    return;
  }
};
exports.search = async function (query, limit, page, type, body, res) {
  community_id = body.community_id;
  login_user_id = body.login_user_id;
  search = body.search;
  if (community_id && search) {
    productData = await Product.find({
      community_id: {
        $in: body.community_id,
      },
      "seller_id.0": { $exists: true },
      status: 1,
      $or: [
        { product_en: { $regex: ".*" + search + ".*", $options: "-i" } },
        { description: { $regex: ".*" + search + ".*", $options: "-i" } },
      ],
    })
      .populate("cat_id", "title image")
      .populate("community_id", "builder_name name pincode")
      .populate(
        "seller_id",
        [
          "name",
          "seller_profile_status",
          "username",
          "email",
          "userrole",
          "profile_pic",
        ],
        { seller_profile_status: 1, status: 1 }
      )
      .populate("creater_id", "name username email userrole profile_pic")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });

    productData = productData.filter(
      (product) => product.seller_id != null && product.seller_id.length != 0
    );

    sellerdata = await User.find({
      userRole: 3,
      seller_profile_status: 1,
      status: 1,
      community_id: {
        $in: body.community_id,
      },
      name: { $regex: ".*" + search + ".*" },
    })
      .populate(
        "community_id",
        "builder_name name locality pincode city status"
      )
      .skip(page * limit)
      .limit(limit)
      .sort({
        _id: -1,
      })
      .select("name profile_pic cover_image community_id")
      .skip(page * limit)
      .limit(limit)
      .sort({ _id: -1 });

    r_s = { product: productData, seller: sellerdata };
    ResponseService.generalPayloadResponse(null, r_s, res);
    return;
  } else {
    ResponseService.generalPayloadResponse(
      null,
      "Community id is Required",
      res
    );
    return;
  }
};

function array_diff(a1, a2) {
  var a = [],
    diff = [];

  for (var i = 0; i < a1.length; i++) {
    a[a1[i]] = true;
  }

  for (var i = 0; i < a2.length; i++) {
    if (a[a2[i]]) {
      delete a[a2[i]];
    } else {
      a[a2[i]] = true;
    }
  }

  for (var k in a) {
    diff.push(k);
  }

  return diff;
}
