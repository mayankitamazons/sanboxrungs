const ResponseService = require('../shared/ResponseService'); // Response service
const User = require('../models/User'); // User model
const Like = require('../models/Like'); // Like model
const Blog = require('../models/Blog'); // Video model
const Comment = require('../models/Comment'); // Comment model
const Notification = require('../models/Notification'); // Comment model
const mongoose = require('mongoose');
const CRUD = require('../shared/CRUD')

const NotificationService = require('../shared/NotificationService')

function userDetail(id) {
    const user = new User();
    const userData = user.findById(id);
    ResponseService.generalPayloadResponse(null, userData, userData, );
    return;
}


exports.addLike = async function(req, res) {

    saveRecords = new Like;
    if (req.body.is_like == true) {

        var userRecords = await User.findById(req.body.userid);
        if (!userRecords) return ResponseService.generalResponse("User doesnt exist", res, 404);

        var BlogRecords = await Blog.findById(req.body.liked_blog);
        if (!BlogRecords) return ResponseService.generalResponse("Blog doesnt exist", res, 404);

        var creator_user_id = BlogRecords.creater_id;
        var creatorRecords = await User.findById(creator_user_id);
        let NoticeModel = new Notification;

        NoticeModel.noti_type = 3;
        NoticeModel.left_key = userRecords._id;
        NoticeModel.user = req.body.userid;
        NoticeModel.right_key = BlogRecords._id;
        NoticeModel.left_action = 2;
        NoticeModel.left_image = userRecords.profile_pic;
        NoticeModel.right_action = 3;
        NoticeModel.right_image = '';
        NoticeModel.noti_title = userRecords.name + " Liked on your blog"
        NoticeModel.noti_sub_title = "";

        if (NoticeModel) {
            console.log(NoticeModel);
            NoticeModel.save();
            console.log("Nofitication saved successfully.")

        }
        if (creatorRecords.notification_id) {
            const result = await NotificationService.sendToUserList(`${userRecords.name} Liked on your blog`, "Comment on blog...", creatorRecords.notification_id,
                NoticeModel);
        }


        BlogQuery = {};
        BlogQuery.$addToSet = { userlikes: req.body.userid }
        BlogRecords.likes_count = (BlogRecords.likes_count) + 1;
        await Blog.findByIdAndUpdate(req.body.liked_blog, BlogRecords, { new: true });
        await Blog.findByIdAndUpdate(req.body.liked_blog, BlogQuery, { new: true });
        saveRecords.userid = req.body.userid;
        saveRecords.liked_blog = req.body.liked_blog;
        saveRecords.is_like = true;
        saveRecords.save(async function(err, result) {
            if (err) {
                ResponseService.generalResponse("Something went wrong, please try again.", result, 401, "Something went wrong, please try again");
                return;
            } else {
                // var videoData = await Video.findById(saveRecords.likeed_video);

                // videoData.likes_count = videoData.likes_count + 1;

                //videoData.save();
                ResponseService.generalPayloadResponse(err, saveRecords, res);
                return;
            }
        });
    } else {
        //var userLikes = await User.findById(req.body.userid);
        //userLikes.likes_count = userLikes.likes_count - 1;
        // userLikes.save();
        //let videoRecord = await Video.findById(req.body.likeed_video);
        BlogQuery = {};
        BlogQuery.$pull = { userlikes: req.body.userid }
        Blog.findByIdAndUpdate(req.body.liked_blog, videoQuery, { new: true }, (err, doc) => {
            //  ResponseService.generalPayloadResponse(err, doc, res, undefined, "Done");
        });
        saveRecords.userid = req.body.userid;
        saveRecords.liked_blog = req.body.liked_blog;
        saveRecords.is_like = false;
        saveRecords.save(async function(err, result) {
            if (err) {
                ResponseService.generalResponse("Something went wrong, please try again.", result, 401, "Something went wrong, please try again");
                return;
            } else {
                //var videoData = await Video.findById(saveRecords.likeed_video);

                //videoData.likes_count = videoData.likes_count + 1;

                //videoData.save();
                ResponseService.generalPayloadResponse(err, saveRecords, res);
                return;
            }
        });
    }
}



exports.updateLike = async function(req, res) {
    if (req.body.userid) {
        try {

            const LikeData = await Like.find({ userid: req.body.userid, likeed_video: req.body.likeed_video });
            LikeData.forEach((data) => {
                data.is_like = req.body.is_like;
                data.save(async function(err, result) {
                    if (err) {
                        ResponseService.generalResponse("Something went wrong, please try again.", result, 401, "Something went wrong, please try again");
                        return;
                    } else {
                        var videoData = await Video.findById(data.videoid);
                        if (data.is_like) {
                            // videoData.likes_count = videoData.likes_count + 1;
                        } else {
                            //videoData.likes_count = videoData.likes_count - 1;
                        }

                        videoData.save(function(err, result) {
                            console.log(result);
                        });
                        ResponseService.generalPayloadResponse(err, result, res);
                        return;
                    }
                });
            });
        } catch (err) {
            ResponseService.generalPayloadResponse(err, {}, res);
        }
    }
}