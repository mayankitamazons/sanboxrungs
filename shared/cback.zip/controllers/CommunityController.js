const ResponseService = require('../shared/ResponseService'); // Response service
const Community = require('../models/Community'); // Topic model
const CRUD = require('../shared/CRUD');
const User = require('../models/User');

exports.communityList = async function(query, limit, page, type, body, res) {
    const model = Community;
    isrequested = query.isrequested;
    limit = 1000;
    if (isrequested == "y") {
        cdata = await Community.find({
            "isrequested": "y"
        }).populate('community_leader', "name username email userrole profile_pic mobile_no").sort({ name: 1 });

    } else if (query.status == 1) {

        cdata = await Community.find({ "status": 1 }).skip(page * limit).limit(limit)
            .populate('community_leader', "name username email userrole profile_pic mobile_no").sort({ name: 1 });

    } else if (query.status == 0) {
        cdata = await Community.find({ "status": 0 }).skip(page * limit).limit(limit)
            .populate('community_leader', "name username email userrole profile_pic mobile_no").sort({ name: 1 });

    } else {
        cdata = await Community.find({ "status": 1 }).skip(page * limit).limit(limit)
            .populate('community_leader', "name username email userrole profile_pic mobile_no").sort({ name: 1 });
    }

    ResponseService.generalPayloadResponse(null, cdata, res);
    return;
}

exports.communityFilter = async function(req, res) {

    const model = Community;
    var CommunityData;

    if (req.body.status) {
        CommunityData = await Community.find({ status: req.body.status });
    }
    ResponseService.generalPayloadResponse(null, CommunityData, res);
}
exports.addleader = function(req, res) {
    query = {};
    u_q = {};
    if (req.body.isAdd) {
        query.$addToSet = { community_leader: req.body.customer_id }
        u_q.is_community_leader = true;
    } else {
        query.$pull = { community_leader: req.body.customer_id }
        u_q.is_community_leader = false;
    }

    Community.findByIdAndUpdate(req.body.community_id, query, { new: true }, (err, doc) => {
        ResponseService.generalPayloadResponse(err, doc, res, undefined, "Added");
        User.findByIdAndUpdate(req.body.customer_id, u_q, { new: true }, (err, doc) => {
            console.log('User data updated');
        })

    })
}