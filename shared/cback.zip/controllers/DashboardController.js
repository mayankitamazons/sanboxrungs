const Category = require('../models/Category');
const Order = require('../models/Order');
const Product = require('../models/Product');
const User = require('../models/User');
const ResponseService = require('../shared/ResponseService'); // Response service

exports.getDasboard = async (req, res) => {


	if (!req.body.login_user_id) return ResponseService.generalResponse("Login Id is required", res, 404);

	const user = await User.findById(req.body.login_user_id);
	if (!user) return ResponseService.generalResponse("User not found", res, 404);

	body = {};

	if (req.body.dashboard_for == 1) {

		users = await User.find({ userRole: 2 }).sort('-registration_time');
		body.totalUsers = users.length;
		body.recentUsers = users.length >= 5 ? users.slice(0, 5) : users;

		sellers = await User.find({ userRole: 3 }).sort('-registration_time');
		body.totalSellers = sellers.length;
		body.recentSellers = sellers.length >= 5 ? sellers.slice(0, 5) : sellers;

		body.totalProducts = await Product.find().countDocuments();

		orders = await Order.find().sort("-created_at");
		body.totalOrders = orders.length;
		body.recentOrders = orders.length >= 5 ? orders.slice(0, 5) : orders;

		body.totalCategory = await Category.find().countDocuments();

	} else if (req.body.dashboard_for == 2) {
		orders = await Order.find({ seller_id: user._id }).sort("-created_at");
		body.totalOrders = orders.length;
		body.recentOrders = orders.length >= 5 ? orders.slice(0, 5) : orders;

		body.totalCategory = await Category.find({ sellerid: user._id }).countDocuments();

		products = await Product.find({ seller_id: user._id }).sort("-created_time");
		body.totalProducts = products.length;
		body.recentProducts = products.length >= 5 ? products.slice(0, 5) : products;

	} else {
		return ResponseService.generalResponse("Invalid Dashboard for", res, 404);
	}

	return ResponseService.generalPayloadResponse(null, body, res);

}