const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model

const Schema = new mongoose.Schema({
    userid: String,
    liked_blog: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Blog',
        index: true
    }],

    is_like: Boolean,
});

var autoPopulate = function(next) {
    this.populate('liked_blog', "title cover_image");
    next();
};
Schema.methods.saveFollow = function(val, type, res) {

    const model = createNewModelInstanceByName(type, val);
    model.save((err, val) => {
        ResponseService.generalPayloadResponse(err, val, res);
    });
}

module.exports = mongoose.model('Like', Schema);