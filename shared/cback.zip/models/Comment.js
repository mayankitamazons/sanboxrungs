const mongoose = require('mongoose');
const moment = require('moment-timezone');
const dateIndia = moment.tz(Date.now(), "Asia/Kolkata");

const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model

const Schema = new mongoose.Schema({
    userid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true
    },
    blogid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Blog',
        index: true
    },
    userlikes: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true
    }],
    isLike: {
        type: Boolean,
        default: false
    },
    likes_count: {
        type: Number,
        default: 0
    },
    time: {
        type: Date,
        default: Date.now
    },
    commentTime: String,
    comment: String,
    status: {
        type: Number,
        default: 1
    }
});

Schema.methods.saveComment = function(val, type, res) {

    const model = createNewModelInstanceByName(type, val);
    model.save((err, val) => {
        ResponseService.generalPayloadResponse(err, val, res);
    });
}
var autoPopulate = function(next) {
    this.populate('userid', "username name profile_pic");
    this.populate('userlikes', "username name profile_pic");
    this.populate('videoid', "title cover_image comment_status videoUrl");
    next();
};
module.exports = mongoose.model('Comment', Schema);