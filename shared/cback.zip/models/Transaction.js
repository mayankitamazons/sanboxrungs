const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types


const Schema = new mongoose.Schema({
    item_order_id: String,
    user_type: String,
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true
    },
    order_status: String,
    payment_status: String,
    payment_process: String,
    comment: String,
    created_date: {
        type: Date,
        default: Date.now
    }
});

var autoPopulate = function(next) {

    next();
};
module.exports = mongoose.model('Transaction', Schema);