const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model

const Schema = new mongoose.Schema({
    noti_type: {
        type: Number
    },
    left_image: {
        type: String,
        default: ''
    },
    left_key: {
        type: String,
        default: ''
    },
    // actions are 1 for user, 2 for video , 3 for hashtag
    left_action: {
        type: Number
    },
    right_image: {
        type: String,
        default: ''
    },
    right_key: {
        type: String,
        default: ''
    },
    // actions are 1 for user, 2 for video , 3 for hashtag
    right_action: {
        type: Number
    },
    left_image: {
        type: String,
        default: ''
    },
    left_key: {
        type: String,
        default: ''
    },
    // actions are 1 for user, 2 for video , 3 for hashtag
    noti_title: {
        type: String,
        default: ''
    },
    noti_sub_title: {
        type: String,
        default: ''
    },
    // User only attributes
    // User only attributes
    videoList: [],
    status: {
        type: Number,
        default: 1
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true
    },
    status: {
        type: Number,
        default: 1
    },
    created_date: {
        type: Date,
        default: Date.now
    }

});

Schema.methods.saveNotification = function(val, type, res) {

    const model = createNewModelInstanceByName(type, val);
    model.save((err, val) => {
        ResponseService.generalPayloadResponse(err, val, res);
    });
}

module.exports = mongoose.model('Notification', Schema);