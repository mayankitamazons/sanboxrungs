const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model

const Schema = new mongoose.Schema({
    //attr_id: String,
    product_id: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Product',
            index: true
        }],
    attr_id: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Attribue',
            index: true
        }],
    attr_option_value: String
});

var autoPopulate = function (next) {
    this.populate('seller_id', "name username email userrole profile_pic");
    this.populate('cat_id', "cat_name image");
    next();
};
module.exports = mongoose.model('ProductConfig', Schema);