const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD');
const Types = require('../shared/Types'); // Model types
const URLSlug = require("mongoose-slug-generator");


const Schema = new mongoose.Schema({
    //  1 active, 0 inactive    
    is_active: {
        type: Number,
        default: 1 // 1 for generate 0 = default
    },
    visibility: {
        type: String,
        default: "public" // public  or private
    },
    coupon_type: {
        type: String,
        default: "fixed" // percent or fixed
    },
    rule_type: {
        type: String,
        default: "checkout" // checkout
    },
    //   1 for fix coupon , 2 for random 
    coupon_method: {
        type: Number,
        defalut: 1
    },
    coupon_count: {
        type: Number,
        defalut: 1
    },
    coupon_code: { type: String, required: true, unique: true },
    uses_per_customer: {
        type: Number,
        default: 0
    },
    uses_per_coupon: {
        type: Number,
        default: 0
    },
    conditional_value: String,
    description: {
        type: String,
        defalut: ""
    },
    amount: {
        type: Number,
        required: true
    },
    start_date: Date,
    end_date: Date,
    created_at: Date,
    coupon_label: String,
    min_amount: Number,
    max_amount: Number,
    // assing to 1- for all , 2-spericific user 
    assing_to: {
        type: String,
        default: 'all'
    },
    assigned_user_id: [],
    creater_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    },
    // admin  , seller 
    created_by: {
        type: String,
        defalut: "admin"
    },
    created_time: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Coupon', Schema);