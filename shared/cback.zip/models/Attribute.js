const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types

///attribute table here
const Schema = new mongoose.Schema({
    input_name: String,
    input_type: String,
    assoc_type: String, //1 -product, 2 service
    atrr_code: String,
    atrr_code: String,
    status: {
        type: Number,
        default: 1
    },
    style_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'AttributeStyle',
        index: true,
        default: ''
    }],
    created_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = function(next) {
    this.populate('style', "style_name comment");

    next();
};
module.exports = mongoose.model('Attribute', Schema);

//Brand (Attribute)
//
//  samsung Attribeoption 
//  Apple Attribeoption
//
//
//Product 
//
//  iPhone 11
//  
//  
//  Product 
//      Brand Attribe id  (iphone)
//      Color Attribue Option 
//      
//      
// Product Open 
// 
//    Objects of Attirbute (Iphone)
//    Objects of Attirbute (Iphone)