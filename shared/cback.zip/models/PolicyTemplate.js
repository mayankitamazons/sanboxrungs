const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types


const Schema = new mongoose.Schema({
    policy_for: String,
    policy_name: String,
    content: String,
    icon: String,
    created_date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('PolicyTemplate', Schema);