const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD');
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model
const Community = require('../models/Community'); // Community model
const Category = require('../models/Category'); // Category model
const Attribute = require('../models/Attribute'); // Attribute model
const AttributeOption = require('../models/AttributeOption'); // AttributeOption model
const SellerProduct = require('../models/SellerProduct');


const URLSlug = require("mongoose-slug-generator");
mongoose.plugin(URLSlug);


const Schema = new mongoose.Schema({
    //  1 active, 0 inactive    
    is_active: {
        type: Number,
        default: 1
    },
    allow_checkout: {
        type: Number,
        default: 1
    },
    items_qty: {
        type: Number,
        default: 1
    },

    customer_email: String,
    expected_delivery_date: {
        type: String,
        default: ''
    },
    discount_description: String,
    subtotal: {
        type: Number,
        default: 0
    },
    grandtotal: {
        type: Number,
        default: 0
    },
    currency: {
        type: String,
        default: "INR"
    },
    payment_method: {
        type: String,
        default: "cash on delivery"
    },
    vat: {
        type: Number,
        default: 0
    },
    shipping_amount: {
        type: Number,
        default: 0
    },
    discount_amount: {
        type: Number,
        default: 0
    },
    tax_amount: {
        type: Number,
        default: 0
    },
    customer_group_id: Number,
    customer_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true
    },
    coupon_code: {
        type: String,
        default: ''
    },

    //cartitem  [name,price,qty,subtoal,product_id,item_options]

    cartitem: [],
    address: {},
    created_at: Date,
    updated_at: {
        type: Date,
        default: Date.now
    }
});

var autoPopulate = function(next) {

    this.populate('customer_id', "name username email userrole profile_pic");
    next();
};

module.exports = mongoose.model('Cart', Schema);