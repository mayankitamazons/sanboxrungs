const mongoose = require("mongoose");
const Schema = new mongoose.Schema({
  name: {
    type: String,
    default: "",
  },

  email: {
    type: String,
    index: true,
  },

  country_code: {
    type: String,
    default: "+91",
  },
  login_method: {
    type: Number,
    default: 1,
  },
  mobile_no: {
    type: String,
    index: true,
  },
  // 1 for admin ,2 for user
  userRole: {
    type: Number,
    default: 2,
  },
  social_id: {
    type: String,
    index: true,
  },
  password: String,
  profile_pic: {
    type: String,
    default: "",
  },
  temp_password: String,
  resetPasswordToken: String,
  resetPasswordExpires: Date,
  device_token: String,
  access_token: String,
  status: {
    type: Number,
    default: 1,
  },
  user_id: String,
  gender: String,
  last_login: Date,
  notification_id: [String],

  send_notifcation: {
    type: Boolean,
    default: true,
  },

  address_detail: [
    {
      full_name: {
        type: String,
        default: "",
      },
      email: {
        type: String,
        index: true,
      },
      mobile_no: {
        type: String,
        index: true,
      },
      adderess_1: {
        type: String,
        default: "",
      },
      adderess_2: {
        type: String,
        default: "",
      },
      adderess_3: {
        type: String,
        default: "",
      },
      adderess_4: {
        type: String,
        default: "",
      },
      adderess_5: {
        type: String,
        default: "",
      },
      pin_code: {
        type: String,
        default: "",
      },
      locality: {
        type: String,
        default: "",
      },
      city: {
        type: String,
        default: "",
      },
      state: {
        type: String,
        default: "",
      },
      landmark: {
        type: String,
        default: "",
      },
      alternative_phone: {
        type: String,
        default: "",
      },
      address_type: {
        type: String,
        default: "",
      },
    },
  ],
  registration_time: {
    type: Date,
    default: Date.now,
  },

  wishList: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Product",
      index: true,
    },
  ],
});

Schema.methods.toJSONFor = function (user) {
  return {
    slug: this.slug,
    title: this.title,
    description: this.description,
    body: this.body,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt,
  };
};

module.exports = mongoose.model("User", Schema);
