const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model

const Schema = new mongoose.Schema({
    blockid: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Block',
        index: true
    }],
    videolink: String,
    content_type: {
        type: Number,
        default: 1
    },
    search_key: {
        type: String,
        default: ''
    },
    cover_image: String,
    status: {
        type: Number,
        default: 1
    },
    created_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = function(next) {
    this.populate('blockid', "position title content_view search_key");
    next();
};

module.exports = mongoose.model('Item', Schema);