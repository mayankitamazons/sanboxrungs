const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    title: String,
    sub_title: String,
    image: String,
    slug: String,
    button_text: String,
    // 1 -for category page , 2- for single product page , 3-for event listing , 4- near by shops listing 
    button_action: {
        type: Number,
        default: 1
    },
    search_key: {
        type: String,
        default: ''
    },
    status: {
        type: Number,
        default: 1
    },
    banner_position: {
        type: Number,
        default: 1
    },
    // 1 for home page, 2 -for category page 
    banner_for: {
        type: Number,
        default: 1
    },
    // 1 -for banner 1, 2- banner 2, 3- banner 3
    banner_type: {
        type: Number,
        default: 1
    },
    category_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        index: true,
        default: ''
    }],
    community_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Community',
        index: true,
        default: ''
    }],
    created_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = function(next) {
    this.populate('Community', "builder_name name locality pincode city status")

    next();
};

module.exports = mongoose.model('Banner', Schema);