const mongoose = require('mongoose');
const slug = require('mongoose-slug-generator');
mongoose.plugin(slug);
const Schema = new mongoose.Schema({

    title: String,
    
    slug: { type: String, slug: "title" },
    icon: String,
    slug: String,
    description: String,
    image: String,
    root_path: {
        type: String,
        default: ''
    },
    isTrending: {
        type: Boolean,
        default: false
    },
    haveChild: {
        type: Boolean,
        default: false
    },
    //    childCount: {
    //        type: Number,
    //        default: 0
    //    },
    store_id: {
        type: Number,
        default: 1 //india for multi lang
    },
    parent_id: [],
    //    path: [],
    creater_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    }],
   
    // 1 for active, 2 for requested, 0 - inactive , 3- rejected 
    status: {
        type: Number,
        default: 1
    },
    show_menu: {
        type: Number,
        default: 1
    },
   
    created_date: {
        type: Date,
        default: Date.now
    },
    updated_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = function(next) {
    this.populate('creater_id', "name email");
    next();
};
module.exports = mongoose.model('Category', Schema);