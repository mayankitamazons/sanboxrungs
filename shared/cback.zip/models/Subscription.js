const mongoose = require('mongoose');

const Schema = new mongoose.Schema({

	price: {
		type: Number,
		default: 0
	},

	// Duration in days
	duration: {
		type: Number,
		default: 0
	},

	// -1 for all products, 0 for 0 products and so on
	maximum_product: {
		type: Number,
		default: -1
	}

}, {
	timestamps: true
});

module.exports = mongoose.model('Subscription', Schema);