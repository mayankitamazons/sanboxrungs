const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types


const Schema = new mongoose.Schema({
    color_name: String,
    color_code: String,
    content: String,
    // 1 for active, 2 for requested, 0 - inactive , 3- rejected 
    status: {
        type: Number,
        default: 1
    },
    created_date: {
        type: Date,
        default: Date.now
    },
    updated_date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('ColorTemplate', Schema);