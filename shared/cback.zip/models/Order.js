const mongoose = require('mongoose');

const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD');
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model
const Community = require('../models/Community'); // Community model
const Category = require('../models/Category'); // Category model
const Attribute = require('../models/Attribute'); // Attribute model
const AttributeOption = require('../models/AttributeOption'); // AttributeOption model
const SellerProduct = require('../models/SellerProduct');


const slugGenerator = require("mongoose-slug-generator");
const autoIncrement = require('mongoose-auto-increment');
autoIncrement.initialize(mongoose.connection);
const Schema = new mongoose.Schema({
	items_qty: {
		type: Number,
		default: 1
	},
	customer_email: String,
	status: {
		type: Number,
		default: 1

	},
   // 1 - order placed, 2 - packed , 3- shipped, 4- delivered, 5 - cancel by customer ,6- return by customer 
   // 7- return accepted , 8- refund done , 9- return rejected 
	order_status: {
		type: Number,
		default: 1
	},
	discount_description: String,
	subtotal: Number,
	grandtotal: Number,
	currency: String,
	invoice_no: String,
	payment_method: String,
	vat: Number,
	shipping_amount: {
		type: Number,
		default: 0
	},
	discount_amount: Number,
	tax_amount: Number,
	customer_group_id: Number,
	increment_id: Number,
	customer_id: {
		type: mongoose.Schema.Types.ObjectId,
		ref: 'User',
		index: true
	},
	cart_id: {
		type: mongoose.Schema.Types.ObjectId,
		ref: 'Cart',
		index: true
	},
	coupon_code: {
		type: String,
		default: ''
	},

	is_reviewed: {
		type: Boolean,
		default: false
	},

	//cart_it[product_id,price,subtotal,custom_option,ordered_quanity,cancelled_quantity,refund _quantity

	cartitem: [],
	tracking_detail: [{
		track_msg: {
			type: String,
			default: ''
		},
		track_code: {
			type: String,
			default: ''
		},
		creater_id: {
			type: mongoose.Schema.Types.ObjectId,
			ref: 'User',
			index: true,
		},
		created_time: {
			type: Date,
			default: Date.now
		}


	}],
	address: {},
	rejection_point: String,
	comment: String,
	// rating and revieww 
	// 1- requested , 2- done , 3-return cancelld , 0- not submitted ,4- payment credited back 
	return_status: {
		type: Number,
		default: 0

	},
	expected_delivery_date: {
		type: String,
		default: ''
	},
	return_time_expire: {
		type: Boolean,
		default: false
	},
	created_at: {
		type: Date,
		default: Date.now
	},
	is_parent_order: {
		type: Boolean,
		default: false
	},
	childOrders: [],
	updated_at: {
		type: Date,
		default: Date.now
	},
	invoice_path: String
});

var autoPopulate = function (next) {

	this.populate('customer_id', "name username email userrole profile_pic");
	next();
};

Schema.plugin(autoIncrement.plugin, {
	model: 'Order',
	field: 'increment_id',
	startAt: 10000000,
	incrementBy: 1
});

Schema.plugin(autoIncrement.plugin, {
	model: 'Order',
	field: 'invoice_no',
	startAt: 1000000000,
	incrementBy: 1
})

module.exports = mongoose.model('Order', Schema);