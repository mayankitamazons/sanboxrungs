const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    title: String,
    description: String,
    slug: String,
    cover_image: String,
    createdTime: String,
    pictures: [],
    status: {
        type: Number,
        default: 1
    },

    blog_position: {
        type: Number,
        default: 1
    },
    // 1 for home page, 2 -for category page 
    creater_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    },
    community_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Community',
    }],
    share_count: {
        type: Number,
        default: 0
    },
    isLike: {
        type: Boolean,
        default: false
    },
    likes_count: {
        type: Number,
        default: 0
    },
    comment_count: {
        type: Number,
        default: 0
    },
    userlikes: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true
    }],
    top_blogger: {
        type: Boolean,
        default: false
    },
    created_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = function(next) {

    this.populate('creater_id', "username name profile_pic");
    this.populate('community_id', "builder_name name pincode");
    this.populate('userlikes', "username name profile_pic");
    next();
};

module.exports = mongoose.model('Blog', Schema);