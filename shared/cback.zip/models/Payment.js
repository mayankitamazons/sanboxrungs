const mongoose = require('mongoose');

const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD');
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model
const Community = require('../models/Community'); // Community model
const Category = require('../models/Category'); // Category model
const Attribute = require('../models/Attribute'); // Attribute model
const AttributeOption = require('../models/AttributeOption'); // AttributeOption model
const SellerProduct = require('../models/SellerProduct');

const Schema = new mongoose.Schema({
    //  1 active, 0 inactive    
    is_active: {
        type: Number,
        default: 1
    },
    name: String,
    code: String,
    created_at: Date,
    updated_at: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Payment', Schema);