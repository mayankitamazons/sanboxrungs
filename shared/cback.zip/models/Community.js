const mongoose = require('mongoose');
const Schema = new mongoose.Schema({
    //name: String,
    name: {
        type: String,
        required: true,
    },
    //profile_pic: String,
    locality: {
        type: String,
       
    },
    pincode: {
        type: String,
        
    },
    city: {
        type: String,
        
    },

    status: {
        type: Number,
        default: 1,
       
    },
    created_date: {
        type: Date,
        default: Date.now
    },
    creater_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    }
});

module.exports = mongoose.model('Community', Schema);