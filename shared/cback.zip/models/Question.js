const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    question: {
        type: String,
        index: true
    },
    slug: String,
    answers: [{
        text: String,
        isCorrect: Boolean,
        vote_count: {
            type: Number,
            default: 0
        },
        vote_per: {
            type: String,
            default: ''
        },
    }],
    question_type: {
        type: Number,
        default: 1
    },
    creater_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    },
    community_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Community',
    }],
    share_count: {
        type: Number,
        default: 0
    },
    isVoted: {
        type: Boolean,
        default: false
    },
    poll_complete: {
        type: Boolean,
        default: false
    },
	voting_complete_time:{
		type:Date
	},
    status: {
        type: Number,
        default: 1
    },
    total_vote: {
        type: Number,
        default: 0
    },
    // 1 for anonymous  and 2 -for non anonymous
    share_status: {
        type: Number,
        default: 1
    },
    voters: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true
    }],
    created_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = function(next) {

    this.populate('creater_id', "username name profile_pic");
    this.populate('community_id', "builder_name name pincode");
    this.populate('userlikes', "username name profile_pic");
    next();
};
module.exports = mongoose.model('Question', Schema);