const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    title: String,
    description: String,
    slug: String,
    createdTime: String,
    start_date: String,
    end_date: String,
    pictures: [],
    status: {
        type: Number,
        default: 1
    },
    // 1 for home page, 2 -for category page 
    creater_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    },
    community_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Community',
    }],
    seller_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    }],
    share_count: {
        type: Number,
        default: 0
    },
    created_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = function(next) {

    this.populate('creater_id', "username name profile_pic");
    this.populate('seller_id', "username name profile_pic");
    this.populate('community_id', "builder_name name pincode");

    next();
};

module.exports = mongoose.model('Event', Schema);