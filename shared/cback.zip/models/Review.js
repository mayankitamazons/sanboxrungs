const mongoose = require('mongoose');

const ReviewSchema = new mongoose.Schema({
    order_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Order',
        index: true,
        required: true
    },

    product_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        index: true,
        required: true
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
        required: true
    },
    rating: {
        type: Number,
    },
    review: String,
    images: Array,
    status: {
        type: Number,
        default: 1
    },
    created_date: {
        type: Date,
        default: Date.now
    },
    createdTime: String

});

module.exports = mongoose.model('Review', ReviewSchema);