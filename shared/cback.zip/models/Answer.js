const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    question_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Question',
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    },
    answers: {
        type: String,
        default: ''
    },

    created_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = (next) => {

    this.populate('question_id', "question slug answers");
    this.populate('creater_id', "username name profile_pic");
    next();
};
module.exports = mongoose.model('Answer', Schema);