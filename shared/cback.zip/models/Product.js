const mongoose = require('mongoose');

const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model
const Community = require('../models/Community'); // Community model
const Category = require('../models/Category'); // Category model
const Attribute = require('../models/Attribute'); // Attribute model
const AttributeOption = require('../models/AttributeOption'); // AttributeOption model
const SellerProduct = require('../models/SellerProduct');


const URLSlug = require("mongoose-slug-generator");
mongoose.plugin(URLSlug);


const Schema = new mongoose.Schema({
    product_en: {
        type: String,
        required: true
    },
    product_hn: String,
    sku: { type: String },
    icon: { type: String, required: true },
    pictures: [],
    description: String,
    slug: String,
    //slug: { type: String, slug: "product_en",unique: true },
    cat_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
    }],
    size_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'SizeTemplate',
    }],
    color_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ColorTemplate',
    }],
    is_recommmend: {
        type: Boolean,
        default: false
    },
    is_trending: {
        type: Boolean,
        default: false
    },
    is_topoffer: {
        type: Boolean,
        default: false
    },
    community_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Community',
    }],
    config_attr: [],
   
    shippingCost: {
        type: Number,
        default: 0
    },
    tax: {
        type: Number,
        default: 0
    },
   
    product_tier: [{
        price: Number,
        qty: Number,
        conditional_statment: String,
        seller_id: String
    }],

    //1 simple, 2 configuration
    product_type: {
        type: String,
        default: "1"
    },
    creater_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    },
    //  1 Enable, 2 disable ,3 draft    
    status: {
        type: Number,
        default: 1
    },
    multiseller: {
        type: Boolean,
        default: false
    },
    attributeStyleId: String,
    seller_status: {
        type: Number,
        default: 0
    },
    delivery_time: {
        type: String,
        default: ''
    },
    delivery_slot: {
        type: String,
        default: ''
    },
    // return
    retunr_time: {
        type: Number,
        default: 7
    },
    qty_attr: [],
    attribute: [],
    stock_data: [{
        stock_value: {
            type: Number,
            default: 0
        },
        s_type: {
            type: String
        },
        comment: {
            type: String
        },
        creater_id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            index: true,
        },
        created_time: {
            type: Date,
            default: Date.now
        }


    }],
    //tERMS 
    //
    //    numeric_attribute:[{
    //        attribute_id:Number,
    //        attribute_value:Number,
    //    }],
    //    varchar_attribute:[{
    //        attribute_id:Number,
    //        attribute_value:String,
    //    }],
    //    text_attribute:[{
    //        attribute_id:Number,
    //        attribute_value:String,
    //    }],
    video: [],
    parent_id: String,
    price: Number,
    special_price: Number,
    from_Date: Date,
    to_Date: Date,
    qty: Number,
    min_stock: Number,
    on_cart: {
        type: Number,
        default: 0
    },
    used_stock: {
        type: Number,
        default: 0
    },
    pending_stock: {
        type: Number,
        default: 0
    },
    fetchParentInfo: Boolean,
    policy_text: {
        type: String,
        default: ''
    },
    policy_image: {
        type: String,
        default: ''
    },
    seller_stock: [],
    created_time: {
        type: Date,
        default: Date.now
    },
    otherProducts: [],
    is_wishlist: {
        type: Boolean,
        default: false
    },
    is_on_cart: {
        type: Boolean,
        default: false
    },
    reviews: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Review'
    }]

});
var autoPopulate = function(next) {
    this.populate('cat_id', "cat_name image");
    this.populate('community_id', "name pincode");
    this.populate('creator_id', "name username email userrole profile_pic");
    next();
};


module.exports = mongoose.model('Product', Schema);