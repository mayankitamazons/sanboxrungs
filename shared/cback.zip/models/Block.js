const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model

const Schema = new mongoose.Schema({
    position_nebr: {
        type: Number,
        default: 1
    },
    title: String,
 
    // 1 for banner view, 2 for top category list, 3 -all rugs style 
					// 4- recent views style , 5- similar product style , 6- service label style 
					// 7-  spotligh view, 8- shop by size, 9- popular rugs style,10 ads list 
					// 11 - banner list , 12 single image view  
    content_view: {
        type: Number,
        default: 1
    },
    search_key: [{
        type: String,
        default: ''
    }],
    Record: Array,
    cover_image: {
        type: String,
        default: 'https://img.favpng.com/21/13/20/logo-the-times-of-india-brand-font-png-favpng-SMDK0xdR9d2sQ5S1d1mjaWt5i.jpg'
    },
    sub_title: {
        type: String,
        default: ''
    },
    button_title: {
        type: String,
        default: ''
    },
    community_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Community',
    }],
    status: {
        type: Number,
        default: 1
    },
    created_date: {
        type: Date,
        default: Date.now
    }
});
module.exports = mongoose.model('Block', Schema);