const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types

///attribute option table here
const Schema = new mongoose.Schema({
    attr_id: String,
    att_value: [],
    created_date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('AttributeOption', Schema);