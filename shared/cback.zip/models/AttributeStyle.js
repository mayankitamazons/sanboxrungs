const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types

///attribute table here
const Schema = new mongoose.Schema({
    style_name: String,
    comment: String,
    // style for 1- attribute , 2 for size
    style_type: {
        type: Number,
        default: 1
    },
    status: {
        type: Number,
        default: 1
    },
    created_date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('AttributeStyle', Schema);