const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    full_name: {
        type: String,
        default: ""
    },
    email: {
        type: String,
        index: true
    },
    mobile_no: {
        type: String,
        index: true
    },
    adderess_1: {
        type: String,
        default: ""
    },
    adderess_2: {
        type: String,
        default: ""
    },
    adderess_3: {
        type: String,
        default: ""
    },
    adderess_4: {
        type: String,
        default: ""
    },
    adderess_5: {
        type: String,
        default: ""
    },
    pin_code: {
        type: String,
        default: ""
    },
    locality: {
        type: String,
        default: ""
    },
    city: {
        type: String,
        default: ""
    },
    state: {
        type: String,
        default: ""
    },
    landmark: {
        type: String,
        default: ""
    },
    alternative_phone: {
        type: String,
        default: ""
    },
    address_type: {
        type: String,
        default: ""
    },
    status: {
        type: Number,
        default: 1
    },
    latitude: {
        type: String,
        default: ""
    },
    longitude: {
        type: String,
        default: ""
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    },
    created_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = function(next) {
    this.populate('user_id', "name mobile_no");
    next();
};

module.exports = mongoose.model('Address', Schema);