const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    title: String,
    description: String,
    community_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Community',
    }],
    creater_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    },
    pictures: [],
    status: {
        type: Number,
        default: 1
    },
    start_date: String,
    end_date: String,
    // requested , approve  , rejected 
    seller_register_stauts: {
        type: String,
        default: "pending"
    },
    charges_amount: Number,
    total_amount: Number,
    charges_type: {
        type: Number,
        default: 1
    },
    isBooked: {
        type: Boolean,
        default: false
    },
    accepted_detail: [],
    seller_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    }],
    location: String,
    created_date: {
        type: Date,
        default: Date.now
    },
    createdTime: String

});

var autoPopulate = function(next) {

    this.populate('event_id', "title slug start_date end_date");
    this.populate('seller_id', "name username email userrole profile_pic");
    next();
};

module.exports = mongoose.model('Slot', Schema);