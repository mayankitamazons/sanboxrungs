const mongoose = require('mongoose');
const ResponseService = require('../shared/ResponseService'); // Response service
const CRUD = require('../shared/CRUD')
const Types = require('../shared/Types'); // Model types
const User = require('../models/User'); // User model

const Schema = new mongoose.Schema({
    seller_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true
    },
    product_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        index: true
    },
    community_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Community',
    }],
    price: Number,
    special_price: Number,
    min_stock: Number,
    qty: {
        type: Number,
        default: 0
    },
    on_cart: {
        type: Number,
        default: 0
    },
    used_stock: {
        type: Number,
        default: 0
    },
    pending_stock: {
        type: Number,
        default: 0
    },
    status: {
        type: Number,
        default: 1
    },
    stock_data: [{
        stock_value: {
            type: Number,
            default: 0
        },
        s_type: {
            type: String
        },
        comment: {
            type: String
        },
        created_time: {
            type: Date,
            default: Date.now
        }


    }],
    name: String,
    username: String,
    profile_pic: String,
    business_name: String,
    // service based prodcut data
    // slot_start_time ,slot_end_time,service_count,booking_status
    // booking_status 1- for avilable , 2- booked -- service_count
    group_slot: [{
        min_qty: {
            type: Number,
            default: 1

        },

        product_sell: {
            type: Number,
            default: 0

        },
        sell_start_date: {
            type: Date,
            default: Date.now
        },
        sell_end_date: {
            type: Date
        },
        delivery_time: {
            type: String,
            default: ''
        },
        delivery_slot: {
            type: String,
            default: ''
        },
        // 1 for manual , 2 for automatic
        rollout_type: {
            type: Number,
            default: 1

        },
        //  1 Enable, 2 disable ,3 draft    
        status: {
            type: Number,
            default: 1
        },
        comment: {
            type: String,
            default: ''
        },
        price: Number,
        special_price: Number,

    }],
    service_day_slot: [{
        "slot_days": {
            type: Number,
            default: 1

        },
        "slot": [{
            "slot_start_time": {
                type: String,
                defalut: "00:00"
            },
            "slot_end_time": {
                type: String,
                defalut: "00:00"
            },
            "booking_status": {
                type: Number,
                defalut: 1
            },
            "service_count": {
                type: Number,
                defalut: 1
            },
            product_sell: {
                type: Number,
                default: 0

            },
            "booking": []
        }],


    }],
    created_time: {
        type: Date,
        default: Date.now
    }
});

var autoPopulate = function(next) {
    this.populate('seller_id', "name username email userrole profile_pic");
    next();
};
module.exports = mongoose.model('SellerProduct', Schema);

exports.createSellerProduct = function(params) {
    const sp = new SellerProduct(params);
    const result = sp.save();
};