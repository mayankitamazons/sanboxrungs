const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    order_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Order',
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        index: true,
    },
    product: [],
    sub_title: {
        type: String,
        default: ''
    },
    community_id: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Community',
    }],
    created_date: {
        type: Date,
        default: Date.now
    }
});
var autoPopulate = (next) => {
    next();
};
module.exports = mongoose.model('LeaderBoard', Schema);