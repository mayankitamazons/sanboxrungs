const mongoose = require('mongoose');
const URLSlug = require("mongoose-slug-generator");
mongoose.plugin(URLSlug);

const Schema = new mongoose.Schema({
    key: String,
    title: String,
    content: String,
    slug: { type: String, slug: "title", unique: true },
    image: {
        type: String,
        default: ''
    },
    seo_title: String,
    seo_content: String,
    status: {
        type: Number,
        default: 1
    },
    footer_type: {
        type: Number,
        default: ''
    },
    created_date: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Page', Schema);