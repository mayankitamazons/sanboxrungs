// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//SizeTemplate Controller
const SizeTemplateController = require('../controllers/SizeTemplateController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', (req, res) => CRUD.create(req.body, Types.SIZE, res));


router.post('/list', (req, res) => SizeTemplateController.list({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.SIZE,
    req.body,
    res));
// Update

router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.SIZE, res));
// Get by id

router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.SIZE, res));

module.exports = router;