// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')

//Block Controller
const AddressController = require('../controllers/AddressController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.ADDRESS, res));

// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.ADDRESS, res));

// Get all
router.post('/list', CheckAuth, AddressController.addresslist);

// Get by id
router.get('/:id', CheckAuth, (req, res) => CRUD.getById(req.params.id, Types.ADDRESS, res));

module.exports = router;   