// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Coupon Controller
const CouponController = require('../controllers/CouponController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')


router.post('/addcoupon', (req, res) => CouponController.add(req, res));
router.post('/assignuser', (req, res) => CouponController.assignuser(req, res));
router.post('/removeuser', (req, res) => CouponController.removeuser(req, res));
// router.put('/:id', (req, res) => CouponController.update(req.params.id, req.body, Types.COUPON, res));
router.put('/:id', (req, res) => CouponController.updateByid(req, res));
router.post('/couponlist', (req, res) => CouponController.list({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.COUPON,
    req.body,
    res
));
// Get by id
router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.COUPON, res));


module.exports = router;