// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Category Controller
const BannerController = require('../controllers/BannerController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
//router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.BANNER, res));
router.post('/', (req, res) => BannerController.add(req, res));
//Filter
// router.post('/categorylist', CheckAuth, CategoryController.categorylist);
router.post('/list', (req, res) => BannerController.list({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.BANNER,
    req.body,
    res));
// Update
router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.BANNER, res));
// Get by id
router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.BANNER, res));
module.exports = router;