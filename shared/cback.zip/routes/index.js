const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// API v1 routes
// Auth routes
const AuthRoutes = require('./authRoutes');
router.use('/auth', AuthRoutes);

// User routes
const UserRoutes = require('./userRoutes');
router.use('/user', UserRoutes);

// Notification routes
const NotificationRoutes = require('./notificationRoutes');
router.use('/notification', NotificationRoutes);

// Page routes
const PageRoutes = require('./pageRoutes');
router.use('/page', PageRoutes);

// Block routes    
const BlockRoutes = require('./blockRoute');
router.use('/block', BlockRoutes);

// Item routes
const ItemRoutes = require('./itemRoute');
router.use('/item', ItemRoutes);

// Category routes
const CategoryRoutes = require('./categoryRoute');
router.use('/category', CategoryRoutes);
// Community routes

const CommunityRoutes = require('./CommunityRoute');
router.use('/Community', CommunityRoutes);

// Product routes
const ProductRoute = require('./ProductRoute');
router.use('/product', ProductRoute);
   
// Policy routes
const PolicyTemplateRoute = require('./PolicyTemplateRoute');
router.use('/policy', PolicyTemplateRoute);
// Color routes
const ColorTemplateRoute = require('./ColorTemplateRoute');
router.use('/color', ColorTemplateRoute);
// Size routes
const SizeTemplateRoute = require('./SizeTemplateRoute');
router.use('/size', SizeTemplateRoute);
// Product config
const ProductConfigRoutes = require('./ProductConfigRoute');
router.use('/productconfig', ProductConfigRoutes);
// Seller Product
const SellerProductRoutes = require('./SellerProductRoute');
router.use('/sellerproduct', SellerProductRoutes);
// Attributestyle
const AttributeStyleRoute = require('./AttributeStyleRoute');
router.use('/style', AttributeStyleRoute);
// Attribute 
const AttributeRoutes = require('./AttributeRoute');
router.use('/Attribute', AttributeRoutes);


// Attribute 
const AttributeOptionRoute = require('./AttributeOptionRoute');
router.use('/attributeoption', AttributeOptionRoute);
// Block routes
const BannerRoute = require('./BannerRoute');
router.use('/banner', BannerRoute);
// Blog routes
const BlogRoute = require('./BlogRoute');
router.use('/blog', BlogRoute);
// Blog like 
const LikeRoute = require('./likeRoutes');
router.use('/like', LikeRoute);
// Comment routes
const CommentRoute = require('./commentRoutes');
router.use('/comment', CommentRoute);
// Poll routes
const PollRoute = require('./questionRoutes');
router.use('/poll', PollRoute);
// Misc routes

const AnswerRoute = require('./answerRoutes');
router.use('/answer', AnswerRoute);

// Cart 
const CartRoute = require('./CartRoute');
router.use('/cart', CartRoute);

// Order 
const OrderRoute = require('./OrderRoute');
router.use('/order', OrderRoute);
// LeaderBaord sharing 
// Event 
const EventRoute = require('./EventRoute');
router.use('/event', EventRoute);

//Time slot
const SlotRoute = require('./SlotRoute');
router.use('/slot', SlotRoute);

// Coupon 
const CouponRoute = require('./CouponRoute');
router.use('/coupon', CouponRoute);

// Coupon 
const PaymentRoute = require('./paymentRoute');
router.use('/payment', PaymentRoute);

// Event 
const LeaderBoardRoute = require('./LeaderBoardRoute');
router.use('/leaderboard', LeaderBoardRoute);

// REview
const ReviewRoute = require('./ReviewRoute');
router.use('/review', ReviewRoute);
const AddressRoutes = require('./AddressRoutes');
router.use('/address', AddressRoutes);
// Dashboard
const dashboardController = require('../controllers/DashboardController');
router.post('/dashboard', dashboardController.getDasboard);

const MiscRoutes = require('./misc');
router.use('/', MiscRoutes);

// All delete route
router.delete('/delete/:type/:id', CheckAuth, (req, res) => CRUD.statusChangeById(req.params.id, Types[req.params.type], res));

// All delete route
router.delete('/deleteper/:type/:id', CheckAuth, (req, res) => CRUD.perDelete(req.params.id, Types[req.params.type], res));

// Common upload route
const UploadController = require('../controllers/UploadController');

const FileController = require('../controllers/FileController');
const Order = require('../models/Order');

// router.post('/upload', CheckAuth, UploadController.uploadFile);
// For upload on S3
router.post('/uploadvideo', CheckAuth, UploadController.uploadVideoFileS3);

// For upload File on S3
router.post('/upload', FileController.uploadFileS3);

// Email routes for creating, updating
const EmailRoutes = require('./EmailRoute');
router.use('/email', EmailRoutes);

// For upload on Local
//router.post('/uploadvideo', CheckAuth, UploadController.uploadVideoFile);
module.exports = router;