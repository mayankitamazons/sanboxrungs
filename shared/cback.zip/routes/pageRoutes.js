// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.PAGE, res));

// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.PAGE, res));
//Category Controller
const CategoryController = require('../controllers/CategoryController');
// Get all
router.get('/', (req, res) => CategoryController.pagelist({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.PAGE,
    req.query,
    res));


// Get by id
router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.PAGE, res));
router.get('/slug/:slug', (req, res) => CRUD.getBySlug(req.params.slug, Types.PAGE, res));

module.exports = router;