// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//PolicyTemplate Controller
const ColorTemplateController = require('../controllers/ColorTemplateController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', (req, res) => CRUD.create(req.body, Types.COLOR, res));


router.post('/list', (req, res) => ColorTemplateController.list({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.COLOR,
    req.body,
    res));
// Update   

router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.COLOR, res));
// Get by id

router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.COLOR, res));

module.exports = router;