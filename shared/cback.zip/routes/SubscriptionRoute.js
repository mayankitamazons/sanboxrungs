const app = require('express');
const router = app.Router();

const {
	createSubscription,
	getSubscription,
	getSubscriptions,
	subscribeSeller
} = require("../controllers/SubscriptionController");

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware');

router.route('/')
	.get(getSubscriptions)
	.post(CheckAuth, createSubscription);

router.route('/:id')
	.get(CheckAuth, getSubscription).post(CheckAuth, subscribeSeller);

module.exports = router;