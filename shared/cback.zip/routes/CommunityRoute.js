// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Community  Controller
const CommunityController = require('../controllers/CommunityController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', (req, res) => CRUD.create(req.body, Types.COMMUNITY, res));

//Filter
router.post('/communityFilter', CheckAuth, CommunityController.communityFilter);

// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.COMMUNITY, res));

// Get all
router.get('/', (req, res) => CommunityController.communityList(req.query,
    req.query.limit ? parseInt(req.query.limit) : 1000,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.COMMUNITY,
    req.body,
    res));

// Get by id
router.get('/:id', CheckAuth, (req, res) => CRUD.getById(req.params.id, Types.COMMUNITY, res));
// leader  add
router.post('/leader', CheckAuth, (req, res) => CommunityController.addleader(req, res));
module.exports = router;