// Page router
const app = require('express');
const router = app.Router();

// Email controller
const emailController = require('../controllers/EmailController');

// Create registration template
router.get('/create/registration/template', emailController.createRegistrationTemplate);

// Create registration template
router.get('/update/registration/template', emailController.updateRegistrationTemplate);

// Test registration template
router.get('/send/registration/email', emailController.sendRegistrationEmail);

// Test order template
router.get('/send/order/email', emailController.sendOrderEmail);

//  Get all templates
router.get('/list', emailController.getAllTemplate);

router.get('/list/:name', emailController.getEmailTemplate);

// Create order confirm template
router.get('/create/order/template', emailController.createOrderConfirmTemplate);

module.exports = router;