// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')
    //Blog Controller
const LeaderBoardController = require('../controllers/LeaderBoardController');
// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
//router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.BLOG, res));
router.post('/', CheckAuth, (req, res) => LeaderBoardController.add(req, res));
// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.LeaderBoard, res));

// Get all
router.post('/list', (req, res) => LeaderBoardController.list({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.LeaderBoard,
    req.body,
    res
));

// Get by id
//router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.BLOG, res));
module.exports = router;