// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Category Controller
const SubcategoryController = require('../controllers/SubcategoryController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.SUBCATEGORY, res));

//Filter
// router.post('/categorylist', CheckAuth, CategoryController.categorylist);
router.post('/subcategorylist', (req, res) => SubcategoryController.categorylist({},
            req.query.limit ? parseInt(req.query.limit) : 10,
            req.query.page ? parseInt(req.query.page) : 0,
            Types.SUBCATEGORY,
            req.body,
            res));
// Update

router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.SUBCATEGORY, res));
// Get by id
router.get('/:id', (req, res) => SubcategoryController.getSubcategoryById(req, res));

module.exports = router;