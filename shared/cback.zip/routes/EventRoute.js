// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')
    //Blog Controller
const EventController = require('../controllers/EventController');
// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
//router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.BLOG, res));
router.post('/', CheckAuth, (req, res) => EventController.add(req, res));

// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.EVENT, res));

// Get all  
router.post('/list', (req, res) => EventController.list({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.EVENT,
    req.body,
    res
));

// Get by id

router.post('/:id', (req, res) => EventController.getById(req, res));
// get by slug 
router.post('/slug/:slug', (req, res) => EventController.getBySlug(req, res));
router.get('/share/:id', (req, res) => EventController.share(req.params.id, res));
module.exports = router;