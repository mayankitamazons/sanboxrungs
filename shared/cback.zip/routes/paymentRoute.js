// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Cart Controller
const PaymentController = require('../controllers/PaymentController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')


router.post('/addpayment', (req, res) => PaymentController.add(req, res));
router.post('/updatepayment', (req, res) => PaymentController.update(req, res));
router.post('/getPaymentMethods', (req, res) => PaymentController.getPaymentMethods({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.CART,
    req.body,
    res
));
module.exports = router;