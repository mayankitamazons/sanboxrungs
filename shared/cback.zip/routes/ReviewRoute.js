const app = require('express');
const router = app.Router();

const {
    addReview,
    deleteReview,
    getAllReview,
    getReviewById,
    getReviewByProduct
} = require("../controllers/ReviewController");

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware');

router.route('/')
    .get(getAllReview)
    .post(CheckAuth, addReview);

router.route('/:id')
    .delete(CheckAuth, deleteReview)
    .get(CheckAuth, getReviewById)

module.exports = router;