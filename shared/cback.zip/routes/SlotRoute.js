// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')
    //Slot Controller
const SlotController = require('../controllers/SlotController');
// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create

router.post('/', (req, res) => SlotController.add(req, res));

// Update
// router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.SLOT, res));
router.put('/:id', (req, res) => SlotController.updateByid(req, res));
// Get all  
router.post('/list', (req, res) => SlotController.list({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.SLOT,
    req.body,
    res
));
// register seller for slot 
router.post('/sellerregister', CheckAuth, (req, res) => SlotController.sellerregister(req, res));
// Get by id    
router.get('/:id', (req, res) => SlotController.getById(req, res));

module.exports = router;