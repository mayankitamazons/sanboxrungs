// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Category Controller
const AttributeoptionController = require('../controllers/AttributeOptionController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.ATTRIBUTEOPTION, res));

//Filter
// router.post('/categorylist', CheckAuth, CategoryController.categorylist);
router.post('/list', (req, res) => AttributeoptionController.list({},
            req.query.limit ? parseInt(req.query.limit) : 10,
            req.query.page ? parseInt(req.query.page) : 0,
            Types.ATTRIBUTEOPTION,
            req.body,
            res));
// Update
router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.ATTRIBUTEOPTION, res));
// Get by id
router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.ATTRIBUTEOPTION, res));
module.exports = router;