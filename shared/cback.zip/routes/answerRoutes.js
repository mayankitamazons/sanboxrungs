// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')
    //Blog Controller
const AnswerController = require('../controllers/AnswerController');
// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
//router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.BLOG, res));
router.post('/', CheckAuth, (req, res) => AnswerController.add(req, res));

router.post('/getQuestionDetail', CheckAuth, (req, res) => AnswerController.getQuestionDetail(req, res));
// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.Answer, res));

// Get all
router.post('/list', (req, res) => AnswerController.list({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.Answer,
    req.body,
    res
));

// Get by id
//router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.BLOG, res));
router.get('/:id', (req, res) => AnswerController.getById(req, res));
router.get('/share/:id', (req, res) => AnswerController.share(req.params.id, res));
module.exports = router;