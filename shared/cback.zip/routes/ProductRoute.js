// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Product Controller
const ProductController = require('../controllers/ProductController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware');

router.post('/checkslug', (req, res) => ProductController.checkSlug(req, res));

router.post('/addproduct', (req, res) => ProductController.add(req, res));

router.post('/productlist', (req, res) => ProductController.productlist({},
    req.query.limit ? parseInt(req.query.limit) : 50,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.PRODUCT,
    req.body,
    res
));

// FITLER PRODUCTS LISTING WITH LIMIT & PAGINATION

router.post('/profilter', (req, res) => ProductController.ProductFilter({},
    req.query.limit ? parseInt(req.query.limit) : 50,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.PRODUCT,
    req.body,
    res
));
// seller wise product stock
router.post('/sellerwisestock', (req, res) => ProductController.sellerwisestock({},
    req.query.limit ? parseInt(req.query.limit) : 50,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.PRODUCT,
    req.body,
    res
));

// router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.PRODUCT, res));
router.put('/:id', (req, res) => ProductController.updateProductByid(req, res));
// Get by id

//router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.PRODUCT, res));

router.post('/:id', (req, res) => ProductController.getById(req, res));

router.get('/slug/:slug', (req, res) => ProductController.getBySlug(req, res));

router.get('/sku/:sku', (req, res) => ProductController.getBySku(req, res));

// add stock 
router.post('/addstock', (req, res) => ProductController.addstock(req, res));
// seller wise stock update
router.put('/sellerwiseupdate/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.SELLERPRODUCT, res));
router.put('/sellerwisestock/:id', (req, res) => ProductController.addstock(req, res));
router.put('/sellerwisegroupupdate/:id', (req, res) => ProductController.groupupdate(req, res));
module.exports = router;