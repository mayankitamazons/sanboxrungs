// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Cart Controller
const OrderController = require('../controllers/OrderController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

router.get('/invoice', OrderController.viewInvoice);

// router.post('/create', (req, res) => OrderController.create(req, res));
//  create order for mobile 
router.post('/createmobile', (req, res) => OrderController.createmobile(req, res));
// create services booking 
// router.post('/bookservice', (req, res) => OrderController.bookservice(req, res));
router.post('/deletecartitem', (req, res) => OrderController.delete(req, res));

router.post('/orderlist', (req, res) => OrderController.orderlist({},
	req.query.limit ? parseInt(req.query.limit) : 10,
	req.query.page ? parseInt(req.query.page) : 0,
	Types.ORDER,
	req.body,
	res
));

// router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.ORDER, res));
//router.put('/:id', (req, res) => OrderController.updateProductByid(req, res));
// Get by id
// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.ORDER, res));

//router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.PRODUCT, res));
router.get('/:id', (req, res) => OrderController.getById(req, res));
// order status change 
router.post('/changeorderstatus/:id', (req, res) => OrderController.changeorderstatus(req, res));
router.get('/slug/:slug', (req, res) => OrderController.getBySlug(req, res));

router.get('/sku/:sku', (req, res) => OrderController.getBySku(req, res));

module.exports = router;