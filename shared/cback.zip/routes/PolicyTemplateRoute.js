// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//PolicyTemplate Controller
const PolicyTemplateController = require('../controllers/PolicyTemplateController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', (req, res) => CRUD.create(req.body, Types.POLICYTEMPLATE, res));


router.post('/list', (req, res) => PolicyTemplateController.list({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.POLICYTEMPLATE,
    req.body,
    res));
// Update

router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.POLICYTEMPLATE, res));
// Get by id

router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.POLICYTEMPLATE, res));

module.exports = router;