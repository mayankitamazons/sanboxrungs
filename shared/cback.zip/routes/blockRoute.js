// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')

//Block Controller
const blockController = require('../controllers/BlockController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.BLOCK, res));

// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.BLOCK, res));

// Get all
router.get('/', CheckAuth, blockController.blockList);




// Get by id
router.get('/:id', CheckAuth, (req, res) => CRUD.getById(req.params.id, Types.BLOCK, res));

// home page 
// Get all

router.post('/home', blockController.homelist); 
router.post('/homepage', (req, res) => blockController.homepage({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.QUESTION,
    req.body,
    res
));
router.post('/search', (req, res) => blockController.search({},
    req.query.limit ? parseInt(req.query.limit) : 1000,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.PRODUCT,
    req.body,
    res
));

module.exports = router;