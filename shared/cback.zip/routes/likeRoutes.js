// User router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// Follow controller
const likeController = require('../controllers/LikeController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// CRUD Service
const CRUD = require('../shared/CRUD')

// add like true false video
router.post('/addlike', CheckAuth, likeController.addLike);

// add like true false comment
//router.post('/addcommentlike', CheckAuth, likeController.addCommentLike);

// update Follow is_follow false
router.post('/updatelike', CheckAuth, likeController.updateLike);

// Followed By logged in user
//router.post('/likelisting', CheckAuth, likeController.likeListing);


module.exports = router;