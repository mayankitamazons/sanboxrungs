// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Category Controller
const CustomController = require('../controllers/CustomController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
// router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.CATEGORY, res));

//Filter
router.post('/add', (req, res) => CustomController.add({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    req.body,
    res
));
router.post('/customlist', (req, res) => CustomController.categorylist({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.CATEGORY,
    req.body,
    res));
// Update

router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.CATEGORY, res));
// Get by id
router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.CATEGORY, res));

module.exports = router;