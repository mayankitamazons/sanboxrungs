// Notification router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// NotificationController
const notificationController = require('../controllers/NotificationController');

// CRUD Service
const CRUD = require('../shared/CRUD')

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Call start notification
router.post('/call', CheckAuth, notificationController.callNotification);

// Call end notification
router.post('/call_end', CheckAuth, notificationController.callEndNotification);

module.exports = router;