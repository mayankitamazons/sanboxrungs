// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Category Controller
const CategoryController = require('../controllers/CategoryController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', CheckAuth, (req, res) => CategoryController.create(req, res));

//Filter
// router.post('/categorylist', CheckAuth, CategoryController.categorylist);
router.post('/categorylist', (req, res) => CategoryController.categorylist({},
    req.query.limit ? parseInt(req.query.limit) : 1000,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.CATEGORY,
    req.body,
    res));
// Update

//category id can be main category id and subcategory id
router.post('/getCategoryTreeByid', (req, res) => CategoryController.getCategoryTreeByid({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.CATEGORY,
    req.body,
    res));
// get categry tree by slug
router.post('/getCategoryTreeByslug', (req, res) => CategoryController.getCategoryTreeByslug({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.CATEGORY,
    req.body,
    res));

//router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.CATEGORY, res));
router.put('/:id', (req, res) => CategoryController.updateCategoryByid(req, res));

// Get by id
//router.get('/:id', (req, res) => CategoryController.getCategoryById(req, res));

router.get('/treeFormat', (req, res) => CategoryController.treeFormat(req, res));

router.get('/:id', (req, res) => CategoryController.getCategoryById(req, res));
router.get('/slug/:slug', (req, res) => CategoryController.getBySlug(req, res));
module.exports = router;