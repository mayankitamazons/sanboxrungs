// User router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// Comment controller
const commentController = require('../controllers/CommentController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// CRUD Service
const CRUD = require('../shared/CRUD')

// add Comment is_comment true
router.post('/addcomment', CheckAuth, commentController.addComment);

// update Comment is_comment false
router.post('/update', CheckAuth, commentController.updateComment);
//router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.COMMENT, res));

// Commented By logged in user
router.post('/listing', commentController.commentListing);   


module.exports = router;