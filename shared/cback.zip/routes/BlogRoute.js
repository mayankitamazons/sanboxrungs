// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')
    //Blog Controller
const BlogController = require('../controllers/BlogController');
// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
//router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.BLOG, res));
router.post('/', CheckAuth, (req, res) => BlogController.addBlog(req, res));

// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.BLOG, res));

// Get all
router.post('/list', (req, res) => BlogController.bloglist({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.BLOG,
    req.body,
    res
));

// Get by id
//router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.BLOG, res));
router.post('/:id', (req, res) => BlogController.getById(req, res));
// get by slug 
router.post('/slug/:slug', (req, res) => BlogController.getBySlug(req, res));
router.get('/share/:id', (req, res) => BlogController.shareblog(req.params.id, res));
module.exports = router;