// User router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// User controller
const userController = require('../controllers/UserController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// CRUD Service
const CRUD = require('../shared/CRUD')

// User update
//router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.USER, res));
router.put('/:id', (req, res) => userController.updateById(req, res));
router.get('/env', userController.getENV);
//router.get('/all', CheckAuth, userController.getAllUser);
// Get all
router.get('/all', (req, res) => userController.getAllUser({},
	req.query.limit ? parseInt(req.query.limit) : 1000,
	req.query.page ? parseInt(req.query.page) : 0,
	Types.USER,
	res));
router.post('/sellerlist', (req, res) => userController.sellerlist({},
	req.query.limit ? parseInt(req.query.limit) : 10,
	req.query.page ? parseInt(req.query.page) : 0,
	Types.USER,
	res));
// User GetUserByid
router.post('/getuserdata', userController.getuserdata);
//router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.USER, res));
router.get('/:id', (req, res) => userController.getById(req, res));
router.get('/seller/:id', (req, res) => userController.getSellerById(req, res));
// Notification id
router.post('/notification_id', CheckAuth, userController.notificationID);
router.post('/sendotp', userController.sendotp);
// send message
router.get('/sendsms', userController.sendsms);
// wishlist add
router.post('/addwishlist', CheckAuth, (req, res) => userController.addtowishlist(req, res));
router.post('/wishlist', CheckAuth, (req, res) => userController.wishlist(req, res));

module.exports = router;