// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD')
//Blog Controller
const QuestionController = require('../controllers/QuestionController');
// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
//router.post('/', CheckAuth, (req, res) => CRUD.create(req.body, Types.BLOG, res));
router.post('/', CheckAuth, (req, res) => QuestionController.add(req, res));

// Update
router.put('/:id', CheckAuth, QuestionController.update);

// Get all
router.post('/list', (req, res) => QuestionController.list({},
	req.query.limit ? parseInt(req.query.limit) : 10,
	req.query.page ? parseInt(req.query.page) : 0,
	Types.QUESTION,
	req.body,
	res
));

// Get by id
//router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.BLOG, res));
router.get('/:id', (req, res) => QuestionController.getById(req, res));
router.get('/slug/:slug', (req, res) => QuestionController.getBySlug(req, res));
router.get('/share/:id', (req, res) => QuestionController.share(req.params.id, res));
module.exports = router;