// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Cart Controller
const CartController = require('../controllers/CartController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')


router.post('/addtocart', (req, res) => CartController.add(req, res));
router.post('/deletecartitem', (req, res) => CartController.delete(req, res));
router.post('/setPaymentMethod', (req, res) => CartController.setPaymentMethod(req, res));
router.post('/applyCoupon', (req, res) => CartController.applyCoupon(req, res));
router.post('/removeCoupon', (req, res) => CartController.removeCoupon(req, res));
router.post('/setCheckoutAddress', (req, res) => CartController.setCheckoutAddress(req, res));

router.post('/cartlist', (req, res) => CartController.cartlist({},
    req.query.limit ? parseInt(req.query.limit) : 10,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.CART,
    req.body,
    res
));

router.put('/:id', (req, res) => CRUD.updateById(req.params.id, req.body, Types.CART, res));
//router.put('/:id', (req, res) => CartController.updateProductByid(req, res));
// Get by id

router.get('/:id', (req, res) => CRUD.getById(req.params.id, Types.CART, res));
//router.get('/:id', (req, res) => CartController.getById(req, res));
// get cart by user id 
router.get('/:user_id', (req, res) => CartController.getByUserId(req, res));
router.get('/slug/:slug', (req, res) => CartController.getBySlug(req, res));

router.get('/sku/:sku', (req, res) => CartController.getBySku(req, res));

module.exports = router;