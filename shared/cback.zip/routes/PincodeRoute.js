// Page router
const app = require('express');
const router = app.Router();
const Types = require('../shared/Types') // Model types

// CRUD Service
const CRUD = require('../shared/CRUD');

//Pincode  Controller
const PincodeController = require('../controllers/PincodeController');

// Auth middleware
const CheckAuth = require('../shared/middleware/AuthMiddleware')

// Create
router.post('/', (req, res) => CRUD.create(req.body, Types.PINCODE, res));

//Filter
router.post('/pincodeFilter', CheckAuth, PincodeController.communityFilter);

// Update
router.put('/:id', CheckAuth, (req, res) => CRUD.updateById(req.params.id, req.body, Types.PINCODE, res));

// Get all
router.get('/', (req, res) => PincodeController.pincodeList(req.query,
    req.query.limit ? parseInt(req.query.limit) : 1000,
    req.query.page ? parseInt(req.query.page) : 0,
    Types.PINCODE,
    req.body,
    res));

// Get by id
router.get('/:id', CheckAuth, (req, res) => CRUD.getById(req.params.id, Types.PINCODE, res));
module.exports = router;